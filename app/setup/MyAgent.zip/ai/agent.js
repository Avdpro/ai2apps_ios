//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
/*#{1HDBOSUN90MoreImports*/
/*}#1HDBOSUN90MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HDBOSUN90StartDoc*/
/*}#1HDBOSUN90StartDoc*/
//----------------------------------------------------------------------------
let agent=async function(session){
	let context,globalContext;
	let self;
	let DrawAndTell,OpenPic,SEG1HEP4C3P80,SEG1HEP4C3P81,SEG1HEPDGD1D0,SEG1HEPDGD1D1,SEG1HEPDGD1D2,SEG1HEQGDB1A0,SEG1HEQGF1KN0,SEG1HEQGGTHM0,SEG1HEQGR6G61,SEG1HEQGR6G62,SEG1HEQGR6G63,DrawGirl,Hair,SEG1HEQQ6LKK1,Chest,SEG1HEQQ6LKK2,Cloth,SEG1HEQQ6LKK3,SEG1HEQQ6LKK4,SEG1HESQFUCA0,SEG1HESR6BL30,SEG1HEVKC45P0,SEG1HEVKC45P1,SEG1HEVKC45P2,SEG1HEVKC45P3,AskHow,SEG1HF3JK1CR0,SEG1HF3JK1CR1,SEG1HF3JK1CR2,SEG1HF4D10RK0,SEG1HF4NEDC00;
	/*#{1HDBOSUN90LocalVals*/
	/*}#1HDBOSUN90LocalVals*/
	
	/*#{1HDBOSUN90PreContext*/
	/*}#1HDBOSUN90PreContext*/
	globalContext=session.globalContext;
	context={
		"req":"","hair":"长发","chest":"大","body":"偏瘦","cloth":"水手服",
		/*#{1HDBOSUNA3ExCtxAttrs*/
		/*}#1HDBOSUNA3ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1HDBOSUN90PostContext*/
	/*}#1HDBOSUN90PostContext*/
	let agent,segs={};
	segs["DrawAndTell"]=DrawAndTell=async function(input){//:1HEQGR6G60
		let prompt=("Please input")||input;
		let placeholder=("");
		let text=("");
		let result="";
		result=await session.askChatInput({type:"input",prompt:prompt,placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:SEG1HEQGR6G61,result:(result),preSeg:"1HEQGR6G60",outlet:"1HEQGR6G80"};
	};
	DrawAndTell.jaxId="1HEQGR6G60"
	DrawAndTell.url="DrawAndTell@"+agentURL
	
	segs["OpenPic"]=OpenPic=async function(input){//:1HEQDJHUP0
		let prompt=("Please confirm")||input;
		let resultText="";
		let fileData=null;
		let enc=null;
		let ext=null;
		let fileSys="native";
		let result="";
		let path=("");
		let filter=("");
		[resultText,result]=await session.askUserRaw({type:"input",prompt:prompt,text:path,file:fileSys,filter:filter,});
		return {seg:SEG1HEQGDB1A0,result:(result),preSeg:"1HEQDJHUP0",outlet:"1HEQDJHUP2"};
	};
	OpenPic.jaxId="1HEQDJHUP0"
	OpenPic.url="OpenPic@"+agentURL
	
	segs["SEG1HEP4C3P80"]=SEG1HEP4C3P80=async function(input){//:1HEP4C3P80
		let prompt=("Please input")||input;
		let placeholder=("");
		let text=("");
		let result="";
		result=await session.askChatInput({type:"input",prompt:prompt,placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:SEG1HEPDGD1D0,result:(result),preSeg:"1HEP4C3P80",outlet:"1HEP4C3P90"};
	};
	SEG1HEP4C3P80.jaxId="1HEP4C3P80"
	SEG1HEP4C3P80.url="SEG1HEP4C3P80@"+agentURL
	
	segs["SEG1HEP4C3P81"]=SEG1HEP4C3P81=async function(input){//:1HEP4C3P81
		let prompt;
		let result;
		
		let opts={
			mode:"gpt-4-1106-preview",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false
		};
		let messages=[
			{role:"system",content:"你是一个提炼输入的小说文本内容，自动生成用于AI绘制图片提示词的AI。\n请尽量简短的输出图片描述。"},
		];
		prompt=input;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("SEG1HEP4C3P81@"+agentURL,opts,messages,true);
		return {result:result};
	};
	SEG1HEP4C3P81.jaxId="1HEP4C3P81"
	SEG1HEP4C3P81.url="SEG1HEP4C3P81@"+agentURL
	
	segs["SEG1HEPDGD1D0"]=SEG1HEPDGD1D0=async function(input){//:1HEPDGD1D0
		let sumVO={}
		let pmsList=[]
		let result;
		/*#{1HEPDGD1D0PreCodes*/
		/*}#1HEPDGD1D0PreCodes*/
		pmsList.push(session.execAISeg(agent,SEG1HEPDGD1D1,(input)).then((r)=>{
			sumVO["No1"]=r;
			/*#{1HEPDJA2F2PostCodes*/
			/*}#1HEPDJA2F2PostCodes*/
		
		}));
		pmsList.push(session.execAISeg(agent,SEG1HEPDGD1D1,(input)).then((r)=>{
			sumVO["No2"]=r;
			/*#{1HEPDJA2F3PostCodes*/
			/*}#1HEPDJA2F3PostCodes*/
		
		}));
		pmsList.push(session.execAISeg(agent,SEG1HEPDGD1D1,(input)).then((r)=>{
			sumVO["No3"]=r;
			/*#{1HEPDJA2F4PostCodes*/
			/*}#1HEPDJA2F4PostCodes*/
		
		}));
		await Promise.all(pmsList);
		/*#{1HEPDGD1D0PostCodes*/
		/*}#1HEPDGD1D0PostCodes*/
		result=JSON.stringify(sumVO,null,"\t");
		/*#{1HEPDGD1D0Codes*/
		/*}#1HEPDGD1D0Codes*/
		return {seg:SEG1HEPDGD1D2,result:(result),preSeg:"1HEPDGD1D0",outlet:"1HEPDGD1E0"};
	};
	SEG1HEPDGD1D0.jaxId="1HEPDGD1D0"
	SEG1HEPDGD1D0.url="SEG1HEPDGD1D0@"+agentURL
	
	segs["SEG1HEPDGD1D1"]=SEG1HEPDGD1D1=async function(input){//:1HEPDGD1D1
		let callVO=null;
		let result=input;
		let rsp=null;
		let dataURL=null;
		let mode="dall-e-3";
		let prompt=input;
		let size="1792x1024";
		let label="AI Picture:";
		callVO={model:mode,prompt:prompt,size:size};
		rsp=await session.sysCall("AIDraw",callVO,true,100000);
		if(rsp.code===200){
			result=rsp.img;
			dataURL=`data:image/jpeg;base64,${result}`
			session.addChatText("assistant",label,{image:dataURL});
			result=dataURL;
		
		}else{
			throw Error("Error "+rsp.code+": "+rsp.info||"")
		}
		return {result:result};
	};
	SEG1HEPDGD1D1.jaxId="1HEPDGD1D1"
	SEG1HEPDGD1D1.url="SEG1HEPDGD1D1@"+agentURL
	
	segs["SEG1HEPDGD1D2"]=SEG1HEPDGD1D2=async function(input){//:1HEPDGD1D2
		let prompt=("是否生成更多图片？")||input;
		let button1=("More")||"OK";
		let button2=("Done")||"Cancel";
		let button3=("")||"";
		let result="";
		let value=0;
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3});
		if(value===1){result=("OK")||result;
		return {seg:SEG1HEPDGD1D0,result:(result),preSeg:"1HEPDGD1D2",outlet:"1HFCL8DQ90"};}
		if(value===2){result=("")||result;
		return {result:result};}
		result=("Cancel")||result;
		return {seg:SEG1HEP4C3P80,result:(result),preSeg:"1HEPDGD1D2",outlet:"1HFCL8DQ91"};
	
	};
	SEG1HEPDGD1D2.jaxId="1HEPDGD1D2"
	SEG1HEPDGD1D2.url="SEG1HEPDGD1D2@"+agentURL
	
	segs["SEG1HEQGDB1A0"]=SEG1HEQGDB1A0=async function(input){//:1HEQGDB1A0
		let result=input;
		let role="assistant";
		let conent="图片:";
		session.addChatText(role,conent,{image:input});
		return {seg:SEG1HEQGF1KN0,result:(result),preSeg:"1HEQGDB1A0",outlet:"1HEQGDB1C0"};
	};
	SEG1HEQGDB1A0.jaxId="1HEQGDB1A0"
	SEG1HEQGDB1A0.url="SEG1HEQGDB1A0@"+agentURL
	
	segs["SEG1HEQGF1KN0"]=SEG1HEQGF1KN0=async function(input){//:1HEQGF1KN0
		let prompt;
		let result;
		
		let imageURL=input
		let opts={
			mode:"gpt-4-vision-preview",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false
		};
		let messages=[];
		prompt="描述一下这幅图片";
		if(prompt!==null){
			if(!imageURL.startsWith("data:")){
				let ext=pathLib.extname(imageURL)
				let buf=await (await fetch(imageURL)).arrayBuffer();
				buf=Base64.encode(buf)
				switch(ext){
					case ".jpg":
						imageURL="data:image/jpeg;base64,"+buf;
						break;
					case ".png":
						imageURL="data:image/png;base64,"+buf;
						break;
					default:
						throw Error("Wrong imageURL extname: "+ext);
						break;
				}
			}
			messages.push({role:"user",content:[{type:"text",text:prompt},{type:"image_url","image_url":imageURL}]});
		
		}
		result=await session.callSegLLM("SEG1HEQGF1KN0@"+agentURL,opts,messages,true);
		return {seg:SEG1HEQGGTHM0,result:(result),preSeg:"1HEQGF1KN0",outlet:"1HEQGF1KP0"};
	};
	SEG1HEQGF1KN0.jaxId="1HEQGF1KN0"
	SEG1HEQGF1KN0.url="SEG1HEQGF1KN0@"+agentURL
	
	segs["SEG1HEQGGTHM0"]=SEG1HEQGGTHM0=async function(input){//:1HEQGGTHM0
		let result=input;
		let role="assistant";
		let conent=input;
		session.addChatText(role,conent);
		return {result:result};
	};
	SEG1HEQGGTHM0.jaxId="1HEQGGTHM0"
	SEG1HEQGGTHM0.url="SEG1HEQGGTHM0@"+agentURL
	
	segs["SEG1HEQGR6G61"]=SEG1HEQGR6G61=async function(input){//:1HEQGR6G61
		let callVO=null;
		let result=input;
		let rsp=null;
		let dataURL=null;
		let mode="dall-e-3";
		let prompt=input;
		let size="1024x1024";
		let label="AI Picture:";
		callVO={model:mode,prompt:prompt,size:size};
		rsp=await session.sysCall("AIDraw",callVO,true,100000);
		if(rsp.code===200){
			result=rsp.img;
			dataURL=`data:image/jpeg;base64,${result}`
			session.addChatText("assistant",label,{image:dataURL});
			result=dataURL;
		
		}else{
			throw Error("Error "+rsp.code+": "+rsp.info||"")
		}
		return {seg:SEG1HEQGR6G62,result:(result),preSeg:"1HEQGR6G61",outlet:"1HEQGR6G81"};
	};
	SEG1HEQGR6G61.jaxId="1HEQGR6G61"
	SEG1HEQGR6G61.url="SEG1HEQGR6G61@"+agentURL
	
	segs["SEG1HEQGR6G62"]=SEG1HEQGR6G62=async function(input){//:1HEQGR6G62
		let prompt;
		let result;
		
		let imageURL=input
		let opts={
			mode:"gpt-4-vision-preview",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false
		};
		let messages=[];
		prompt="描述一下这幅图片";
		if(prompt!==null){
			if(!imageURL.startsWith("data:")){
				let ext=pathLib.extname(imageURL)
				let buf=await (await fetch(imageURL)).arrayBuffer();
				buf=Base64.encode(buf)
				switch(ext){
					case ".jpg":
						imageURL="data:image/jpeg;base64,"+buf;
						break;
					case ".png":
						imageURL="data:image/png;base64,"+buf;
						break;
					default:
						throw Error("Wrong imageURL extname: "+ext);
						break;
				}
			}
			messages.push({role:"user",content:[{type:"text",text:prompt},{type:"image_url","image_url":imageURL}]});
		
		}
		result=await session.callSegLLM("SEG1HEQGR6G62@"+agentURL,opts,messages,true);
		return {seg:SEG1HEQGR6G63,result:(result),preSeg:"1HEQGR6G62",outlet:"1HEQGR6G82"};
	};
	SEG1HEQGR6G62.jaxId="1HEQGR6G62"
	SEG1HEQGR6G62.url="SEG1HEQGR6G62@"+agentURL
	
	segs["SEG1HEQGR6G63"]=SEG1HEQGR6G63=async function(input){//:1HEQGR6G63
		let result=input;
		let role="assistant";
		let conent=input;
		session.addChatText(role,conent);
		return {result:result};
	};
	SEG1HEQGR6G63.jaxId="1HEQGR6G63"
	SEG1HEQGR6G63.url="SEG1HEQGR6G63@"+agentURL
	
	segs["DrawGirl"]=DrawGirl=async function(input){//:1HEQQ6LKK0
		let result=input;
		let role="assistant";
		let conent="请选择你的萝莉女友外观";
		session.addChatText(role,conent);
		return {seg:Hair,result:(result),preSeg:"1HEQQ6LKK0",outlet:"1HEQQ6LKL0"};
	};
	DrawGirl.jaxId="1HEQQ6LKK0"
	DrawGirl.url="DrawGirl@"+agentURL
	
	segs["Hair"]=Hair=async function(input){//:1HEQQ6LKL1
		let prompt=("头发：")||input;
		let items=[
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"长发",code:0},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"短发",code:1},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"到肩",code:2},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"卷发",code:3},
		];
		let result="";
		let item=null;
		let multi=true;
		
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:multi,items:items});
		if(multi){
			return {seg:SEG1HEQQ6LKK1,result:(result),preSeg:"1HEQQ6LKL1",outlet:"1HFCL8DQB0"};
		}
		if(item.code===0){
			return {seg:SEG1HEQQ6LKK1,result:(result),preSeg:"1HEQQ6LKL1",outlet:"1HFCL8DQB0"};
		}
		if(item.code===1){
			return {seg:SEG1HEQQ6LKK1,result:(result),preSeg:"1HEQQ6LKL1",outlet:"1HFCL8DQB1"};
		}
		if(item.code===2){
			return {seg:SEG1HEQQ6LKK1,result:(result),preSeg:"1HEQQ6LKL1",outlet:"1HFCL8DQB2"};
		}
		if(item.code===3){
			return {seg:SEG1HEQQ6LKK1,result:(result),preSeg:"1HEQQ6LKL1",outlet:"1HEQQJ4BU0"};
		}
		return {result:result};
	
	};
	Hair.jaxId="1HEQQ6LKL1"
	Hair.url="Hair@"+agentURL
	
	segs["SEG1HEQQ6LKK1"]=SEG1HEQQ6LKK1=async function(input){//:1HEQQ6LKK1
		let result=""
		/*#{1HEQQ6LKK1Code*/
		/*}#1HEQQ6LKK1Code*/
		Object.assign(context,{
			"hair":input
		});
		return {seg:Chest,result:(result),preSeg:"1HEQQ6LKK1",outlet:"1HEQQ6LKL2"};
	};
	SEG1HEQQ6LKK1.jaxId="1HEQQ6LKK1"
	SEG1HEQQ6LKK1.url="SEG1HEQQ6LKK1@"+agentURL
	
	segs["Chest"]=Chest=async function(input){//:1HEQQ6LKL3
		let prompt=("胸部")||input;
		let items=[
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"发育良好",code:0},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"中等",code:1},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"小",code:2},
		];
		let result="";
		let item=null;
		let multi=false;
		
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:multi,items:items});
		if(multi){
			return {seg:SEG1HEQQ6LKK2,result:(result),preSeg:"1HEQQ6LKL3",outlet:"1HFCL8DQC0"};
		}
		if(item.code===0){
			return {seg:SEG1HEQQ6LKK2,result:(result),preSeg:"1HEQQ6LKL3",outlet:"1HFCL8DQC0"};
		}
		if(item.code===1){
			return {seg:SEG1HEQQ6LKK2,result:(result),preSeg:"1HEQQ6LKL3",outlet:"1HFCL8DQC1"};
		}
		if(item.code===2){
			return {seg:SEG1HEQQ6LKK2,result:(result),preSeg:"1HEQQ6LKL3",outlet:"1HFCL8DQC2"};
		}
		return {result:result};
	
	};
	Chest.jaxId="1HEQQ6LKL3"
	Chest.url="Chest@"+agentURL
	
	segs["SEG1HEQQ6LKK2"]=SEG1HEQQ6LKK2=async function(input){//:1HEQQ6LKK2
		let result=""
		/*#{1HEQQ6LKK2Code*/
		/*}#1HEQQ6LKK2Code*/
		Object.assign(context,{
			"chest":input
		});
		return {seg:Cloth,result:(result),preSeg:"1HEQQ6LKK2",outlet:"1HEQQ6LKL4"};
	};
	SEG1HEQQ6LKK2.jaxId="1HEQQ6LKK2"
	SEG1HEQQ6LKK2.url="SEG1HEQQ6LKK2@"+agentURL
	
	segs["Cloth"]=Cloth=async function(input){//:1HEQQ6LKL5
		let prompt=("衣服")||input;
		let items=[
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"水手校服",code:0},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"女仆装",code:1},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"泡泡裙",code:2},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"西装",code:3},
		];
		let result="";
		let item=null;
		let multi=false;
		
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:multi,items:items});
		if(multi){
			return {seg:SEG1HEQQ6LKK3,result:(result),preSeg:"1HEQQ6LKL5",outlet:"1HFCL8DQC3"};
		}
		if(item.code===0){
			return {seg:SEG1HEQQ6LKK3,result:(result),preSeg:"1HEQQ6LKL5",outlet:"1HFCL8DQC3"};
		}
		if(item.code===1){
			return {seg:SEG1HEQQ6LKK3,result:(result),preSeg:"1HEQQ6LKL5",outlet:"1HFCL8DQC4"};
		}
		if(item.code===2){
			return {seg:SEG1HEQQ6LKK3,result:(result),preSeg:"1HEQQ6LKL5",outlet:"1HFCL8DQC5"};
		}
		if(item.code===3){
			return {seg:SEG1HEQQ6LKK3,result:(result),preSeg:"1HEQQ6LKL5",outlet:"1HEQQJ4BU1"};
		}
		return {result:result};
	
	};
	Cloth.jaxId="1HEQQ6LKL5"
	Cloth.url="Cloth@"+agentURL
	
	segs["SEG1HEQQ6LKK3"]=SEG1HEQQ6LKK3=async function(input){//:1HEQQ6LKK3
		let result=""
		/*#{1HEQQ6LKK3Code*/
		/*}#1HEQQ6LKK3Code*/
		Object.assign(context,{
			"cloth":input
		});
		return {seg:SEG1HEQQ6LKK4,result:(result),preSeg:"1HEQQ6LKK3",outlet:"1HEQQ6LKM0"};
	};
	SEG1HEQQ6LKK3.jaxId="1HEQQ6LKK3"
	SEG1HEQQ6LKK3.url="SEG1HEQQ6LKK3@"+agentURL
	
	segs["SEG1HEQQ6LKK4"]=SEG1HEQQ6LKK4=async function(input){//:1HEQQ6LKK4
		let callVO=null;
		let result=input;
		let rsp=null;
		let dataURL=null;
		let mode="dall-e-3";
		let prompt=`一个头发长度是${context.hair}，${context.chest}胸，穿着${context.cloth}的萝莉女孩非常真实效果的照片。`;
		let size="1024x1024";
		let label="AI Picture:";
		callVO={model:mode,prompt:prompt,size:size};
		rsp=await session.sysCall("AIDraw",callVO,true,100000);
		if(rsp.code===200){
			result=rsp.img;
			dataURL=`data:image/jpeg;base64,${result}`
			session.addChatText("assistant",label,{image:dataURL});
			result=dataURL;
		
		}else{
			throw Error("Error "+rsp.code+": "+rsp.info||"")
		}
		return {result:result};
	};
	SEG1HEQQ6LKK4.jaxId="1HEQQ6LKK4"
	SEG1HEQQ6LKK4.url="SEG1HEQQ6LKK4@"+agentURL
	
	segs["SEG1HESQFUCA0"]=SEG1HESQFUCA0=async function(input){//:1HESQFUCA0
		let result=input;
		/*#{1HESQFUCA0Code*/
		/*}#1HESQFUCA0Code*/
		return {seg:SEG1HEP4C3P81,result:(result),preSeg:"1HESQFUCA0",outlet:"1HESQFUCI2",catchSeg:SEG1HEP4C3P81,catchlet:"1HESQFUCI3"};
	};
	SEG1HESQFUCA0.jaxId="1HESQFUCA0"
	SEG1HESQFUCA0.url="SEG1HESQFUCA0@"+agentURL
	
	segs["SEG1HESR6BL30"]=SEG1HESR6BL30=async function(input){//:1HESR6BL30
		let result=input;
		let role="assistant";
		let conent=input;
		session.addChatText(role,conent);
		return {result:result};
	};
	SEG1HESR6BL30.jaxId="1HESR6BL30"
	SEG1HESR6BL30.url="SEG1HESR6BL30@"+agentURL
	
	segs["SEG1HEVKC45P0"]=SEG1HEVKC45P0=async function(input){//:1HEVKC45P0
		let prompt=("请选择参考图片")||input;
		let resultText="";
		let fileData=null;
		let enc=null;
		let ext=null;
		let fileSys="native";
		let result="";
		let path=("");
		let filter=("");
		[resultText,result]=await session.askUserRaw({type:"input",prompt:prompt,text:path,file:fileSys,filter:filter,});
		ext=pathLib.extname(resultText);
		fileData=result||(await (await fetch(resultText)).arrayBuffer());
		result=Base64.encode(fileData);
		switch(ext){
			case ".jpg":
				result="data:image/jpeg;base64,"+result;
				break;
			case ".png":
				result="data:image/png;base64,"+result;
				break;case ".txt":
					result="data:text/plain;base64,"+result;
					break;
				default:
					result="data:application/octet-stream;base64,"+result;
					break;
			}
			return {seg:SEG1HF3JK1CR0,result:(result),preSeg:"1HEVKC45P0",outlet:"1HEVKC45S0"};
		};
		SEG1HEVKC45P0.jaxId="1HEVKC45P0"
		SEG1HEVKC45P0.url="SEG1HEVKC45P0@"+agentURL
		
		segs["SEG1HEVKC45P1"]=SEG1HEVKC45P1=async function(input){//:1HEVKC45P1
			let prompt;
			let result;
			
			let imageURL=input
			let opts={
				mode:"gpt-4-vision-preview",
				maxToken:2000,
				temperature:0,
				topP:1,
				fqcP:0,
				prcP:0,
				secret:false
			};
			let messages=[];
			prompt=`请参考这个图片的风格，生成绘制${context.req}的Prompt。你的输出应该仅包含Prompt，不要有其它多余的文字`;
			if(prompt!==null){
				if(!imageURL.startsWith("data:")){
					let ext=pathLib.extname(imageURL)
					let buf=await (await fetch(imageURL)).arrayBuffer();
					buf=Base64.encode(buf)
					switch(ext){
						case ".jpg":
							imageURL="data:image/jpeg;base64,"+buf;
							break;
						case ".png":
							imageURL="data:image/png;base64,"+buf;
							break;
						default:
							throw Error("Wrong imageURL extname: "+ext);
							break;
					}
				}
				messages.push({role:"user",content:[{type:"text",text:prompt},{type:"image_url","image_url":imageURL}]});
			
			}
			result=await session.callSegLLM("SEG1HEVKC45P1@"+agentURL,opts,messages,true);
			return {seg:SEG1HF3JK1CR1,result:(result),preSeg:"1HEVKC45P1",outlet:"1HEVKC45S1"};
		};
		SEG1HEVKC45P1.jaxId="1HEVKC45P1"
		SEG1HEVKC45P1.url="SEG1HEVKC45P1@"+agentURL
		
		segs["SEG1HEVKC45P2"]=SEG1HEVKC45P2=async function(input){//:1HEVKC45P2
			let callVO=null;
			let result=input;
			let rsp=null;
			let dataURL=null;
			let mode="dall-e-3";
			let prompt=input;
			let size="1024x1024";
			let label="AI Picture:";
			callVO={model:mode,prompt:prompt,size:size};
			rsp=await session.sysCall("AIDraw",callVO,true,100000);
			if(rsp.code===200){
				result=rsp.img;
				dataURL=`data:image/jpeg;base64,${result}`
				session.addChatText("assistant",label,{image:dataURL});
				result=dataURL;
			
			}else{
				throw Error("Error "+rsp.code+": "+rsp.info||"")
			}
			return {result:result};
		};
		SEG1HEVKC45P2.jaxId="1HEVKC45P2"
		SEG1HEVKC45P2.url="SEG1HEVKC45P2@"+agentURL
		
		segs["SEG1HEVKC45P3"]=SEG1HEVKC45P3=async function(input){//:1HEVKC45P3
			let callVO=null;
			let result=input;
			let rsp=null;
			let mode="tts-1";
			let text2Read=input;
			let voice="alloy";
			let label="语音:";
			let showBlock=true;
			let autoPlay=true;
			callVO={model:mode,input:text2Read,voice:voice};
			rsp=await session.sysCall("AITTS",callVO,true,100000);
			if(rsp.code===200){
				result=rsp.mp3;
				if(autoPlay)session.addChatText("assistant",label,{audio:result,autoPlay:autoPlay});
			
			}else{
				throw Error("Error "+rsp.code+": "+rsp.info||"")
			}
			return {result:result};
		};
		SEG1HEVKC45P3.jaxId="1HEVKC45P3"
		SEG1HEVKC45P3.url="SEG1HEVKC45P3@"+agentURL
		
		segs["AskHow"]=AskHow=async function(input){//:1HEVKC45P4
			let prompt=("你想话什么东西？")||input;
			let placeholder=("想画的东西");
			let text=("");
			let result="";
			/*#{1HEVKC45P4PreCodes*/
			/*}#1HEVKC45P4PreCodes*/
			result=await session.askChatInput({type:"input",prompt:prompt,placeholder:placeholder,text:text});
			session.addChatText("user",result);
			/*#{1HEVKC45P4PostCodes*/
			context.req=result;
			/*}#1HEVKC45P4PostCodes*/
			return {seg:SEG1HEVKC45P0,result:(result),preSeg:"1HEVKC45P4",outlet:"1HEVKC45T1"};
		};
		AskHow.jaxId="1HEVKC45P4"
		AskHow.url="AskHow@"+agentURL
		
		segs["SEG1HF3JK1CR0"]=SEG1HF3JK1CR0=async function(input){//:1HF3JK1CR0
			let result=input;
			let role="assistant";
			let conent="图片:";
			session.addChatText(role,conent,{image:input});
			//Limit size:
			let callback =null;
			let pms=new Promise((resolve)=>{callback=resolve;});
			{
				
				let maxSize =512;
				let img = new Image();
				img.crossOrigin = "Anonymous";
				img.src = input;
				img.onload = function () {
					let imgW = img.width;
					let imgH = img.height;
					let scale = maxSize/(imgW>imgH?imgW:imgH);
					if(scale<1){
						let canvas = document.createElement("canvas");
						let context = canvas.getContext("2d");
						canvas.width = Math.floor(img.width*scale);
						canvas.height = Math.floor(img.height*scale);
						context.drawImage(img, 0, 0,canvas.width,canvas.height);
						result = canvas.toDataURL("image/png");
					}
					callback();
				};
			}
			await pms;
			return {seg:SEG1HEVKC45P1,result:(result),preSeg:"1HF3JK1CR0",outlet:"1HF3JK1CT0"};
		};
		SEG1HF3JK1CR0.jaxId="1HF3JK1CR0"
		SEG1HF3JK1CR0.url="SEG1HF3JK1CR0@"+agentURL
		
		segs["SEG1HF3JK1CR1"]=SEG1HF3JK1CR1=async function(input){//:1HF3JK1CR1
			let result=input;
			let role="assistant";
			let conent=input;
			session.addChatText(role,conent);
			return {seg:SEG1HF3JK1CR2,result:(result),preSeg:"1HF3JK1CR1",outlet:"1HF3JK1CT1"};
		};
		SEG1HF3JK1CR1.jaxId="1HF3JK1CR1"
		SEG1HF3JK1CR1.url="SEG1HF3JK1CR1@"+agentURL
		
		segs["SEG1HF3JK1CR2"]=SEG1HF3JK1CR2=async function(input){//:1HF3JK1CR2
			let prompt=("是否使用这个提示绘制？")||input;
			let button1=("绘制")||"OK";
			let button2=("重新生成提示")||"Cancel";
			let button3=("重新选择图片")||"";
			let result="";
			let value=0;
			[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3});
			if(value===1){result=(input)||result;
			return {seg:SEG1HEVKC45P2,result:(result),preSeg:"1HF3JK1CR2",outlet:"1HFCL8DQE0"};}
			if(value===2){result=("")||result;
			return {seg:AskHow,result:(result),preSeg:"1HF3JK1CR2",outlet:"1HFCL8DQE2"};}
			result=(input)||result;
			return {seg:SEG1HF4NEDC00,result:(result),preSeg:"1HF3JK1CR2",outlet:"1HFCL8DQE1"};
		
		};
		SEG1HF3JK1CR2.jaxId="1HF3JK1CR2"
		SEG1HF3JK1CR2.url="SEG1HF3JK1CR2@"+agentURL
		
		segs["SEG1HF4D10RK0"]=SEG1HF4D10RK0=async function(input){//:1HF4D10RK0
			let sumVO={}
			let pmsList=[]
			let result;
			await Promise.all(pmsList);
			result=JSON.stringify(sumVO,null,"\t");
			return {result:result};
		};
		SEG1HF4D10RK0.jaxId="1HF4D10RK0"
		SEG1HF4D10RK0.url="SEG1HF4D10RK0@"+agentURL
		
		segs["SEG1HF4NEDC00"]=SEG1HF4NEDC00=async function(input){//:1HF4NEDC00
			let prompt=("请确认提示词")||input;
			let placeholder=("");
			let text=(input);
			let result="";
			result=await session.askChatInput({type:"input",prompt:prompt,placeholder:placeholder,text:text});
			session.addChatText("user",result);
			return {seg:SEG1HEVKC45P2,result:(result),preSeg:"1HF4NEDC00",outlet:"1HF4NEDC10"};
		};
		SEG1HF4NEDC00.jaxId="1HF4NEDC00"
		SEG1HF4NEDC00.url="SEG1HF4NEDC00@"+agentURL
		
		agent={
			isAIAgent:true,
			session:session,
			name:"agent",
			url:agentURL,
			autoStart:true,
			jaxId:"1HDBOSUN90",
			context:context,
			livingSeg:null,
			execChat:async function(input){
				let result;
				/*#{1HDBOSUN90PreEntry*/
				/*}#1HDBOSUN90PreEntry*/
				result={seg:AskHow,"input":input};
				/*#{1HDBOSUN90PostEntry*/
				/*}#1HDBOSUN90PostEntry*/
				return result;
			},
			/*#{1HDBOSUN90MoreAgentAttrs*/
			/*}#1HDBOSUN90MoreAgentAttrs*/
		};
		/*#{1HDBOSUN90PostAgent*/
		/*}#1HDBOSUN90PostAgent*/
		return agent;
	};
	/*#{1HDBOSUN90ExCodes*/
	/*}#1HDBOSUN90ExCodes*/
	
	
	export default agent;
	export{agent};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HDBOSUN90",
//	"editVersion": 110,
//	"attrs": {
//		"editObjs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDBOSUNA0",
//			"editVersion": 2,
//			"attrs": {
//				"agent": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HDBOSUNA4",
//					"editVersion": 122,
//					"attrs": {
//						"constructArgs": {
//							"type": "object",
//							"jaxId": "1HDBOSUNB0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDBOSUNB1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"functions": {
//							"type": "object",
//							"def": "Functions",
//							"jaxId": "1HDBOSUNB2",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDBOSUNA1",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"segs": {
//			"type": "array",
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1HEQGR6G60",
//					"editVersion": 89,
//					"attrs": {
//						"id": "DrawAndTell",
//						"label": "New AI Seg",
//						"x": "0",
//						"y": "80",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGR6GC0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGR6GC1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "Please input",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEQGR6G80",
//							"editVersion": 47,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEQGR6G61"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askFile",
//					"jaxId": "1HEQDJHUP0",
//					"editVersion": 94,
//					"attrs": {
//						"id": "OpenPic",
//						"label": "New AI Seg",
//						"x": "120",
//						"y": "260",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQDJHUV0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQDJHUV1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "Please confirm",
//						"path": "",
//						"fileSys": "naive",
//						"filter": "",
//						"read": "No",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEQDJHUP2",
//							"editVersion": 46,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEQGDB1A0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1HEP4C3P80",
//					"editVersion": 89,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "140",
//						"y": "550",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEP4C3PC0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEP4C3PC1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "Please input",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEP4C3P90",
//							"editVersion": 52,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEPDGD1D0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HEP4C3P81",
//					"editVersion": 158,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "470",
//						"y": "660",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEP4C3PC2",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEP4C3PC3",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"mode": "GPT-4 Turbo",
//						"system": "你是一个提炼输入的小说文本内容，自动生成用于AI绘制图片提示词的AI。\n请尽量简短的输出图片描述。",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"type": "array",
//							"attrs": []
//						},
//						"prompt": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEP4C3P91",
//							"editVersion": 52,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"type": "array",
//							"attrs": []
//						},
//						"keepChat": "No",
//						"clearChat": "2",
//						"inputPrefix": "",
//						"inputPostfix": "",
//						"apiFiles": {
//							"type": "array",
//							"def": "FileArray",
//							"attrs": []
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HEP4C3PC6",
//					"editVersion": 116,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "700",
//						"y": "350",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEP4C3PC7",
//							"editVersion": 51,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEP4C3PC8"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HEP4C3PC8",
//					"editVersion": 76,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "180",
//						"y": "350",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEP4C3PC9",
//							"editVersion": 51,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEP4C3P80"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "summary",
//					"jaxId": "1HEPDGD1D0",
//					"editVersion": 111,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "350",
//						"y": "550",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEPDJA2F0",
//							"editVersion": 10,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEPDJA2F1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEPDGD1E0",
//							"editVersion": 48,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEPDGD1D2"
//						},
//						"async": "true",
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AISampleOutlet",
//									"jaxId": "1HEPDJA2F2",
//									"editVersion": 64,
//									"attrs": {
//										"id": "No1",
//										"condition": "",
//										"survey": "true",
//										"codes": "true",
//										"desc": "输出节点。"
//									},
//									"linkedSeg": "1HEPDGD1D1"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AISampleOutlet",
//									"jaxId": "1HEPDJA2F3",
//									"editVersion": 68,
//									"attrs": {
//										"id": "No2",
//										"condition": "",
//										"survey": "true",
//										"codes": "true",
//										"desc": "输出节点。"
//									},
//									"linkedSeg": "1HEPDGD1D1"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AISampleOutlet",
//									"jaxId": "1HEPDJA2F4",
//									"editVersion": 64,
//									"attrs": {
//										"id": "No3",
//										"condition": "",
//										"survey": "true",
//										"codes": "true",
//										"desc": "输出节点。"
//									},
//									"linkedSeg": "1HEPDGD1D1"
//								}
//							]
//						},
//						"format": "JSON"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiDraw",
//					"jaxId": "1HEPDGD1D1",
//					"editVersion": 133,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "570",
//						"y": "600",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEPDJA2F5",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEPDJA2F6",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "#input",
//						"mode": "DALL-E 3",
//						"size": "1792x1024",
//						"imgLabel": "AI Picture:",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEPDGD1F0",
//							"editVersion": 48,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1HEPDGD1D2",
//					"editVersion": 92,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "570",
//						"y": "460",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEPDJA2F7",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEPDJA2F8",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "是否生成更多图片？",
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQ90",
//									"editVersion": 52,
//									"attrs": {
//										"id": "Button1",
//										"text": "More",
//										"result": "OK",
//										"codes": "true"
//									},
//									"linkedSeg": "1HEPDJA2F9"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQ91",
//									"editVersion": 50,
//									"attrs": {
//										"id": "Button2",
//										"text": "Done",
//										"result": "Cancel",
//										"codes": "false"
//									},
//									"linkedSeg": "1HEP4C3PC6"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQ92",
//									"editVersion": 37,
//									"attrs": {
//										"id": "Button3",
//										"text": "",
//										"result": "",
//										"codes": "false"
//									}
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HEPDJA2F9",
//					"editVersion": 94,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "680",
//						"y": "400",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEPDJA2F10",
//							"editVersion": 48,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEPDJA2F11"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HEPDJA2F11",
//					"editVersion": 82,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "410",
//						"y": "400",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEPDJA2F12",
//							"editVersion": 48,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEPDGD1D0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "image",
//					"jaxId": "1HEQGDB1A0",
//					"editVersion": 74,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "290",
//						"y": "260",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGDB1G0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGDB1G1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"text": "图片:",
//						"image": "#input",
//						"role": "Assistant",
//						"sizeLimit": "",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEQGDB1C0",
//							"editVersion": 46,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEQGF1KN0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiVision",
//					"jaxId": "1HEQGF1KN0",
//					"editVersion": 90,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "460",
//						"y": "260",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGF1KS0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGF1KS1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"mode": "GPT-4VP",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"prompt": "描述一下这幅图片",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEQGF1KP0",
//							"editVersion": 46,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEQGGTHM0"
//						},
//						"secret": "false",
//						"image": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HEQGGTHM0",
//					"editVersion": 72,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "620",
//						"y": "260",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGGTHO0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGGTHO1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEQGGTHN0",
//							"editVersion": 46,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiDraw",
//					"jaxId": "1HEQGR6G61",
//					"editVersion": 77,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "270",
//						"y": "80",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGR6GC2",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGR6GC3",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "#input",
//						"mode": "DALL-E 3",
//						"size": "1024x1024",
//						"imgLabel": "AI Picture:",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEQGR6G81",
//							"editVersion": 47,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEQGR6G62"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiVision",
//					"jaxId": "1HEQGR6G62",
//					"editVersion": 87,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "450",
//						"y": "80",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGR6GC4",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGR6GC5",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"mode": "GPT-4VP",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"prompt": "描述一下这幅图片",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEQGR6G82",
//							"editVersion": 47,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEQGR6G63"
//						},
//						"secret": "false",
//						"image": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HEQGR6G63",
//					"editVersion": 73,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "630",
//						"y": "80",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGR6GC6",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQGR6GC7",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEQGR6G83",
//							"editVersion": 46,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HEQQ6LKK0",
//					"editVersion": 98,
//					"attrs": {
//						"id": "DrawGirl",
//						"label": "New AI Seg",
//						"x": "10",
//						"y": "860",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "请选择你的萝莉女友外观",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEQQ6LKL0",
//							"editVersion": 50,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEQQ6LKL1"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1HEQQ6LKL1",
//					"editVersion": 120,
//					"attrs": {
//						"id": "Hair",
//						"label": "New AI Seg",
//						"x": "210",
//						"y": "860",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS2",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS3",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "头发：",
//						"multi": "true",
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQB0",
//									"editVersion": 58,
//									"attrs": {
//										"id": "长发",
//										"text": "长发",
//										"codes": "false"
//									},
//									"linkedSeg": "1HEQQ6LKK1"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQB1",
//									"editVersion": 53,
//									"attrs": {
//										"id": "短发",
//										"text": "短发",
//										"codes": "false"
//									},
//									"linkedSeg": "1HEQQ6LKK1"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQB2",
//									"editVersion": 51,
//									"attrs": {
//										"id": "到肩",
//										"text": "到肩",
//										"codes": "false"
//									},
//									"linkedSeg": "1HEQQ6LKK1"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HEQQJ4BU0",
//									"editVersion": 57,
//									"attrs": {
//										"id": "卷发",
//										"text": "卷发",
//										"result": "",
//										"codes": "false"
//									},
//									"linkedSeg": "1HEQQ6LKK1"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1HEQQ6LKK1",
//					"editVersion": 72,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "400",
//						"y": "860",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS4",
//							"editVersion": 8,
//							"attrs": {
//								"hair": {
//									"type": "string",
//									"valText": "#input"
//								}
//							}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS5",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEQQ6LKL2",
//							"editVersion": 48,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEQQ6LKL3"
//						},
//						"result": ""
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1HEQQ6LKL3",
//					"editVersion": 102,
//					"attrs": {
//						"id": "Chest",
//						"label": "New AI Seg",
//						"x": "460",
//						"y": "1010",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS6",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS7",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "胸部",
//						"multi": "false",
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQC0",
//									"editVersion": 63,
//									"attrs": {
//										"id": "大",
//										"text": "发育良好",
//										"codes": "false"
//									},
//									"linkedSeg": "1HEQQ6LKK2"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQC1",
//									"editVersion": 67,
//									"attrs": {
//										"id": "中等",
//										"text": "中等",
//										"codes": "false"
//									},
//									"linkedSeg": "1HEQQ6LKK2"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQC2",
//									"editVersion": 52,
//									"attrs": {
//										"id": "小",
//										"text": "小",
//										"codes": "false"
//									},
//									"linkedSeg": "1HEQQ6LKK2"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1HEQQ6LKK2",
//					"editVersion": 82,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "660",
//						"y": "1010",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS8",
//							"editVersion": 8,
//							"attrs": {
//								"chest": {
//									"type": "string",
//									"valText": "#input"
//								}
//							}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS9",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEQQ6LKL4",
//							"editVersion": 48,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEQQ6LKL5"
//						},
//						"result": ""
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1HEQQ6LKL5",
//					"editVersion": 98,
//					"attrs": {
//						"id": "Cloth",
//						"label": "New AI Seg",
//						"x": "790",
//						"y": "880",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS10",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS11",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "衣服",
//						"multi": "false",
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQC3",
//									"editVersion": 55,
//									"attrs": {
//										"id": "水手校服",
//										"text": "水手校服",
//										"codes": "false"
//									},
//									"linkedSeg": "1HEQQ6LKK3"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQC4",
//									"editVersion": 53,
//									"attrs": {
//										"id": "女仆装",
//										"text": "女仆装",
//										"codes": "false"
//									},
//									"linkedSeg": "1HEQQ6LKK3"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQC5",
//									"editVersion": 52,
//									"attrs": {
//										"id": "泡泡裙",
//										"text": "泡泡裙",
//										"codes": "false"
//									},
//									"linkedSeg": "1HEQQ6LKK3"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HEQQJ4BU1",
//									"editVersion": 59,
//									"attrs": {
//										"id": "西装",
//										"text": "西装",
//										"result": "",
//										"codes": "false"
//									},
//									"linkedSeg": "1HEQQ6LKK3"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1HEQQ6LKK3",
//					"editVersion": 80,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1000",
//						"y": "880",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS12",
//							"editVersion": 8,
//							"attrs": {
//								"cloth": {
//									"type": "string",
//									"valText": "#input"
//								}
//							}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS13",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEQQ6LKM0",
//							"editVersion": 48,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEQQ6LKK4"
//						},
//						"result": ""
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiDraw",
//					"jaxId": "1HEQQ6LKK4",
//					"editVersion": 106,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1120",
//						"y": "1030",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS14",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEQQ6LKS15",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "#`一个头发长度是${context.hair}，${context.chest}胸，穿着${context.cloth}的萝莉女孩非常真实效果的照片。`",
//						"mode": "DALL-E 3",
//						"size": "1024x1024",
//						"imgLabel": "AI Picture:",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEQQ6LKM1",
//							"editVersion": 43,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "tryCatch",
//					"jaxId": "1HESQFUCA0",
//					"editVersion": 83,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "280",
//						"y": "710",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HESQFUCI0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HESQFUCI1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HESQFUCI2",
//							"editVersion": 39,
//							"attrs": {
//								"id": "Try",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEP4C3P81"
//						},
//						"catchlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HESQFUCI3",
//							"editVersion": 39,
//							"attrs": {
//								"id": "Catch",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HESR6BL30"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HESR6BL30",
//					"editVersion": 68,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "470",
//						"y": "750",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HESR6BLB0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HESR6BLB1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HESR6BL60",
//							"editVersion": 38,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askFile",
//					"jaxId": "1HEVKC45P0",
//					"editVersion": 111,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "-40",
//						"y": "1100",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEVKC4650",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEVKC4651",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "请选择参考图片",
//						"path": "",
//						"fileSys": "naive",
//						"filter": "",
//						"read": "DataURL",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEVKC45S0",
//							"editVersion": 57,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HF3JK1CR0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiVision",
//					"jaxId": "1HEVKC45P1",
//					"editVersion": 119,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "170",
//						"y": "1290",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEVKC4652",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEVKC4653",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"mode": "GPT-4VP",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"prompt": "#`请参考这个图片的风格，生成绘制${context.req}的Prompt。你的输出应该仅包含Prompt，不要有其它多余的文字`",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEVKC45S1",
//							"editVersion": 52,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HF3JK1CR1"
//						},
//						"secret": "false",
//						"image": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiDraw",
//					"jaxId": "1HEVKC45P2",
//					"editVersion": 140,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "810",
//						"y": "1170",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEVKC4654",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEVKC4655",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "#input",
//						"mode": "DALL-E 3",
//						"size": "1024x1024",
//						"imgLabel": "AI Picture:",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEVKC45S2",
//							"editVersion": 38,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiTTS",
//					"jaxId": "1HEVKC45P3",
//					"editVersion": 76,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "210",
//						"y": "160",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEVKC4656",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEVKC4657",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"mode": "Open AI TTS-1",
//						"text": "#input",
//						"voice": "Alloy",
//						"ttsLabel": "语音:",
//						"showBlock": "true",
//						"autoPlay": "true",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEVKC45T0",
//							"editVersion": 38,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1HEVKC45P4",
//					"editVersion": 127,
//					"attrs": {
//						"id": "AskHow",
//						"label": "New AI Seg",
//						"x": "-180",
//						"y": "1240",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEVKC4658",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HEVKC4660",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"prompt": "你想话什么东西？",
//						"placeholder": "想画的东西",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HEVKC45T1",
//							"editVersion": 63,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEVKC45P0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "image",
//					"jaxId": "1HF3JK1CR0",
//					"editVersion": 78,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "1190",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HF3JK1D60",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HF3JK1D61",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"text": "图片:",
//						"image": "#input",
//						"role": "Assistant",
//						"sizeLimit": "512",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HF3JK1CT0",
//							"editVersion": 32,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEVKC45P1"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HF3JK1CR1",
//					"editVersion": 57,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "290",
//						"y": "1190",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HF3JK1D62",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HF3JK1D63",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HF3JK1CT1",
//							"editVersion": 31,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HF3JK1CR2"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1HF3JK1CR2",
//					"editVersion": 89,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "470",
//						"y": "1280",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HF3JK1D64",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HF3JK1D65",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "是否使用这个提示绘制？",
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQE0",
//									"editVersion": 44,
//									"attrs": {
//										"id": "绘制",
//										"text": "绘制",
//										"result": "#input",
//										"codes": "false"
//									},
//									"linkedSeg": "1HEVKC45P2"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQE1",
//									"editVersion": 47,
//									"attrs": {
//										"id": "修改提示",
//										"text": "重新生成提示",
//										"result": "#input",
//										"codes": "false"
//									},
//									"linkedSeg": "1HF4NEDC00"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HFCL8DQE2",
//									"editVersion": 36,
//									"attrs": {
//										"id": "重新选择图片",
//										"text": "重新选择图片",
//										"result": "",
//										"codes": "false"
//									},
//									"linkedSeg": "1HF3JK1D66"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HF3JK1D66",
//					"editVersion": 58,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "620",
//						"y": "1470",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HF3JK1D67",
//							"editVersion": 25,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HF3JK1D68"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HF3JK1D68",
//					"editVersion": 62,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "-140",
//						"y": "1470",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HF3JK1D69",
//							"editVersion": 25,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEVKC45P4"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "summary",
//					"jaxId": "1HF4D10RK0",
//					"editVersion": 42,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "-20",
//						"y": "990",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HF4D10RU0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HF4D10RU1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HF4D10RL0",
//							"editVersion": 8,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。"
//							}
//						},
//						"async": "true",
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AISampleOutlet",
//									"jaxId": "1HF4D10RU2",
//									"editVersion": 14,
//									"attrs": {
//										"id": "Sample",
//										"condition": "",
//										"survey": "true",
//										"codes": "false",
//										"desc": "输出节点。"
//									}
//								},
//								{
//									"type": "aioutlet",
//									"def": "AISampleOutlet",
//									"jaxId": "1HF4D10RU3",
//									"editVersion": 14,
//									"attrs": {
//										"id": "Sample",
//										"condition": "",
//										"survey": "true",
//										"codes": "false",
//										"desc": "输出节点。"
//									}
//								},
//								{
//									"type": "aioutlet",
//									"def": "AISampleOutlet",
//									"jaxId": "1HF4D10RU4",
//									"editVersion": 14,
//									"attrs": {
//										"id": "Sample",
//										"condition": "",
//										"survey": "true",
//										"codes": "false",
//										"desc": "输出节点。"
//									}
//								}
//							]
//						},
//						"format": "JSON"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1HF4NEDC00",
//					"editVersion": 52,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "690",
//						"y": "1280",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HF4NEDCB0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HF4NEDCB1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "请确认提示词",
//						"placeholder": "",
//						"text": "#input",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HF4NEDC10",
//							"editVersion": 4,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HEVKC45P2"
//						}
//					}
//				}
//			]
//		},
//		"entry": "AskHow",
//		"autoStart": "true",
//		"debug": "true",
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDBOSUNA2",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"context": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDBOSUNA3",
//			"editVersion": 58,
//			"attrs": {
//				"req": {
//					"type": "string",
//					"valText": ""
//				},
//				"hair": {
//					"type": "string",
//					"valText": "长发"
//				},
//				"chest": {
//					"type": "string",
//					"valText": "大"
//				},
//				"body": {
//					"type": "string",
//					"valText": "偏瘦"
//				},
//				"cloth": {
//					"type": "string",
//					"valText": "水手服"
//				}
//			}
//		},
//		"globalMockup": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDIJB7SK6",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"desc": "这是一个AI代理。"
//	}
//}