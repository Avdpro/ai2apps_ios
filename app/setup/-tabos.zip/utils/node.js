import process from "/@process";
import {Buffer} from "/@buffer"
window.global=window;
global.process=process;
global.Buffer=Buffer;