import {VFACT} from "/@vfact";
import {} from "/@vfact/vfact_app.js";
import {UIView} from "/~/editkit_dev/ui/UIView.js";
import {MainUI} from "./temp/MainUI.js";
async function startApp() {
	let app,uiDef;
	window.tabOSApp=app=await VFACT.createApp();
	uiDef=UIView(MainUI);
	await VFACT.initApp(app,uiDef,{});
}
startApp();
