//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
import {BtnText} from "./BtnText.js";
/*#{1H1T7ISV50StartDoc*/
/*}#1H1T7ISV50StartDoc*/
//----------------------------------------------------------------------------
let DialogTemplate=function(title,closeIcon,buttons){
	let $ln,cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	let txtTitle,boxContent,boxButtons,btnYes,btnNo,btn3rd;
	
	$ln=appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7ISV51LocalVals*/
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	state={
		"title":title,"buttons":buttons,
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":10,"y":"30%","w":360,"h":"","padding":10,"styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","background":cfgColor.body,"border":2,"borderColor":cfgColor["fontBodySub"],
				"corner":5,"shadow":true,"shadowX":3,"shadowY":6,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T84P6A0",
				"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","x":">calc(100% - 36px)","y":5,"display":!!closeIcon,"padding":3,
				"attached":!!closeIcon,
				"OnClick":function(event){
					/*#{1H1T8K68O0FunctionBody*/
					/*}#1H1T8K68O0FunctionBody*/
				},
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,10,0],"styleClass":"","color":cfgColor.fontBodySub,
				"text":$P(()=>(state.title),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":"","minH":30,"styleClass":"",
				children:[
					{
						"hash":"1H1T8B4370",
						"type":"text","id":"TxtMockup","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","color":cfgColor.fontBodyLit,"text":"Add your components here.",
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
					}
				],
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":0,"styleClass":"","contentLayout":"flex-x",
				"subAlign":2,"attached":!!buttons,
				children:[
					{
						"hash":"1H1T802O00",
						"type":BtnText("primary",80,24,state.buttons[1]||"OK",false,""),"id":"BtnYes","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1H1T8J6TN0FunctionBody*/
							/*}#1H1T8J6TN0FunctionBody*/
						},
					},
					{
						"hash":"1H1T820FU0",
						"type":BtnText("warning",80,24,state.buttons[0]||"Cancel",false,""),"id":"BtnNo","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1H1T8JJRK0FunctionBody*/
							/*}#1H1T8JJRK0FunctionBody*/
						},
					},
					{
						"hash":"1H25185U60",
						"type":BtnText("secondary",80,24,state.buttons[2],false,""),"id":"Btn3rd","position":"relative","x":0,"y":"50%","display":!!(buttons&&buttons[2]),
						"anchorY":1,"attached":!!(buttons&&buttons[2]),
						"OnClick":function(event){
							/*#{1H25185U72FunctionBody*/
							/*}#1H25185U72FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContent=self.BoxContent;boxButtons=self.BoxButtons;btnYes=self.BtnYes;btnNo=self.BtnNo;btn3rd=self.Btn3rd;
			/*#{1H1T7ISV51Create*/
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	/*}#1H1T7ISV51PostCSSVO*/
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/

DialogTemplate.gearExport={
	framework: "jax",
	hudType: "hud",
	showName:"Standard Dialog",icon:"gears.svg",previewImg:"false",
	fixPose:false,initW:360,initH:500,
	catalog:"",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Dialog title", "localizable": true
		}, 
		"closeIcon": {
			"name": "closeIcon", "showName": "closeIcon", "type": "bool", "key": true, "fixed": true, "initVal": false, "localizable": undefined
		}, 
		"buttons": {
			"name": "buttons", "showName": "buttons", "type": "auto", "key": true, "fixed": true, 
			"initVal": [], "localizable": undefined
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","display"],
	faces:[
	],
	subContainers:{
		"1H1T7S0BE0":{"showName":"BoxContent"}
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1T7ISV50ExGearInfo*/
	/*}#1H1T7ISV50ExGearInfo*/
};
export default DialogTemplate;
export{DialogTemplate};