//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1LSJKOO0StartDoc*/
/*}#1H1LSJKOO0StartDoc*/
//----------------------------------------------------------------------------
let BoxRange=function(value,minVal,maxVal){
	let $ln,cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	let btnDrag,boxBtn;
	
	$ln=appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1LSJKOO1LocalVals*/
	/*}#1H1LSJKOO1LocalVals*/
	
	/*#{1H1LSJKOO1PreState*/
	/*}#1H1LSJKOO1PreState*/
	state={
		"buttonSize":20,"barSize":8,"value":value,"min":minVal,"max":maxVal,"step":1,"valColor":cfgColor.primary,"enable":true,
		/*#{1H1LSJKOO6ExState*/
		/*}#1H1LSJKOO6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1LSJKOO1PostState*/
	/*}#1H1LSJKOO1PostState*/
	cssVO={
		"hash":"1H1LSJKOO1",nameHost:true,
		"type":"hud","x":125,"y":182,"w":100,"h":20,"alpha":$P(()=>(state.enable?1:0.6),state),"styleClass":"",
		"trackSize":true,
		children:[
			{
				"hash":"1H1LSR12R0",
				"type":"box","id":"BoxTrack","x":5,"y":"50%","w":">calc(100% - 10px)","h":$P(()=>(state.barSize),state),"anchorY":1,"styleClass":"","background":[0,0,0,0],
				"border":1,"borderColor":cfgColor.fontBody,"corner":100,
				children:[
					{
						"hash":"1H1LTEIBS0",
						"type":"box","id":"BoxValue","x":0,"y":0,"w":$P(()=>(((state.value-state.min)/(state.max-state.min)*100)+"%"),state),"h":"100%","styleClass":"",
						"background":$P(()=>(state.valColor),state),"corner":[100,0,0,100],
						"OnClick":function(event){
							/*#{1H2E5TECE0FunctionBody*/
							/*}#1H2E5TECE0FunctionBody*/
						},
					}
				],
				"OnClick":function(event){
					/*#{1H2E5T5950FunctionBody*/
					/*}#1H2E5T5950FunctionBody*/
				},
			},
			{
				"hash":"1H2E6IVF70",
				"type":"button","id":"BtnDrag","x":$P(()=>(`(FW-${state.buttonSize})*${(state.value-state.min)/(state.max-state.min)}`),state),"y":"50%","w":$P(()=>(state.buttonSize),state),
				"h":$P(()=>(state.buttonSize),state),"anchorY":1,"cursor":"pointer","styleClass":"","drag":2,
				children:[
					{
						"hash":"1H2E6L0B10",
						"type":"box","id":"BoxBtn","x":0,"y":0,"w":$P(()=>(state.buttonSize),state),"h":$P(()=>(state.buttonSize),state),"uiEvent":-1,"styleClass":"","background":cfgColor.body,
						"border":1,"borderColor":cfgColor.fontBody,"corner":100,
					}
				],
				/*#{1H2E6IVF70Codes*/
				/*}#1H2E6IVF70Codes*/
			}
		],
		get $$value(){return state["value"]},
		set $$value(v){
			state["value"]=v;
			/*#{1H1LSJKOO1Setvalue*/
			/*}#1H1LSJKOO1Setvalue*/
		},
		get $$min(){return state["min"]},
		set $$min(v){
			state["min"]=v;
			/*#{1H1LSJKOO1Setmin*/
			/*}#1H1LSJKOO1Setmin*/
		},
		get $$max(){return state["max"]},
		set $$max(v){
			state["max"]=v;
			/*#{1H1LSJKOO1Setmax*/
			/*}#1H1LSJKOO1Setmax*/
		},
		get $$step(){return state["step"]},
		set $$step(v){
			state["step"]=v;
			/*#{1H1LSJKOO1Setstep*/
			/*}#1H1LSJKOO1Setstep*/
		},
		get $$enable(){return state["enable"]},
		set $$enable(v){
			state["enable"]=v;
			/*#{1H1LSJKOO1Setenable*/
			/*}#1H1LSJKOO1Setenable*/
		},
		get $$barSize(){return state["barSize"]},
		set $$barSize(v){
			state["barSize"]=v;
			/*#{1H1LSJKOO1SetbarSize*/
			/*}#1H1LSJKOO1SetbarSize*/
		},
		get $$buttonSize(){return state["buttonSize"]},
		set $$buttonSize(v){
			state["buttonSize"]=v;
			/*#{1H1LSJKOO1SetbuttonSize*/
			/*}#1H1LSJKOO1SetbuttonSize*/
		},
		get $$valColor(){return state["valColor"]},
		set $$valColor(v){
			state["valColor"]=v;
			/*#{1H1LSJKOO1SetvalColor*/
			/*}#1H1LSJKOO1SetvalColor*/
		},
		/*#{1H1LSJKOO1ExtraCSS*/
		/*}#1H1LSJKOO1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			btnDrag=self.BtnDrag;boxBtn=self.BoxBtn;
			/*#{1H1LSJKOO1Create*/
			/*}#1H1LSJKOO1Create*/
		},
		/*#{1H1LSJKOO1EndCSS*/
		/*}#1H1LSJKOO1EndCSS*/
	};
	/*#{1H1LSJKOO1PostCSSVO*/
	/*}#1H1LSJKOO1PostCSSVO*/
	return cssVO;
};
/*#{1H1LSJKOO1ExCodes*/
/*}#1H1LSJKOO1ExCodes*/

BoxRange.gearExport={
	framework: "jax",
	hudType: "hud",
	showName:"Value Bar",icon:"gears.svg",previewImg:"false",
	fixPose:false,initW:100,initH:100,
	desc:"Draggable value bar",
	catalog:"Inputs",
	args: {
		"value": {
			"name": "value", "showName": "value", "type": "number", "key": true, "fixed": true, "initVal": 100, "localizable": undefined
		}, 
		"minVal": {
			"name": "minVal", "showName": "minVal", "type": "number", "key": true, "fixed": true, "initVal": 0, "localizable": undefined
		}, 
		"maxVal": {
			"name": "maxVal", "showName": "maxVal", "type": "number", "key": true, "fixed": true, "initVal": 100, "localizable": undefined
		}
	},
	state:{
		value:{name:"value",type:"number",initVal:100},
		min:{name:"min",type:"number",initVal:0},
		max:{name:"max",type:"number",initVal:100},
		step:{name:"step",type:"number",initVal:1},
		enable:{name:"enable",type:"bool",initVal:true},
		barSize:{name:"barSize",type:"int",initVal:8},
		buttonSize:{name:"buttonSize",type:"int",initVal:20},
		valColor:{name:"valColor",type:"colorRGBA",initVal:[13,110,253,1]}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","minW","minH","maxW","maxH","attach"],
	faces:[
	],
	subContainers:{
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1LSJKOO0ExGearInfo*/
	/*}#1H1LSJKOO0ExGearInfo*/
};
export default BoxRange;
export{BoxRange};