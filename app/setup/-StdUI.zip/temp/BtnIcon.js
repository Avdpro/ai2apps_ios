//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1KJQ5RK0StartDoc*/
/*}#1H1KJQ5RK0StartDoc*/
//----------------------------------------------------------------------------
let BtnIcon=function(style,w,h,icon,colorBG){
	let $ln,cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	$ln=appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let color=Array.isArray(style)?(style):(cfgColor[style]);
	
	/*#{1H1KJQ5RK1LocalVals*/
	/*}#1H1KJQ5RK1LocalVals*/
	
	/*#{1H1KJQ5RK1PreState*/
	/*}#1H1KJQ5RK1PreState*/
	state={
		"corner":3,"border":0,
		/*#{1H1KJQ5RK6ExState*/
		/*}#1H1KJQ5RK6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1KJQ5RK1PostState*/
	/*}#1H1KJQ5RK1PostState*/
	cssVO={
		"hash":"1H1KJQ5RK1",nameHost:true,
		"type":"button","x":0,"y":0,"w":w,"h":h||w,"cursor":"pointer","styleClass":"",
		children:[
			{
				"hash":"1H1KK7EMK0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"styleClass":"","background":colorBG||[0,0,0,0],"border":$P(()=>(state.border||0),state),
				"borderColor":color,"corner":$P(()=>(state.corner),state),
			},
			{
				"hash":"1H1KKD55C0",
				"type":"box","position":"relative","x":"50%","y":"50%","w":"100%","h":"100%","anchorX":1,"anchorY":1,"uiEvent":-1,"margin":[0,3,0,0],"styleClass":"",
				"background":color,"attached":icon,"maskImage":icon,
			}
		],
		get $$border(){return state["border"]},
		set $$border(v){
			state["border"]=v;
			/*#{1H1KJQ5RK1Setborder*/
			/*}#1H1KJQ5RK1Setborder*/
		},
		get $$corner(){return state["corner"]},
		set $$corner(v){
			state["corner"]=v;
			/*#{1H1KJQ5RK1Setcorner*/
			/*}#1H1KJQ5RK1Setcorner*/
		},
		/*#{1H1KJQ5RK1ExtraCSS*/
		/*}#1H1KJQ5RK1ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG||[0,0,0,0],"y":0,"borderColor":cfgColor[style]
				},
				"#1H1KKD55C0":{
					"background":color,"y":"50%","w":"100%","h":"100%"
				}
			},"over":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.5]):([color[0],color[1],color[2],color[3]*0.25]),"y":0
				},
				"#1H1KKD55C0":{
					"background":color,"y":"50%","w":"100%","h":"100%"
				}
			},"down":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.25]):([color[0],color[1],color[2],color[3]*0.15]),"y":0
				},
				"#1H1KKD55C0":{
					"background":color,"w":">calc(100% - 2px)","h":">calc(100% - 2px)"
				}
			},"gray":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":colorBG?([colorBG[0],colorBG[1],colorBG[2],colorBG[3]*0.5]):[0,0,0,0],"borderColor":cfgColor["itemGray"]
				},
				"#1H1KKD55C0":{
					"background":[color[0],color[1],color[2],color[3]*0.25],"w":"100%","h":"100%"
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H1KJQ5RK1Create*/
			/*}#1H1KJQ5RK1Create*/
		},
		/*#{1H1KJQ5RK1EndCSS*/
		/*}#1H1KJQ5RK1EndCSS*/
	};
	/*#{1H1KJQ5RK1PostCSSVO*/
	/*}#1H1KJQ5RK1PostCSSVO*/
	return cssVO;
};
/*#{1H1KJQ5RK1ExCodes*/
/*}#1H1KJQ5RK1ExCodes*/

BtnIcon.gearExport={
	framework: "jax",
	hudType: "button",
	showName:"Icon Button",icon:"btn_icon.svg",previewImg:false,
	fixPose:false,initW:30,initH:30,
	desc:"Icon button",
	catalog:"Buttons",
	args: {
		"style": {
			"name": "style", "showName": "style", "type": "auto", "key": true, "fixed": true, "initVal": "front"
		}, 
		"w": {
			"name": "w", "showName": "w", "type": "int", "key": true, "fixed": true, "initVal": 30
		}, 
		"h": {
			"name": "h", "showName": "h", "type": "int", "key": true, "fixed": true, "initVal": 0
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/lab.svg"
		}, 
		"colorBG": {
			"name": "colorBG", "showName": "colorBG", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
		border:{name:"border",type:"int",initVal:0},
		corner:{name:"corner",type:"int",initVal:3}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","margin","padding","enable","drag","attach"],
	faces:[
		{name:"up",entry:false,next:"",desc:"",time:0},
		{name:"over",entry:false,next:"",desc:"",time:0},
		{name:"down",entry:false,next:"",desc:"",time:0},
		{name:"gray",entry:false,next:"",desc:"",time:0}
	],
	subContainers:{
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1KJQ5RK0ExGearInfo*/
	/*}#1H1KJQ5RK0ExGearInfo*/
};
export default BtnIcon;
export{BtnIcon};