//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1H2CQBSVI0StartDoc*/
/*}#1H2CQBSVI0StartDoc*/
//----------------------------------------------------------------------------
let NaviTop=function(title,bgColor,color,logoIcon,menuIcon,menuItems){
	let $ln,cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	let naviItems,itemsRight;
	
	$ln=appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7DITA1LocalVals*/
	/*}#1H1T7DITA1LocalVals*/
	
	/*#{1H1T7DITA1PreState*/
	/*}#1H1T7DITA1PreState*/
	/*#{1H1T7DITA1PostState*/
	/*}#1H1T7DITA1PostState*/
	cssVO={
		"hash":"1H1T7DITA1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":40,"padding":[5,35,5,5],"styleClass":"","contentLayout":"flex-x","traceSize":true,
		children:[
			{
				"hash":"1H1TB73370",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","padding":5,"styleClass":"","background":bgColor,"contentLayout":"flex-x",
			},
			{
				"hash":"1H1TBM5HJ0",
				"type":BtnIcon(color,30,0,logoIcon,null),"id":"BtnHome","position":"relative","x":0,"y":0,"border":0,
				"OnClick":function(event){
					/*#{1H1TNA1270FunctionBody*/
					/*}#1H1TNA1270FunctionBody*/
				},
			},
			{
				"hash":"1H1TBHQJ30",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"","h":"100%","styleClass":"","color":color,"text":title,"fontSize":txtSize.big,
				"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1H1TBOLJK0",
				"type":BtnIcon(color,30,0,menuIcon,null),"id":"BtnMenu","x":">calc(100% - 5px)","y":"50%","anchorX":2,"anchorY":1,
				"OnClick":function(event){
					/*#{1H1TM72AV0FunctionBody*/
					/*}#1H1TM72AV0FunctionBody*/
				},
			},
			{
				"hash":"1H2CQI73O0",
				"type":"hud","id":"NaviItems","position":"relative","x":0,"y":0,"w":20,"h":"100%","margin":[0,0,0,20],"styleClass":"","flex":true,"contentLayout":"flex-x",
			},
			{
				"hash":"1H2CQTOQC0",
				"type":"hud","id":"ItemsRight","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":10,"styleClass":"","contentLayout":"flex-x",
			}
		],
		/*#{1H1T7DITA1ExtraCSS*/
		/*}#1H1T7DITA1ExtraCSS*/
		faces:{
			"desktop":{
				/*NaviItems*/"#1H2CQI73O0":{
					"display":1
				},
				/*ItemsRight*/"#1H2CQTOQC0":{
					"display":1
				},
				/*#{1H1TBU4LI0Code*/
				/*}#1H1TBU4LI0Code*/
			},"mobile":{
				/*NaviItems*/"#1H2CQI73O0":{
					"display":0
				},
				/*ItemsRight*/"#1H2CQTOQC0":{
					"display":0
				},
				/*#{1H1TBU4LI2Code*/
				/*}#1H1TBU4LI2Code*/
			}
		},
		OnCreate:function(){
			self=this;
			naviItems=self.NaviItems;itemsRight=self.ItemsRight;
			/*#{1H1T7DITA1Create*/
			/*}#1H1T7DITA1Create*/
		},
		/*#{1H1T7DITA1EndCSS*/
		/*}#1H1T7DITA1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnSize=function(){
		/*#{1H5RDNHI30FunctionBody*/
		/*}#1H5RDNHI30FunctionBody*/
	};
	/*#{1H1T7DITA1PostCSSVO*/
	/*}#1H1T7DITA1PostCSSVO*/
	return cssVO;
};
/*#{1H1T7DITA1ExCodes*/
/*}#1H1T7DITA1ExCodes*/

NaviTop.gearExport={
	framework: "jax",
	hudType: "hud",
	showName:"Top Navi Bar",icon:"gears.svg",previewImg:"./NaviTop.png",
	fixPose:true,initW:500,initH:60,
	desc:"Simple web site header, support both motile and desktop mode.",
	catalog:"Views",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Cool Site Name", "localizable": true
		}, 
		"bgColor": {
			"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [108,117,125,1]
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [255,255,255,1]
		}, 
		"logoIcon": {
			"name": "logoIcon", "showName": "logoIcon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/cklogo.svg"
		}, 
		"menuIcon": {
			"name": "menuIcon", "showName": "menuIcon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/menu.svg"
		}, 
		"menuItems": {
			"name": "menuItems", "showName": "menuItems", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[
		{name:"desktop",entry:false,next:"",desc:"",time:0},
		{name:"mobile",entry:false,next:"",desc:"",time:0}
	],
	subContainers:{
		"1H2CQI73O0":{"showName":"NaviItems","contentLayout":"flex-x"},
		"1H2CQTOQC0":{"showName":"ItemsRight","contentLayout":"flex-x"}
	},
	deviceW:800,
	deviceH:750,
	/*#{1H2CQBSVI0ExGearInfo*/
	/*}#1H2CQBSVI0ExGearInfo*/
};
export default NaviTop;
export{NaviTop};