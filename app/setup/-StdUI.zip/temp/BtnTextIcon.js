//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1RPOAH90StartDoc*/
/*}#1H1RPOAH90StartDoc*/
//----------------------------------------------------------------------------
let BtnTextIcon=function(w,h,icon,color,hasMark,hasCheck,text){
	let $ln,cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	let boxMark;
	
	$ln=appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1KJQ5RK1LocalVals*/
	/*}#1H1KJQ5RK1LocalVals*/
	
	/*#{1H1KJQ5RK1PreState*/
	/*}#1H1KJQ5RK1PreState*/
	state={
		"corner":3,"border":false,"text":text,"fontSize":txtSize.small,"markNum":1,
		/*#{1H1KJQ5RK6ExState*/
		/*}#1H1KJQ5RK6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1KJQ5RK1PostState*/
	/*}#1H1KJQ5RK1PostState*/
	cssVO={
		"hash":"1H1KJQ5RK1",nameHost:true,
		"type":"button","x":26,"y":15,"w":"","h":h||w,"cursor":"pointer","padding":[0,3,0,3],"minW":w,"styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1KK7EMK0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"styleClass":"","background":[0,0,0,0],"borderColor":color,"corner":$P(()=>(state.corner),state),
			},
			{
				"hash":"1H60UF7OR0",
				"type":"hud","position":"relative","x":"50%","y":0,"w":w-15,"h":(h||w)-15,"anchorX":1,"uiEvent":-1,"styleClass":"",
				children:[
					{
						"hash":"1H60UGMSN0",
						"type":"box","position":"relative","x":"50%","y":0,"w":(h||w)-15,"h":(h||w)-15,"anchorX":1,"uiEvent":-1,"alpha":hasCheck?0.5:1,"margin":[0,3,0,0],
						"styleClass":"","background":color,"attached":icon,"maskImage":icon,
					},
					{
						"hash":"1H60ULCF00",
						"type":"hud","id":"Overlays","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"styleClass":"",
					},
					{
						"hash":"1H60UO9EL0",
						"type":"box","id":"BoxMark","x":"100%","y":0,"w":"","h":"","anchorX":1,"display":$P(()=>(!!state.markNum),state),"padding":[2,5,2,5],"minW":15,"styleClass":"",
						"background":cfgColor.error,"corner":100,"contentLayout":"flex-x","subAlign":1,"attached":!!hasMark,
						children:[
							{
								"hash":"1H60UO9EM0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","styleClass":"","color":cfgColor.fontError,"text":$P(()=>(state.markNum),state),
								"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							}
						],
					}
				],
			},
			{
				"hash":"1H1RPTGKE0",
				"type":"text","position":"relative","x":"50%","y":0,"w":"","h":"","anchorX":1,"alpha":hasCheck?0.5:1,"styleClass":"","color":color,"text":$P(()=>(state.text),state),
				"fontSize":$P(()=>(state.fontSize),state),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
			}
		],
		get $$markNum(){return state["markNum"]},
		set $$markNum(v){
			state["markNum"]=v;
			/*#{1H1KJQ5RK1SetmarkNum*/
			/*}#1H1KJQ5RK1SetmarkNum*/
		},
		/*#{1H1KJQ5RK1ExtraCSS*/
		/*}#1H1KJQ5RK1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H1KK1Q1R0PreCode*/
				/*}#1H1KK1Q1R0PreCode*/
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":[0,0,0,0],"y":0,"borderColor":color
				},
				"#1H60UGMSN0":{
					"background":color,"y":0,"alpha":hasCheck?0.5:1
				},
				"#1H1RPTGKE0":{
					"color":color,"alpha":hasCheck?0.5:1
				}
			},"over":{
				/*#{1H1KK1SU60PreCode*/
				/*}#1H1KK1SU60PreCode*/
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":cfgColor.itemOver,"y":0,"alpha":1
				},
				"#1H60UGMSN0":{
					"background":color,"y":0,"alpha":1
				},
				"#1H1RPTGKE0":{
					"color":color,"alpha":1
				}
			},"down":{
				/*#{1H1KK1M7O0PreCode*/
				/*}#1H1KK1M7O0PreCode*/
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":cfgColor.itemDown,"y":1
				},
				"#1H60UGMSN0":{
					"background":color,"y":1,"alpha":1
				},
				"#1H1RPTGKE0":{
					"color":color,"alpha":1
				}
			},"gray":{
				/*#{1H1KK26UE3PreCode*/
				/*}#1H1KK26UE3PreCode*/
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":[0,0,0,0],"borderColor":cfgColor["itemGray"]
				},
				"#1H60UGMSN0":{
					"background":color,"alpha":0.3
				},
				"#1H1RPTGKE0":{
					"color":color,"alpha":0.3
				}
			},"focus":{
				/*BoxBG*/"#1H1KK7EMK0":{
					"background":[0,0,0,0]
				},
				"#1H60UGMSN0":{
					"alpha":1
				},
				"#1H1RPTGKE0":{
					"alpha":1
				},
				/*#{1H1UIV5040Code*/
				/*}#1H1UIV5040Code*/
			},"blur":{
				"#1H60UGMSN0":{
					"alpha":0.5
				},
				"#1H1RPTGKE0":{
					"alpha":0.5
				},
				/*#{1H1UIVME70Code*/
				/*}#1H1UIVME70Code*/
			}
		},
		OnCreate:function(){
			self=this;
			boxMark=self.BoxMark;
			/*#{1H1KJQ5RK1Create*/
			/*}#1H1KJQ5RK1Create*/
		},
		/*#{1H1KJQ5RK1EndCSS*/
		/*}#1H1KJQ5RK1EndCSS*/
	};
	/*#{1H1KJQ5RK1PostCSSVO*/
	/*}#1H1KJQ5RK1PostCSSVO*/
	return cssVO;
};
/*#{1H1KJQ5RK1ExCodes*/
/*}#1H1KJQ5RK1ExCodes*/

BtnTextIcon.gearExport={
	framework: "jax",
	hudType: "button",
	showName:"Icon with Text",icon:"btn_icon.svg",previewImg:"./IconText.png",
	fixPose:false,initW:40,initH:40,
	desc:"Icon button with a text footer, a optional message number mark.",
	catalog:"Buttons",
	args: {
		"w": {
			"name": "w", "showName": "w", "type": "int", "key": true, "fixed": true, "initVal": 48
		}, 
		"h": {
			"name": "h", "showName": "h", "type": "int", "key": true, "fixed": true, "initVal": 48
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/lab.svg"
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [0,0,0,1]
		}, 
		"hasMark": {
			"name": "hasMark", "showName": "hasMark", "type": "bool", "key": true, "fixed": true, "initVal": false
		}, 
		"hasCheck": {
			"name": "hasCheck", "showName": "hasCheck", "type": "bool", "key": true, "fixed": true, "initVal": false
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Icon button", "localizable": true
		}
	},
	state:{
		markNum:{name:"markNum",type:"int",initVal:1}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","margin","enable","attach"],
	faces:[
		{name:"up",entry:false,next:"",desc:"",time:0},
		{name:"over",entry:false,next:"",desc:"",time:0},
		{name:"down",entry:false,next:"",desc:"",time:0},
		{name:"gray",entry:false,next:"",desc:"",time:0},
		{name:"focus",entry:false,next:"",desc:"",time:0},
		{name:"blur",entry:false,next:"",desc:"",time:0}
	],
	subContainers:{
		"1H60ULCF00":{"showName":"Overlays"}
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1RPOAH90ExGearInfo*/
	/*}#1H1RPOAH90ExGearInfo*/
};
export default BtnTextIcon;
export{BtnTextIcon};