//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1O4B7OK0StartDoc*/
/*}#1H1O4B7OK0StartDoc*/
//----------------------------------------------------------------------------
let BtnObject=function(obj,converter){
	let $ln,cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	$ln=appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1O4B7OK1LocalVals*/
	/*}#1H1O4B7OK1LocalVals*/
	
	/*#{1H1O4B7OK1PreState*/
	/*}#1H1O4B7OK1PreState*/
	state={
		"fontSize":txtSize.smallPlus,
		/*#{1H1O4B7OL4ExState*/
		/*}#1H1O4B7OL4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1O4B7OK1PostState*/
	/*}#1H1O4B7OK1PostState*/
	cssVO={
		"hash":"1H1O4B7OK1",nameHost:true,
		"type":"button","x":0,"y":0,"w":"100%","h":24,"padding":[0,5,0,5],"styleClass":"","enable":obj.enable===false?false:true,"contentLayout":"flex-x","traceSize":true,
		"obj":obj,
		children:[
			{
				"hash":"1H1O6BJ290",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","background":[0,0,0,0],
			},
			{
				"hash":"1H1O5PAKH0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"50%","w":"FH-4","h":"FH-4","anchorY":1,"autoLayout":true,"margin":[0,3,0,0],"styleClass":"",
				"background":obj.iconColor||obj.color||cfgColor.fontBody,"attached":(!!obj.icon)||(obj.icon===""),"maskImage":obj.icon,
			},
			{
				"hash":"1H1O5T0HD0",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":"100%","styleClass":"","color":obj.color||cfgColor.fontBody,"text":obj.text,
				"fontSize":$P(()=>(state.fontSize),state),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1H1O640F30",
				"type":"box","id":"BoxCheck","x":">calc(100% - 5px)","y":"50%","w":"FH-6","h":"FH-6","anchorX":2,"anchorY":1,"display":!!obj.check,"styleClass":"",
				"background":obj.color||cfgColor.fontBody,"border":1,"maskImage":appCfg.sharedAssets+"/check_fat.svg","attached":("check" in obj),
			}
		],
		get $$fontSize(){return state["fontSize"]},
		set $$fontSize(v){
			state["fontSize"]=v;
			/*#{1H1O4B7OK1SetfontSize*/
			/*}#1H1O4B7OK1SetfontSize*/
		},
		/*#{1H1O4B7OK1ExtraCSS*/
		/*}#1H1O4B7OK1ExtraCSS*/
		faces:{
			"up":{
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":[0,0,0,0]
				}
			},"over":{
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemOver"]
				}
			},"down":{
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemDown"]
				}
			},"gray":{
				"#self":{
					"alpha":0.5
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":[0,0,0,0]
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H1O4B7OK1Create*/
			/*}#1H1O4B7OK1Create*/
		},
		/*#{1H1O4B7OK1EndCSS*/
		/*}#1H1O4B7OK1EndCSS*/
	};
	/*#{1H1O4B7OK1PostCSSVO*/
	/*}#1H1O4B7OK1PostCSSVO*/
	return cssVO;
};
/*#{1H1O4B7OK1ExCodes*/
/*}#1H1O4B7OK1ExCodes*/

BtnObject.gearExport={
	framework: "jax",
	hudType: "button",
	showName:"Object Line",icon:"gears.svg",previewImg:"false",
	fixPose:false,initW:100,initH:24,
	catalog:"",
	args: {
		"obj": {
			"name": "obj", "showName": "obj", "type": "auto", "key": true, "fixed": true, 
			"initVal": {
				"text": "Object", "icon": "", "iconColor": [255,0,0,1], "check": true, "enable": false
			}, 
			"localizable": undefined
		}, 
		"converter": {
			"name": "converter", "showName": "converter", "type": "auto", "key": true, "fixed": true, 
			"initVal": null, "localizable": undefined
		}
	},
	state:{
		fontSize:{name:"fontSize",type:"int",initVal:14}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","rotate","scale","cursor","zIndex","margin","minW","minH","maxW","maxH","enable","attach"],
	faces:[
		{name:"up",entry:false,next:"",desc:"",time:0},
		{name:"over",entry:false,next:"",desc:"",time:0},
		{name:"down",entry:false,next:"",desc:"",time:0},
		{name:"gray",entry:false,next:"",desc:"",time:0}
	],
	subContainers:{
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1O4B7OK0ExGearInfo*/
	/*}#1H1O4B7OK0ExGearInfo*/
};
export default BtnObject;
export{BtnObject};