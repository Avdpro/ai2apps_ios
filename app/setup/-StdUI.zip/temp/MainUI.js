//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {NaviTop} from "./NaviTop.js";
import {DialogTemplate} from "./DialogTemplate.js";
import {DlgMenu} from "./DlgMenu.js";
import {BtnTextIcon} from "./BtnTextIcon.js";
/*#{1GGJKM84D0StartDoc*/
/*}#1GGJKM84D0StartDoc*/
//----------------------------------------------------------------------------
let MainUI=function(app,appFrame){
	let $ln,cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	let dlgAlert,menu;
	
	$ln=appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let title="Hello Tab-OS!";
	
	/*#{1GGJKM84D1LocalVals*/
	/*}#1GGJKM84D1LocalVals*/
	
	/*#{1GGJKM84D1PreState*/
	/*}#1GGJKM84D1PreState*/
	state={
		"counter":0,
		/*#{1GGJKM84D6ExState*/
		/*}#1GGJKM84D6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GGJKM84D1PostState*/
	/*}#1GGJKM84D1PostState*/
	cssVO={
		"hash":"1GGJKM84D1",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
		children:[
			{
				"hash":"1H2CTK7KT0",
				"type":NaviTop("Cool Site Name",[108,117,125,1],[255,255,255,1],"/~/-tabos/shared/assets/cklogo.svg","/~/-tabos/shared/assets/menu.svg",[]),"x":0,
				"y":0,"face":"desktop",
				subContainers:{
					"1H2CQTOQC0":[
						{
							"hash":"1H2CTOITA0",
							"type":BtnIcon(cfgColor.fontPrimary,28,0,appCfg.sharedAssets+"/find.svg",null),"position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,0,0,5],
						}
					]
				},
				/*#{1H2CTK7KT0Codes*/
				/*}#1H2CTK7KT0Codes*/
			},
			{
				"hash":"1H22KV7950",
				"type":DialogTemplate("Dialog title",false,[]),"id":"DlgAlert","x":">calc(50% - 160px)","y":">calc(30%  -  81px)","display":0,"w":320,
				subContainers:{
					"1H1T7S0BE0":[
						{
							"hash":"1H22TNAVQ0",
							"type":"text","x":29,"y":5,"w":100,"h":20,"styleClass":"","color":[0,0,0],"text":"text","fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						}
					]
				},
			},
			{
				"hash":"1H2CN7FUO0",
				"type":DlgMenu(),"id":"menu","x":">calc(100% - 15px)","y":30,"display":0,"w":120,"anchorX":2,"corner":3,
				subContainers:{
					"1H2CN3UCE0":[
						{
							"hash":"1H2CN9SSN0",
							"type":BtnObject({"text":"Login"},null),"position":"relative","x":0,"y":0,
						},
						{
							"hash":"1H2CNTN7K0",
							"type":BtnObject({"text":"Settings","enable":false},null),"position":"relative","x":0,"y":0,
						}
					]
				},
			},
			{
				"hash":"1H2SEA0TE0",
				"type":BtnTextIcon(48,48,"/~/-tabos/shared/assets/lab.svg",[0,0,0,1],false,false,"Lab"),"x":30,"y":281,"markNum":0,
			},
			{
				"hash":"1H60TM6FB0",
				"type":BtnTextIcon(48,48,appCfg.sharedAssets+"/prj.svg",cfgColor.primary,false,false,"Project"),"x":147,"y":390,
			},
			{
				"hash":"1H60TNNPR0",
				"type":BtnTextIcon(48,48,appCfg.sharedAssets+"/faces.svg",cfgColor.warning,false,false,"Faces"),"x":210,"y":390,
			},
			{
				"hash":"1H60TS3PB0",
				"type":BtnTextIcon(48,48,"/~/-tabos/shared/assets/lab.svg",[0,0,0,1],true,false,"Lab"),"x":219,"y":281,"markNum":999,
			},
			{
				"hash":"1H63DLIJP0",
				"type":NaviTop("Coder's Fun",cfgColor.success,[255,255,255,1],"/-tabos/shared/assets/code.svg","/~/-tabos/shared/assets/menu.svg",[]),"x":0,"y":52,
				"face":"desktop",
				subContainers:{
					"1H2CQI73O0":[
						{
							"hash":"1H63DU9A70",
							"type":BtnNaviItem("Home","Home",cfgColor.fontPrimary,"../../../../../StdUI/ui",undefined),"position":"relative","x":0,"y":0,"face":"focus",
						},
						{
							"hash":"1H63DVE950",
							"type":BtnNaviItem("Home","Play",cfgColor.fontPrimary,"/-tabos/shared/assets/cal.svg",undefined),"position":"relative","x":0,"y":0,"face":"focus",
						}
					]
				},
				/*#{1H63DLIJP0Codes*/
				/*}#1H63DLIJP0Codes*/
			},
			{
				"hash":"1H6RAI8JE0",
				"type":"box","x":233,"y":162,"w":50,"h":90,"styleClass":"","background":[255,255,255,1],"border":1,
			},
			{
				"hash":"1H6SSKGKJ0",
				"type":"text","x":114,"y":177,"w":100,"h":20,"styleClass":"","color":[0,0,0],"text":"text","fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			}
		],
		/*#{1GGJKM84D1ExtraCSS*/
		/*}#1GGJKM84D1ExtraCSS*/
		faces:{
			"init":{
				"#1H2CTK7KT0":{
					"display":1
				},
				/*DlgAlert*/"#1H22KV7950":{
					"display":0
				},
				/*menu*/"#1H2CN7FUO0":{
					"display":0
				},
				"#1H63DLIJP0":{
					"display":1
				}
			},"mobile":{
				"#1H2CTK7KT0":{
					"face":"mobile"
				},
				"#1H63DLIJP0":{
					"face":"mobile"
				}
			},"desktop":{
				"#1H2CTK7KT0":{
					"face":"desktop"
				},
				"#1H63DLIJP0":{
					"face":"desktop"
				}
			},"showMenu":{
				/*DlgAlert*/"#1H22KV7950":{
					"display":0
				},
				/*menu*/"#1H2CN7FUO0":{
					"display":1
				}
			},"showDlog":{
				/*DlgAlert*/"#1H22KV7950":{
					"display":1
				},
				/*menu*/"#1H2CN7FUO0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			dlgAlert=self.DlgAlert;menu=self.menu;
			/*#{1GGJKM84D1Create*/
			/*}#1GGJKM84D1Create*/
		},
		/*#{1GGJKM84D1EndCSS*/
		/*}#1GGJKM84D1EndCSS*/
	};
	/*#{1GGJKM84D1PostCSSVO*/
	/*}#1GGJKM84D1PostCSSVO*/
	return cssVO;
};
/*#{1GGJKM84D1ExCodes*/
/*}#1GGJKM84D1ExCodes*/

MainUI.gearExport={
	framework: "vfact",
	hudType: "view",
	showName:"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"app": {
			"name": "app", "showName": "app", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"appFrame": {
			"name": "appFrame", "showName": "appFrame", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[
		{name:"init",entry:true,next:"",desc:"",time:0},
		{name:"mobile",entry:false,next:"",desc:"",time:0},
		{name:"desktop",entry:false,next:"",desc:"",time:0},
		{name:"showMenu",entry:false,next:"",desc:"",time:0},
		{name:"showDlog",entry:false,next:"",desc:"",time:0}
	],
	subContainers:{
	},
	deviceW:375,
	deviceH:750,
	/*#{1GGJKM84D0ExGearInfo*/
	/*}#1GGJKM84D0ExGearInfo*/
};
export default MainUI;
export{MainUI};