//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1H1LRUDP20StartDoc*/
/*}#1H1LRUDP20StartDoc*/
//----------------------------------------------------------------------------
let BoxSteps=function(size){
	let $ln,cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	let btnStepUp,btnStepDown;
	
	$ln=appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1LRUDP21LocalVals*/
	/*}#1H1LRUDP21LocalVals*/
	
	/*#{1H1LRUDP21PreState*/
	/*}#1H1LRUDP21PreState*/
	state={
		"enable":true,"enableUp":true,"enableDown":true,
		/*#{1H1LRUDP26ExState*/
		/*}#1H1LRUDP26ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1LRUDP21PostState*/
	/*}#1H1LRUDP21PostState*/
	cssVO={
		"hash":"1H1LRUDP21",nameHost:true,
		"type":"hud","x":121,"y":141,"w":size,"h":size,"alpha":$P(()=>(state.enable?1:0.6),state),"styleClass":"",
		children:[
			{
				"hash":"1H1LRVCO90",
				"type":BtnIcon("front",size,size*0.5,appCfg.sharedAssets+"/stepup.svg",null),"id":"BtnStepUp","x":0,"y":0,"enable":$P(()=>(state.enableUp),state),
				"OnButtonDown":function(code,event){
					/*#{1H2E51V6T0FunctionBody*/
					/*}#1H2E51V6T0FunctionBody*/
				},
				"OnButtonUp":function(code,event){
					/*#{1H2E520ES0FunctionBody*/
					/*}#1H2E520ES0FunctionBody*/
				},
			},
			{
				"hash":"1H1LS2K200",
				"type":BtnIcon("front",size,size*0.5,appCfg.sharedAssets+"/stepdown.svg",null),"id":"BtnStepDown","x":0,"y":size*0.5,"enable":$P(()=>(state.enableDown),state),
				"OnButtonDown":function(code,event){
					/*#{1H2E52PJA0FunctionBody*/
					/*}#1H2E52PJA0FunctionBody*/
				},
				"OnButtonUp":function(code,event){
					/*#{1H2E52QAT0FunctionBody*/
					/*}#1H2E52QAT0FunctionBody*/
				},
			}
		],
		get $$enable(){return state["enable"]},
		set $$enable(v){
			state["enable"]=v;
			/*#{1H1LRUDP21Setenable*/
			/*}#1H1LRUDP21Setenable*/
		},
		get $$enableUp(){return state["enableUp"]},
		set $$enableUp(v){
			state["enableUp"]=v;
			/*#{1H1LRUDP21SetenableUp*/
			/*}#1H1LRUDP21SetenableUp*/
		},
		get $$enableDown(){return state["enableDown"]},
		set $$enableDown(v){
			state["enableDown"]=v;
			/*#{1H1LRUDP21SetenableDown*/
			/*}#1H1LRUDP21SetenableDown*/
		},
		/*#{1H1LRUDP21ExtraCSS*/
		/*}#1H1LRUDP21ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			btnStepUp=self.BtnStepUp;btnStepDown=self.BtnStepDown;
			/*#{1H1LRUDP21Create*/
			/*}#1H1LRUDP21Create*/
		},
		/*#{1H1LRUDP21EndCSS*/
		/*}#1H1LRUDP21EndCSS*/
	};
	/*#{1H1LRUDP21PostCSSVO*/
	/*}#1H1LRUDP21PostCSSVO*/
	return cssVO;
};
/*#{1H1LRUDP21ExCodes*/
/*}#1H1LRUDP21ExCodes*/

BoxSteps.gearExport={
	framework: "jax",
	hudType: "hud",
	showName:"Step Buttons",icon:"btn_step.svg",previewImg:"false",
	fixPose:false,initW:20,initH:20,
	desc:"2-buttons that increase or decrease value.",
	catalog:"Buttons",
	args: {
		"size": {
			"name": "size", "showName": "size", "type": "int", "key": true, "fixed": true, "initVal": 20, "localizable": undefined
		}
	},
	state:{
		enable:{name:"enable",type:"bool",initVal:true},
		enableUp:{name:"enableUp",type:"bool",initVal:true},
		enableDown:{name:"enableDown",type:"bool",initVal:true}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","rotate","scale","cursor","zIndex","margin","attach"],
	faces:[
	],
	subContainers:{
	},
	deviceW:375,
	deviceH:750,
	/*#{1H1LRUDP20ExGearInfo*/
	/*}#1H1LRUDP20ExGearInfo*/
};
export default BoxSteps;
export{BoxSteps};