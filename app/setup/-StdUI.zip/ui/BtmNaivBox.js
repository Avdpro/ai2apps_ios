//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnTextIcon} from "./BtnTextIcon.js";
/*#{1H1UMGT2L0StartDoc*/
/*}#1H1UMGT2L0StartDoc*/
//----------------------------------------------------------------------------
let BtmNaivBox=function(colorBG,color,items){
	let $ln,cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	$ln=appCfg.lanCode||'EN';
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1UMGT2L1LocalVals*/
	/*}#1H1UMGT2L1LocalVals*/
	
	/*#{1H1UMGT2L1PreState*/
	/*}#1H1UMGT2L1PreState*/
	/*#{1H1UMGT2L1PostState*/
	/*}#1H1UMGT2L1PostState*/
	cssVO={
		"hash":"1H1UMGT2L1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":60,"styleClass":"","contentLayout":"flex-x","subAlign":4,
		children:[
			{
				"hash":"1H1UMHISA0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","background":colorBG,"border":[1,0,0,0],"borderColor":color,"contentLayout":"flex-x",
				"subAlign":3,
			},
			{
				"hash":"1H22VD24H0",
				"type":"hud","id":"NaviButtons","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","contentLayout":"flex-x","subAlign":4,
				children:[
				],
			}
		],
		/*#{1H1UMGT2L1ExtraCSS*/
		/*}#1H1UMGT2L1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H1UMGT2L1Create*/
			/*}#1H1UMGT2L1Create*/
		},
		/*#{1H1UMGT2L1EndCSS*/
		/*}#1H1UMGT2L1EndCSS*/
	};
	/*#{1H1UMGT2L1PostCSSVO*/
	/*}#1H1UMGT2L1PostCSSVO*/
	return cssVO;
};
/*#{1H1UMGT2L1ExCodes*/
/*}#1H1UMGT2L1ExCodes*/

BtmNaivBox.gearExport={
	framework: "jax",
	hudType: "hud",
	showName:"Navi-Bottom",icon:"gears.svg",
	initW:360,initH:60,
	desc:"App bottom navi-box",
	catalog:"Views",
	args: {
		"colorBG": {
			"name": "colorBG", "showName": "colorBG", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [255,255,255,1], "localizable": undefined
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [0,0,0,1], "localizable": undefined
		}, 
		"items": {
			"type": "array", "name": "items", "showName": "items", "icon": undefined, 
			"def": {"initAttrVOs":[]}, "key": true, "fixed": true
		}
	},
	state:{
	},
	properties:["id","position","x","y","h","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","traceSize","attach"],
	faces:[],
	/*#{1H1UMGT2L0ExGearInfo*/
	/*}#1H1UMGT2L0ExGearInfo*/
};
export default BtmNaivBox;
export{BtmNaivBox};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1H1UMGT2L0",
//	"editVersion": 86,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H1UMGT2L2",
//			"editVersion": 10,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H1UMGT2L3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1UMGT2L4",
//			"editVersion": 20,
//			"attrs": {
//				"colorBG": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor.body"
//				},
//				"color": {
//					"type": "colorRGBA",
//					"valText": "[0,0,0,1.00]"
//				},
//				"items": {
//					"type": "array",
//					"def": "Array",
//					"attrs": []
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1UMGT2L5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H1UMGT2L6",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "Navi-Bottom",
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "60",
//		"gearCatalog": "Views",
//		"description": "App bottom navi-box",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H1UMGT2L7",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1UMGT2L1",
//			"editVersion": 20,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H1UMGT2L8",
//					"editVersion": 76,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "60",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"subAlign": "Space Evenly"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1UMHISA0",
//							"editVersion": 26,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1UMJG5J0",
//									"editVersion": 128,
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#colorBG",
//										"border": "[1,0,0,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#color",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"subAlign": "Space Around"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1UMJG5J1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1UMJG5J2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1UMJG5J3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H22VD24H0",
//							"editVersion": 27,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H22VG2CB0",
//									"editVersion": 84,
//									"attrs": {
//										"type": "hud",
//										"id": "NaviButtons",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "Space Evenly"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1RPOAH90",
//											"jaxId": "1H22VEAQ50",
//											"editVersion": 41,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H22VEAQ51",
//													"editVersion": 20,
//													"attrs": {
//														"w": "48",
//														"h": "48",
//														"icon": "/~/-tabos/shared/assets/lab.svg",
//														"color": "[0,0,0,1.00]",
//														"hasMark": "true",
//														"hasCheck": "false",
//														"text": "Item 1"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H22VEAQ52",
//													"editVersion": 49,
//													"attrs": {
//														"type": "#null#>BtnTextIcon(48,48,\"/~/-tabos/shared/assets/lab.svg\",[0,0,0,1],true,false,\"Item 1\")",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H22VEAQ53",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H22VEAQ54",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H22VEAQ55",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H22VEAQ56",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1RPOAH90",
//											"jaxId": "1H22VEKT10",
//											"editVersion": 41,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H22VEKT11",
//													"editVersion": 20,
//													"attrs": {
//														"w": "48",
//														"h": "48",
//														"icon": "/~/-tabos/shared/assets/lab.svg",
//														"color": "[0,0,0,1.00]",
//														"hasMark": "true",
//														"hasCheck": "false",
//														"text": "Item 2"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H22VEKT12",
//													"editVersion": 49,
//													"attrs": {
//														"type": "#null#>BtnTextIcon(48,48,\"/~/-tabos/shared/assets/lab.svg\",[0,0,0,1],true,false,\"Item 2\")",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H22VEKT20",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H22VEKT21",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H22VEKT22",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H22VEKT23",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1RPOAH90",
//											"jaxId": "1H22VEP4S0",
//											"editVersion": 42,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H22VEP4S1",
//													"editVersion": 20,
//													"attrs": {
//														"w": "48",
//														"h": "48",
//														"icon": "/~/-tabos/shared/assets/lab.svg",
//														"color": "[0,0,0,1.00]",
//														"hasMark": "true",
//														"hasCheck": "false",
//														"text": "item 3"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H22VEP4S2",
//													"editVersion": 50,
//													"attrs": {
//														"type": "#null#>BtnTextIcon(48,48,\"/~/-tabos/shared/assets/lab.svg\",[0,0,0,1],true,false,\"item 3\")",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H22VEP4S3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H22VEP4S4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H22VEP4S5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H22VEP4S6",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1RPOAH90",
//											"jaxId": "1H22VET1I0",
//											"editVersion": 43,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H22VET1I1",
//													"editVersion": 20,
//													"attrs": {
//														"w": "48",
//														"h": "48",
//														"icon": "/~/-tabos/shared/assets/lab.svg",
//														"color": "[0,0,0,1.00]",
//														"hasMark": "true",
//														"hasCheck": "false",
//														"text": "Item 4"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H22VET1I2",
//													"editVersion": 51,
//													"attrs": {
//														"type": "#null#>BtnTextIcon(48,48,\"/~/-tabos/shared/assets/lab.svg\",[0,0,0,1],true,false,\"Item 4\")",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H22VET1I3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H22VET1I4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H22VET1I5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H22VET1I6",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1RPOAH90",
//											"jaxId": "1H22VF28C0",
//											"editVersion": 48,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H22VF28C1",
//													"editVersion": 26,
//													"attrs": {
//														"w": "48",
//														"h": "48",
//														"icon": "/~/-tabos/shared/assets/lab.svg",
//														"color": "[0,0,0,1.00]",
//														"hasMark": "true",
//														"hasCheck": "false",
//														"text": "Item 5"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H22VF28C2",
//													"editVersion": 53,
//													"attrs": {
//														"type": "#null#>BtnTextIcon(48,48,\"/~/-tabos/shared/assets/lab.svg\",[0,0,0,1],true,false,\"Item 5\")",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H22VF28C3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H22VF28C4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H22VF28C5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H22VF28C6",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H22VG2CB1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H22VG2CB2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H22VG2CB3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H1UMGT2L9",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H1UMGT2L10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H1UMGT2L11",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1UMGT2L12",
//			"editVersion": 106,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"innerLayout": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "true",
//				"marginL": "false",
//				"marginR": "false",
//				"marginT": "false",
//				"marginB": "false",
//				"padding": "false",
//				"paddingL": "false",
//				"paddingR": "false",
//				"paddingT": "false",
//				"paddingB": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"attach": "true"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}