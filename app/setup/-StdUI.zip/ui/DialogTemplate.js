//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
import {BtnText} from "./BtnText.js";
/*#{1H1T7ISV50StartDoc*/
/*
This is a template for standard dialog.
*/
/*}#1H1T7ISV50StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DialogTemplate=function(title,closeIcon,buttons){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxContent,boxButtons,btnYes,btnNo,btn3rd;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7ISV51LocalVals*/
	let app,dlgVO;
	app=window.tabOSApp;
	dlgVO=null;
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	state={
		"title":title,"buttons":buttons,
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":10,"y":"30%","w":360,"h":"","padding":10,"styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","background":cfgColor.body,"border":2,"borderColor":cfgColor["fontBodySub"],
				"corner":5,"shadow":true,"shadowX":3,"shadowY":6,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T84P6A0",
				"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","x":">calc(100% - 36px)","y":5,"display":!!closeIcon,"padding":3,
				"attached":!!closeIcon,
				"OnClick":function(event){
					/*#{1H1T8K68O0FunctionBody*/
					self.close(false);
					/*}#1H1T8K68O0FunctionBody*/
				},
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,10,0],"styleClass":"","color":cfgColor.fontBodySub,
				"text":$P(()=>(state.title),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":"","minH":30,"styleClass":"",
				children:[
					{
						"hash":"1H1T8B4370",
						"type":"text","id":"TxtMockup","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","color":cfgColor.fontBodyLit,"text":"Add your components here.",
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
					}
				],
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":0,"styleClass":"","contentLayout":"flex-x",
				"subAlign":2,"attached":!!buttons,
				children:[
					{
						"hash":"1H1T802O00",
						"type":BtnText("primary",80,24,state.buttons[1]||"OK",false,""),"id":"BtnYes","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1H1T8J6TN0FunctionBody*/
							self.close(true);
							/*}#1H1T8J6TN0FunctionBody*/
						},
					},
					{
						"hash":"1H1T820FU0",
						"type":BtnText("warning",80,24,state.buttons[0]||"Cancel",false,""),"id":"BtnNo","position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,15,0,0],
						"OnClick":function(event){
							/*#{1H1T8JJRK0FunctionBody*/
							self.close(false);
							/*}#1H1T8JJRK0FunctionBody*/
						},
					},
					{
						"hash":"1H25185U60",
						"type":BtnText("secondary",80,24,state.buttons[2],false,""),"id":"Btn3rd","position":"relative","x":0,"y":"50%","display":!!(buttons&&buttons[2]),
						"anchorY":1,"attached":!!(buttons&&buttons[2]),
						"OnClick":function(event){
							/*#{1H25185U72FunctionBody*/
							/*}#1H25185U72FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContent=self.BoxContent;boxButtons=self.BoxButtons;btnYes=self.BtnYes;btnNo=self.BtnNo;btn3rd=self.Btn3rd;
			/*#{1H1T7ISV51Create*/
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		//TODO: init/update your dialog based on vo
		self.animate({type:"in",alpha:0,scale:0.9,time:100});
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	/*}#1H1T7ISV51PostCSSVO*/
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/

DialogTemplate.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":(($ln==="CN")?("标准对话框"):("Standard Dialog")),icon:"gears.svg",previewImg:false,
	fixPose:false,initW:360,initH:500,
	catalog:"",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Dialog title", "localizable": true
		}, 
		"closeIcon": {
			"name": "closeIcon", "showName": "closeIcon", "type": "bool", "key": true, "fixed": true, "initVal": false
		}, 
		"buttons": {
			"name": "buttons", "showName": "buttons", "type": "auto", "key": true, "fixed": true, 
			"initVal": []
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","display"],
	faces:[],
	subContainers:{
		"1H1T7S0BE0":{"showName":"BoxContent"}
	},
	/*#{1H1T7ISV50ExGearInfo*/
	/*}#1H1T7ISV50ExGearInfo*/
};
export default DialogTemplate;
export{DialogTemplate};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1H1T7ISV50",
//	"editVersion": 133,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H1T7ISV52",
//			"editVersion": 10,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H1T7ISV53",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H8H690AD0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1T7ISV54",
//			"editVersion": 106,
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Dialog title",
//					"localizable": true
//				},
//				"closeIcon": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"buttons": {
//					"type": "auto",
//					"valText": "[]"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1T7ISV55",
//			"editVersion": 10,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H1T7ISV56",
//			"editVersion": 18,
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "#title",
//					"localizable": true
//				},
//				"buttons": {
//					"type": "auto",
//					"valText": "#buttons"
//				}
//			}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Standard Dialog",
//			"localize": {
//				"EN": "Standard Dialog",
//				"CN": "标准对话框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "500",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H1T7ISV57",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7ISV51",
//			"editVersion": 20,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H1T7ISV58",
//					"editVersion": 158,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "10",
//						"y": "30%",
//						"w": "360",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1T7LGH40",
//							"editVersion": 34,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O0",
//									"editVersion": 152,
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.body",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "5",
//										"shadow": "true",
//										"shadowX": "3",
//										"shadowY": "6",
//										"shadowBlur": "5",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1H1T84P6A0",
//							"editVersion": 60,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1H1T88CE90",
//									"editVersion": 24,
//									"attrs": {
//										"style": "front",
//										"w": "28",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T88CE91",
//									"editVersion": 88,
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/close.svg\",null)",
//										"id": "BtnClose",
//										"position": "Absolute",
//										"x": "100%-36",
//										"y": "5",
//										"display": "#!!closeIcon",
//										"face": "",
//										"padding": "3",
//										"attach": "#!!closeIcon"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T88CE92",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T88CE93",
//									"editVersion": 2,
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H1T8K68O0",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1H1T8KC4H0",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T88CE94",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1H211US3V0",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1T7O2SA0",
//							"editVersion": 46,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O4",
//									"editVersion": 176,
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "${state.title},state",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O5",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O6",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O7",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7S0BE0",
//							"editVersion": 48,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O8",
//									"editVersion": 94,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H1T8B4370",
//											"editVersion": 32,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1T8DM3N0",
//													"editVersion": 136,
//													"attrs": {
//														"type": "text",
//														"id": "TxtMockup",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor.fontBodyLit",
//														"text": "Add your components here.",
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "false",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H1T8DM3N1",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H1T8DM3N2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H1T8DM3N3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O9",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O10",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O11",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7UCES0",
//							"editVersion": 37,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O12",
//									"editVersion": 140,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "End",
//										"attach": "#!!buttons",
//										"flex": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T802O00",
//											"editVersion": 77,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H1T81V2B0",
//													"editVersion": 40,
//													"attrs": {
//														"style": "primary",
//														"w": "80",
//														"h": "24",
//														"text": "#state.buttons[1]||\"OK\"",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1T81V2B1",
//													"editVersion": 100,
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",80,24,state.buttons[1]||\"OK\",false,\"\")",
//														"id": "BtnYes",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H1T81V2B2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H1T81V2B3",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8J6TN0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H1T8JCTG0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H1T81V2B4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H211US3V1",
//													"editVersion": 0,
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"type": "gearcontainer",
//															"jaxId": "1H8H690AD1",
//															"editVersion": 4,
//															"attrs": {
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H1T820FU0",
//											"editVersion": 88,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H1T820FU1",
//													"editVersion": 56,
//													"attrs": {
//														"style": "warning",
//														"w": "80",
//														"h": "24",
//														"text": "#state.buttons[0]||\"Cancel\"",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1T820FU2",
//													"editVersion": 97,
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",80,24,state.buttons[0]||\"Cancel\",false,\"\")",
//														"id": "BtnNo",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,15,0,0]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H1T820FU3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H1T820FU4",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H1T8JJRK0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H1T8JQQ40",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H1T820FU5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H211US3V2",
//													"editVersion": 0,
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"type": "gearcontainer",
//															"jaxId": "1H8H690AE0",
//															"editVersion": 4,
//															"attrs": {
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1H1KB50JO0",
//											"jaxId": "1H25185U60",
//											"editVersion": 95,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1H25185U61",
//													"editVersion": 62,
//													"attrs": {
//														"style": "secondary",
//														"w": "80",
//														"h": "24",
//														"text": "#state.buttons[2]",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1H25185U62",
//													"editVersion": 117,
//													"attrs": {
//														"type": "#null#>BtnText(\"secondary\",80,24,state.buttons[2],false,\"\")",
//														"id": "Btn3rd",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "#!!(buttons&&buttons[2])",
//														"face": "",
//														"anchorV": "Center",
//														"attach": "#!!(buttons&&buttons[2])"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H25185U70",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H25185U71",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H25185U72",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1H25185U73",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H25185U74",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1H25185U75",
//													"editVersion": 0,
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"type": "gearcontainer",
//															"jaxId": "1H8H690AE1",
//															"editVersion": 4,
//															"attrs": {
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O13",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O14",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O15",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H1T7ISV59",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H1T7ISV510",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H1T7ISV511",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7ISV512",
//			"editVersion": 84,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}