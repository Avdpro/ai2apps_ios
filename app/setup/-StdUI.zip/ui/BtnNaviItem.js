//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1TCNO8A0StartDoc*/
import DlgMenu from "./DlgMenu.js";
/*}#1H1TCNO8A0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnNaviItem=function(code,text,color,icon,items){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1TCNO8A1LocalVals*/
	let app=window.tabOSApp;
	let focused=false;
	/*}#1H1TCNO8A1LocalVals*/
	
	/*#{1H1TCNO8A1PreState*/
	/*}#1H1TCNO8A1PreState*/
	/*#{1H1TCNO8A1PostState*/
	/*}#1H1TCNO8A1PostState*/
	cssVO={
		"hash":"1H1TCNO8A1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"","h":"100%","alpha":0.5,"cursor":"pointer","padding":[5,5,5,5],"styleClass":"","contentLayout":"flex-x",
		"traceSize":true,
		"code":code,
		children:[
			{
				"hash":"1H1TCV3O50",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":"50%","w":"FH-10","h":"FH-10","anchorY":1,"autoLayout":true,"uiEvent":-1,"styleClass":"",
				"background":color,"aspect":"1","attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1H1TCQ3130",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"padding":0,"styleClass":"","color":color,"text":text,
				"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1H1TIOQU40",
				"type":"box","id":"MenuMark","position":"relative","x":0,"y":"50%","w":"","h":">calc(100% - 10px)","anchorY":1,"uiEvent":-1,"styleClass":"","background":color,
				"aspect":"1","maskImage":appCfg.sharedAssets+"/down.svg","attached":!!items,
			}
		],
		/*#{1H1TCNO8A1ExtraCSS*/
		/*}#1H1TCNO8A1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H1TD2J6S0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1TD2J6S0PreCode*/
				"#self":{
					"alpha":0.5
				}
			},"over":{
				/*#{1H1TD45OB0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1TD45OB0PreCode*/
				"#self":{
					"alpha":0.7
				}
			},"down":{
				/*#{1H1TD2VV70PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1TD2VV70PreCode*/
				"#self":{
					"alpha":1
				}
			},"gray":{
				/*#{1H1TLQVNS0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1TLQVNS0PreCode*/
				"#self":{
					"alpha":0.2
				}
			},"focus":{
				"#self":{
					"alpha":1
				},
				/*#{1H1TD5GM90Code*/
				$(){
					focused=true;
					this.uiEvent=-1;
				},
				/*}#1H1TD5GM90Code*/
			},"blur":{
				"#self":{
					"alpha":0.5
				},
				/*#{1H1TD5O2O0Code*/
				$(){
					focused=false;
					this.uiEvent=1;
				},
				/*}#1H1TD5O2O0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H1TCNO8A1Create*/
			/*}#1H1TCNO8A1Create*/
		},
		/*#{1H1TCNO8A1EndCSS*/
		/*}#1H1TCNO8A1EndCSS*/
	};
	/*#{1H1TCNO8A1PostCSSVO*/
	/*}#1H1TCNO8A1PostCSSVO*/
	return cssVO;
};
/*#{1H1TCNO8A1ExCodes*/
/*}#1H1TCNO8A1ExCodes*/

BtnNaviItem.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("导航入口"):("Navi Entry")),icon:"gears.svg",previewImg:false,
	fixPose:true,initW:100,initH:40,
	"desc":"Navi bar item button, with text. Item can have an icon. If item has sub-items, click will popup a menu.",
	catalog:"Buttons",
	args: {
		"code": {
			"name": "code", "showName": "code", "type": "string", "key": true, "fixed": true, "initVal": "Home"
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Home", "localizable": true
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [0,0,0,1]
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/home.svg"
		}, 
		"items": {"name":"items","showName":"items","type":"auto","key":true,"fixed":true}
	},
	state:{
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","cursor","margin","enable","attach"],
	faces:["up","over","down","gray","focus","blur"],
	subContainers:{
	},
	/*#{1H1TCNO8A0ExGearInfo*/
	/*}#1H1TCNO8A0ExGearInfo*/
};
export default BtnNaviItem;
export{BtnNaviItem};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H1TCNO8A0",
//	"editVersion": 128,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H1TCNO8A2",
//			"editVersion": 40,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "40",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H1TCNO8A3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H5RF70O00",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1TCNO8A4",
//			"editVersion": 80,
//			"attrs": {
//				"code": {
//					"type": "string",
//					"valText": "Home"
//				},
//				"text": {
//					"type": "string",
//					"valText": "Home",
//					"localizable": true
//				},
//				"color": {
//					"type": "colorRGBA",
//					"valText": "[0,0,0,1.00]"
//				},
//				"icon": {
//					"type": "url",
//					"valText": "#appCfg.sharedAssets+\"/home.svg\""
//				},
//				"items": {
//					"type": "auto",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1TCNO8A5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H1TCNO8A6",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Navi Entry",
//			"localize": {
//				"EN": "Navi Entry",
//				"CN": "导航入口"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "40",
//		"gearCatalog": "Buttons",
//		"description": "Navi bar item button, with text. Item can have an icon. If item has sub-items, click will popup a menu.",
//		"fixPose": "true",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H1TCNO8A7",
//			"editVersion": 18,
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD2J6S0",
//					"editVersion": 10,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1TD5T390",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD45OB0",
//					"editVersion": 10,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1TD5T391",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD2VV70",
//					"editVersion": 10,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1TD5T392",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TLQVNS0",
//					"editVersion": 10,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1TLR73E0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD5GM90",
//					"editVersion": 10,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1TD5T393",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD5O2O0",
//					"editVersion": 10,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1TD5T394",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1TCNO8A1",
//			"editVersion": 49,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H1TCNO8A8",
//					"editVersion": 130,
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "\"\"",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "0.5",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[5,5,5,5]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"attach": "true",
//						"traceSize": "true"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1TCV3O50",
//							"editVersion": 28,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TD5T395",
//									"editVersion": 184,
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "50%",
//										"w": "\"FH-10\"",
//										"h": "\"FH-10\"",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#color",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"aspect": "1",
//										"attach": "#!!icon",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1TD5T396",
//									"editVersion": 62,
//									"attrs": {
//										"1H1TD2VV70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TD5T399",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1TD5T3910",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2VV70",
//											"faceTagName": "down"
//										},
//										"1H1TD45OB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TD5T3911",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1TD5T3912",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD45OB0",
//											"faceTagName": "over"
//										},
//										"1H1TD5O2O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TIUJ9A2",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1TIUJ9A3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5O2O0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1TD5T3917",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1TD5T3918",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1TCQ3130",
//							"editVersion": 28,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TD5T3919",
//									"editVersion": 168,
//									"attrs": {
//										"type": "text",
//										"id": "TxtName",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#color",
//										"text": "#text",
//										"font": "",
//										"fontSize": "#txtSize.mid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1TD5T3920",
//									"editVersion": 62,
//									"attrs": {
//										"1H1TD2VV70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TD5T3923",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1TD5T3924",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2VV70",
//											"faceTagName": "down"
//										},
//										"1H1TD45OB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TD5T3925",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1TD5T3926",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD45OB0",
//											"faceTagName": "over"
//										},
//										"1H1TD5O2O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TIUJ9A6",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1TIUJ9A7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5O2O0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1TD5T3931",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1TD5T3932",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1TIOQU40",
//							"editVersion": 28,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TIT6SM0",
//									"editVersion": 150,
//									"attrs": {
//										"type": "box",
//										"id": "MenuMark",
//										"position": "relative",
//										"x": "0",
//										"y": "50%",
//										"w": "\"\"",
//										"h": "100%-10",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#color",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"aspect": "1",
//										"maskImage": "#appCfg.sharedAssets+\"/down.svg\"",
//										"attach": "#!!items"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1TIT6SM1",
//									"editVersion": 30,
//									"attrs": {
//										"1H1TD45OB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TIUJ9A12",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1TIUJ9A13",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD45OB0",
//											"faceTagName": "over"
//										},
//										"1H1TD2VV70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TIUJ9A14",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1TIUJ9A15",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2VV70",
//											"faceTagName": "down"
//										},
//										"1H1TD5O2O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TIUJ9A18",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1TIUJ9A19",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5O2O0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1TIT6SM2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1TIT6SM3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H1TCNO8A9",
//					"editVersion": 16,
//					"attrs": {
//						"1H1TD2J6S0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1TD5T3933",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TD5T3934",
//									"editVersion": 14,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.5",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TD2J6S0",
//							"faceTagName": "up"
//						},
//						"1H1TD2VV70": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1TD5T3935",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TD5T3936",
//									"editVersion": 26,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TD2VV70",
//							"faceTagName": "down"
//						},
//						"1H1TD45OB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1TD5T3937",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TD5T3938",
//									"editVersion": 8,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.7",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TD45OB0",
//							"faceTagName": "over"
//						},
//						"1H1TD5GM90": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1TD5T3939",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TD5T3940",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TD5GM90",
//							"faceTagName": "focus"
//						},
//						"1H1TD5O2O0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1TD5T3941",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TD5T3942",
//									"editVersion": 10,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.5",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TD5O2O0",
//							"faceTagName": "blur"
//						},
//						"1H1TLQVNS0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1TLR73E9",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TLR73E10",
//									"editVersion": 8,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.2",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TLQVNS0",
//							"faceTagName": "gray"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H1TCNO8A10",
//					"editVersion": 8,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H1TCNO8A11",
//					"editVersion": 8,
//					"attrs": {
//						"code": {
//							"type": "string",
//							"valText": "#code"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1TCNO8A12",
//			"editVersion": 100,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "true",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}