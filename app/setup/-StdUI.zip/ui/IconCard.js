//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H59BTKMB0StartDoc*/
/*}#1H59BTKMB0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let IconCard=function(title,intro,pic,picW,picH){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H54B0SFB1LocalVals*/
	/*}#1H54B0SFB1LocalVals*/
	
	/*#{1H54B0SFB1PreState*/
	/*}#1H54B0SFB1PreState*/
	/*#{1H54B0SFB1PostState*/
	/*}#1H54B0SFB1PostState*/
	cssVO={
		"hash":"1H54B0SFB1",nameHost:true,
		"type":"button","x":38,"y":26,"w":300,"h":"","padding":10,"minH":(pic&&picH>0)?picH+20:30,"styleClass":"","contentLayout":"flex-y","traceSize":true,
		"subAlign":1,
		children:[
			{
				"hash":"1H54B23MV0",
				"type":"box","id":"BG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"styleClass":"","background":[255,255,255,0],"border":1,"borderColor":cfgColor.lineBodyLit,
				"corner":6,
			},
			{
				"hash":"1H59BTTB30",
				"type":"box","x":10,"y":"50%","w":picW||100,"h":picH||picW||100,"anchorY":1,"styleClass":"","background":cfgColor["fontBody"],"attached":!!pic,"maskImage":pic,
			},
			{
				"hash":"1H5721BRE0",
				"type":"text","position":"relative","x":(pic&&picW>0)?picW+10:0,"y":0,"w":(pic&&picW>0)?`FW-${picW+30}`:"FW","h":"","autoLayout":true,"margin":[0,0,5,0],
				"styleClass":"","color":cfgColor.fontBody,"text":title,"fontSize":txtSize.big,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","ellipsis":true,
			},
			{
				"hash":"1H572917N0",
				"type":"text","position":"relative","x":(pic&&picW>0)?picW+10:0,"y":0,"w":(pic&&picW>0)?`FW-${picW+30}`:"FW-20","h":"","autoLayout":true,"styleClass":"",
				"color":cfgColor.fontBodySub,"text":intro,"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,
			}
		],
		/*#{1H54B0SFB1ExtraCSS*/
		/*}#1H54B0SFB1ExtraCSS*/
		faces:{
			"up":{
				"#self":{
					"alpha":1
				},
				/*BG*/"#1H54B23MV0":{
					"border":1,"borderColor":cfgColor.lineBodyLit
				}
			},"over":{
				"#self":{
					"alpha":1
				},
				/*BG*/"#1H54B23MV0":{
					"border":2,"borderColor":cfgColor.lineBody
				}
			},"down":{
				"#self":{
					"alpha":1
				},
				/*BG*/"#1H54B23MV0":{
					"border":2,"borderColor":cfgColor.lineBody
				}
			},"gray":{
				/*BG*/"#1H54B23MV0":{
					"border":1,"borderColor":cfgColor.lineBodyLit
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H54B0SFB1Create*/
			/*}#1H54B0SFB1Create*/
		},
		/*#{1H54B0SFB1EndCSS*/
		/*}#1H54B0SFB1EndCSS*/
	};
	/*#{1H54B0SFB1PostCSSVO*/
	/*}#1H54B0SFB1PostCSSVO*/
	return cssVO;
};
/*#{1H54B0SFB1ExCodes*/
/*}#1H54B0SFB1ExCodes*/

IconCard.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("图标卡片"):("Icon-Card")),icon:"rename.svg",previewImg:"./PicCard.png",
	fixPose:false,initW:300,initH:80,
	"desc":(($ln==="CN")?("一个带有标题和简介的卡片。可能左侧有一个单色图标。"):("A card with title and intro. Maybe has an mono-color-icon on left side.")),
	catalog:"Views",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Title", "localizable": true
		}, 
		"intro": {
			"name": "intro", "showName": "intro", "type": "string", "key": true, "fixed": true, "initVal": "Card intro text", "localizable": true
		}, 
		"pic": {
			"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/prj.svg"
		}, 
		"picW": {
			"name": "picW", "showName": "picW", "type": "int", "key": true, "fixed": true, "initVal": 50
		}, 
		"picH": {
			"name": "picH", "showName": "picH", "type": "int", "key": true, "fixed": true, "initVal": 50
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","filter","cursor","zIndex","flex","margin","minW","minH","maxW","maxH","enable","drag"],
	faces:["up","over","down","gray"],
	subContainers:{
	},
	/*#{1H59BTKMB0ExGearInfo*/
	/*}#1H59BTKMB0ExGearInfo*/
};
export default IconCard;
export{IconCard};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H59BTKMB0",
//	"editVersion": 146,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H54B0SFB2",
//			"editVersion": 10,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H54B0SFC0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H5NQV6BP0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H54B0SFC1",
//			"editVersion": 76,
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Title",
//					"localizable": true
//				},
//				"intro": {
//					"type": "string",
//					"valText": "Card intro text",
//					"localizable": true
//				},
//				"pic": {
//					"type": "url",
//					"valText": "#appCfg.sharedAssets+\"/prj.svg\""
//				},
//				"picW": {
//					"type": "int",
//					"valText": "50"
//				},
//				"picH": {
//					"type": "int",
//					"valText": "50"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H54B0SFC2",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H54B0SFC3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Icon-Card",
//			"localize": {
//				"EN": "Icon-Card",
//				"CN": "图标卡片"
//			},
//			"localizable": true
//		},
//		"gearIcon": "rename.svg",
//		"gearW": "300",
//		"gearH": "80",
//		"gearCatalog": "Views",
//		"description": {
//			"type": "string",
//			"valText": "A card with title and intro. Maybe has an mono-color-icon on left side.",
//			"localize": {
//				"EN": "A card with title and intro. Maybe has an mono-color-icon on left side.",
//				"CN": "一个带有标题和简介的卡片。可能左侧有一个单色图标。"
//			},
//			"localizable": true
//		},
//		"fixPose": "false",
//		"previewImg": "./PicCard.png",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H54B0SFC4",
//			"editVersion": 8,
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H599SSCN0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H59BOAKE0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H59BOAKE1",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H59BOAKE2",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H59BOAKE3",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H59BOAKE4",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H59CICIB0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H59CISV50",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H54B0SFB1",
//			"editVersion": 23,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H54B0SFC5",
//					"editVersion": 116,
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "38",
//						"y": "26",
//						"w": "300",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "#(pic&&picH>0)?picH+20:30",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex Y",
//						"traceSize": "true",
//						"subAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H54B23MV0",
//							"editVersion": 46,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H572GMLL0",
//									"editVersion": 228,
//									"attrs": {
//										"type": "box",
//										"id": "BG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,0]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBodyLit",
//										"corner": "6",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H572GMLL1",
//									"editVersion": 12,
//									"attrs": {
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV51",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CISV52",
//													"editVersion": 12,
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBodyLit"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV53",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CISV54",
//													"editVersion": 16,
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "2",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBody"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV55",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CISV56",
//													"editVersion": 16,
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "2",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBody"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										},
//										"1H59CICIB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV57",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CISV58",
//													"editVersion": 8,
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBodyLit"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CICIB0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H572GMLL2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H572GMLL3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H59BTTB30",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H59C42NS0",
//									"editVersion": 144,
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "10",
//										"y": "50%",
//										"w": "#picW||100",
//										"h": "#picH||picW||100",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBody\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!pic",
//										"maskImage": "#pic"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H59C42NS1",
//									"editVersion": 10,
//									"attrs": {
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV59",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CISV510",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV511",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CISV512",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV513",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CISV514",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H59C42NS2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H59C42NS3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H5721BRE0",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H57290200",
//									"editVersion": 172,
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "#(pic&&picW>0)?picW+10:0",
//										"y": "0",
//										"w": "#(pic&&picW>0)?`FW-${picW+30}`:\"FW\"",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBody",
//										"text": "#title",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "true",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H57290201",
//									"editVersion": 14,
//									"attrs": {
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV517",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CISV518",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV519",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CISV520",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV521",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CISV522",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H57290202",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H57290203",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H572917N0",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H572917N1",
//									"editVersion": 182,
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "#(pic&&picW>0)?picW+10:0",
//										"y": "0",
//										"w": "#(pic&&picW>0)?`FW-${picW+30}`:\"FW-20\"",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "#intro",
//										"font": "",
//										"fontSize": "#txtSize.mid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "true",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H572917O0",
//									"editVersion": 14,
//									"attrs": {
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV525",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CISV526",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV527",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CISV528",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CISV529",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CISV530",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H572917O1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H572917O2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H54B0SFC6",
//					"editVersion": 14,
//					"attrs": {
//						"1H599SSCN0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CISV533",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H59CISV534",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H599SSCN0",
//							"faceTagName": "up"
//						},
//						"1H59BOAKE1": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CISV535",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H59CISV536",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H59BOAKE1",
//							"faceTagName": "over"
//						},
//						"1H59BOAKE3": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CISV537",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H59CISV538",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H59BOAKE3",
//							"faceTagName": "down"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H54B0SFC7",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H54B0SFC8",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H54B0SFC9",
//			"editVersion": 112,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "true",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "true",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"enable": "true",
//				"drag": "true"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}