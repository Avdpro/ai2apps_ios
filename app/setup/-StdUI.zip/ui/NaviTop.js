//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "./BtnIcon.js";
/*#{1H2CQBSVI0StartDoc*/
import DlgMenu from "./DlgMenu.js";
/*}#1H2CQBSVI0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let NaviTop=function(title,bgColor,color,logoIcon,menuIcon,menuItems){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let naviItems,itemsRight;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7DITA1LocalVals*/
	let app=window.tabOSApp;
	let isMobile=false;
	/*}#1H1T7DITA1LocalVals*/
	
	/*#{1H1T7DITA1PreState*/
	/*}#1H1T7DITA1PreState*/
	/*#{1H1T7DITA1PostState*/
	/*}#1H1T7DITA1PostState*/
	cssVO={
		"hash":"1H1T7DITA1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":40,"padding":[5,35,5,5],"styleClass":"","contentLayout":"flex-x","traceSize":true,
		children:[
			{
				"hash":"1H1TB73370",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","padding":5,"styleClass":"","background":bgColor,"contentLayout":"flex-x",
			},
			{
				"hash":"1H1TBM5HJ0",
				"type":BtnIcon(color,30,0,logoIcon,null),"id":"BtnHome","position":"relative","x":0,"y":0,"border":0,
				"OnClick":function(event){
					/*#{1H1TNA1270FunctionBody*/
					if(self.OnHomeClick){
						self.OnHomeClick();
					}
					/*}#1H1TNA1270FunctionBody*/
				},
			},
			{
				"hash":"1H1TBHQJ30",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"","h":"100%","styleClass":"","color":color,"text":title,"fontSize":txtSize.big,
				"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1H1TBOLJK0",
				"type":BtnIcon(color,30,0,menuIcon,null),"id":"BtnMenu","x":">calc(100% - 5px)","y":"50%","anchorX":2,"anchorY":1,
				"OnClick":function(event){
					/*#{1H1TM72AV0FunctionBody*/
					self.showMenu();
					/*}#1H1TM72AV0FunctionBody*/
				},
			},
			{
				"hash":"1H2CQI73O0",
				"type":"hud","id":"NaviItems","position":"relative","x":0,"y":0,"w":20,"h":"100%","margin":[0,0,0,20],"styleClass":"","flex":true,"contentLayout":"flex-x",
			},
			{
				"hash":"1H2CQTOQC0",
				"type":"hud","id":"ItemsRight","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":10,"styleClass":"","contentLayout":"flex-x",
			}
		],
		/*#{1H1T7DITA1ExtraCSS*/
		/*}#1H1T7DITA1ExtraCSS*/
		faces:{
			"desktop":{
				/*NaviItems*/"#1H2CQI73O0":{
					"display":1
				},
				/*ItemsRight*/"#1H2CQTOQC0":{
					"display":1
				},
				/*#{1H1TBU4LI0Code*/
				$(){
					isMobile=false;
				}
				/*}#1H1TBU4LI0Code*/
			},"mobile":{
				/*NaviItems*/"#1H2CQI73O0":{
					"display":0
				},
				/*ItemsRight*/"#1H2CQTOQC0":{
					"display":0
				},
				/*#{1H1TBU4LI2Code*/
				$(){
					isMobile=true;
				}
				/*}#1H1TBU4LI2Code*/
			}
		},
		OnCreate:function(){
			self=this;
			naviItems=self.NaviItems;itemsRight=self.ItemsRight;
			/*#{1H1T7DITA1Create*/
			/*}#1H1T7DITA1Create*/
		},
		/*#{1H1T7DITA1EndCSS*/
		/*}#1H1T7DITA1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnSize=function(){
		/*#{1H5RDNHI30FunctionBody*/
		let w=self.w;
		if(w<500){
			if(!isMobile){
				self.showFace("mobile");
			}
		}else if(w>=500){
			if(isMobile){
				self.showFace("desktop");
			}
		}
		/*}#1H5RDNHI30FunctionBody*/
	};
	/*#{1H1T7DITA1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showMenu=function(){
		let items=menuItems;
		if(!items){
			return;
		}
		if(items instanceof Function){
			items=items();
		}
		app.showDlg(DlgMenu,{
			items:items,
			hud:self.BtnMenu,
			callback(item){
				if(item){
					if(self.OnMenuItem){
						self.OnMenuItem(item);
					}
				}
			}
		});
	};
	/*}#1H1T7DITA1PostCSSVO*/
	return cssVO;
};
/*#{1H1T7DITA1ExCodes*/
/*}#1H1T7DITA1ExCodes*/

NaviTop.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":(($ln==="CN")?("顶部导航栏"):("Top Navi Bar")),icon:"gears.svg",previewImg:"./NaviTop.png",
	fixPose:true,initW:500,initH:60,
	"desc":(($ln==="CN")?("简单网站头部，支持移动端和桌面模式。"):("Simple web site header, support both motile and desktop mode.")),
	catalog:"Views",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Cool Site Name", "localizable": true
		}, 
		"bgColor": {
			"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [108,117,125,1]
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [255,255,255,1]
		}, 
		"logoIcon": {
			"name": "logoIcon", "showName": "logoIcon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/cklogo.svg"
		}, 
		"menuIcon": {
			"name": "menuIcon", "showName": "menuIcon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/menu.svg"
		}, 
		"menuItems": {
			"name": "menuItems", "showName": "menuItems", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["desktop","mobile"],
	subContainers:{
		"1H2CQI73O0":{"showName":"NaviItems","contentLayout":"flex-x"},
		"1H2CQTOQC0":{"showName":"ItemsRight","contentLayout":"flex-x"}
	},
	/*#{1H2CQBSVI0ExGearInfo*/
	/*}#1H2CQBSVI0ExGearInfo*/
};
export default NaviTop;
export{NaviTop};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1H2CQBSVI0",
//	"editVersion": 157,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H1T7DITB0",
//			"editVersion": 18,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "800",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H1T7DITB1",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H5BULA7L0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1T7DITB2",
//			"editVersion": 118,
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Cool Site Name",
//					"localizable": true
//				},
//				"bgColor": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor.secondary"
//				},
//				"color": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor.fontSecondary"
//				},
//				"logoIcon": {
//					"type": "url",
//					"valText": "#appCfg.sharedAssets+\"/cklogo.svg\""
//				},
//				"menuIcon": {
//					"type": "url",
//					"valText": "#appCfg.sharedAssets+\"/menu.svg\""
//				},
//				"menuItems": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1T7DITB3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H1T7DITB4",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Top Navi Bar",
//			"localize": {
//				"EN": "Top Navi Bar",
//				"CN": "顶部导航栏"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "500",
//		"gearH": "60",
//		"gearCatalog": "Views",
//		"description": {
//			"type": "string",
//			"valText": "Simple web site header, support both motile and desktop mode.",
//			"localize": {
//				"EN": "Simple web site header, support both motile and desktop mode.",
//				"CN": "简单网站头部，支持移动端和桌面模式。"
//			},
//			"localizable": true
//		},
//		"fixPose": "true",
//		"previewImg": "./NaviTop.png",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H1T7DITB5",
//			"editVersion": 4,
//			"attrs": {
//				"desktop": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TBU4LI0",
//					"editVersion": 10,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1TBU4LI1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"mobile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TBU4LI2",
//					"editVersion": 10,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1TBU4LI3",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7DITA1",
//			"editVersion": 22,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H1T7DITB6",
//					"editVersion": 100,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "40",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[5,35,5,5]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"traceSize": "true"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1TB73370",
//							"editVersion": 47,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TBU4LI4",
//									"editVersion": 120,
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "5",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#bgColor",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"flex": "false",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1TBU4LI5",
//									"editVersion": 8,
//									"attrs": {
//										"1H1TBU4LI0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TM2SJ10",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1TM2SJ11",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TBU4LI0",
//											"faceTagName": "desktop"
//										},
//										"1H1TBU4LI2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2D0F3200",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2D0F3201",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TBU4LI2",
//											"faceTagName": "mobile"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1TBU4LI6",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1TBU4LI7",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1H1TBM5HJ0",
//							"editVersion": 122,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1H1TBU4LI8",
//									"editVersion": 76,
//									"attrs": {
//										"style": "#color",
//										"w": "30",
//										"h": "0",
//										"icon": "#logoIcon",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TBU4LI9",
//									"editVersion": 71,
//									"attrs": {
//										"type": "#null#>BtnIcon(color,30,0,logoIcon,null)",
//										"id": "BtnHome",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"border": {
//											"type": "int",
//											"valText": "0"
//										}
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1TBU4LI10",
//									"editVersion": 8,
//									"attrs": {
//										"1H1TBU4LI0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TM2SJ12",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1TM2SJ13",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TBU4LI0",
//											"faceTagName": "desktop"
//										},
//										"1H1TBU4LI2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2D0F3202",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2D0F3203",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TBU4LI2",
//											"faceTagName": "mobile"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1TBU4LI11",
//									"editVersion": 2,
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H1TNA1270",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1H1TNAGLH0",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1TBU4LI12",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1H22VJR100",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1TBHQJ30",
//							"editVersion": 45,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TBU4LI13",
//									"editVersion": 154,
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#color",
//										"text": "#title",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false",
//										"flex": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1TBU4LI14",
//									"editVersion": 8,
//									"attrs": {
//										"1H1TBU4LI0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TM2SJ14",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1TM2SJ15",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TBU4LI0",
//											"faceTagName": "desktop"
//										},
//										"1H1TBU4LI2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2D0F3204",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2D0F3205",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TBU4LI2",
//											"faceTagName": "mobile"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1TBU4LI15",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1TBU4LI16",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1KJQ5RK0",
//							"jaxId": "1H1TBOLJK0",
//							"editVersion": 101,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1H1TBU4LI17",
//									"editVersion": 46,
//									"attrs": {
//										"style": "#color",
//										"w": "30",
//										"h": "0",
//										"icon": "#menuIcon",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TBU4LI18",
//									"editVersion": 90,
//									"attrs": {
//										"type": "#null#>BtnIcon(color,30,0,menuIcon,null)",
//										"id": "BtnMenu",
//										"position": "Absolute",
//										"x": "100%-5",
//										"y": "50%",
//										"display": "On",
//										"face": "",
//										"anchorH": "Right",
//										"autoLayout": "false",
//										"anchorV": "Center"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1TBU4LI19",
//									"editVersion": 8,
//									"attrs": {
//										"1H1TBU4LI0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TM2SJ16",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1TM2SJ17",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TBU4LI0",
//											"faceTagName": "desktop"
//										},
//										"1H1TBU4LI2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2D0F3206",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2D0F3207",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TBU4LI2",
//											"faceTagName": "mobile"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1TBU4LI20",
//									"editVersion": 2,
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H1TM72AV0",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1H1TM7AO40",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1TBU4LI21",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1H22VJR101",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H2CQI73O0",
//							"editVersion": 68,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2CQSQIG0",
//									"editVersion": 104,
//									"attrs": {
//										"type": "hud",
//										"id": "NaviItems",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "20",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,20]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true",
//										"contentLayout": "Flex X",
//										"subAlign": "Start"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H2CQSQIG1",
//									"editVersion": 4,
//									"attrs": {
//										"1H1TBU4LI0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2D0F3208",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2D0F3209",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TBU4LI0",
//											"faceTagName": "desktop"
//										},
//										"1H1TBU4LI2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2D0F32010",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2D0F32011",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TBU4LI2",
//											"faceTagName": "mobile"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H2CQSQIG2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H2CQSQIG3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H2CQTOQC0",
//							"editVersion": 65,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2CQTOQC1",
//									"editVersion": 100,
//									"attrs": {
//										"type": "hud",
//										"id": "ItemsRight",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "10",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H2CQTOQC2",
//									"editVersion": 4,
//									"attrs": {
//										"1H1TBU4LI0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2D0F32012",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2D0F32013",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TBU4LI0",
//											"faceTagName": "desktop"
//										},
//										"1H1TBU4LI2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H2D0F32014",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H2D0F32015",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TBU4LI2",
//											"faceTagName": "mobile"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H2CQTOQC3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H2CQTOQC4",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H1T7DITB7",
//					"editVersion": 8,
//					"attrs": {
//						"1H1TBU4LI0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1TM2SJ112",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1TM2SJ113",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TBU4LI0",
//							"faceTagName": "desktop"
//						},
//						"1H1TBU4LI2": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H2D0F32016",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H2D0F32017",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TBU4LI2",
//							"faceTagName": "mobile"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H1T7DITB8",
//					"editVersion": 2,
//					"attrs": {
//						"OnSize": {
//							"type": "fixedFunc",
//							"jaxId": "1H5RDNHI30",
//							"editVersion": 2,
//							"attrs": {
//								"callArgs": {
//									"type": "object",
//									"jaxId": "1H5RDR03O0",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						}
//					}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H1T7DITB9",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "true",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7DITB10",
//			"editVersion": 80,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}