//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnCheck} from "./BtnCheck.js";
/*#{1H1O4B7OK0StartDoc*/
/*}#1H1O4B7OK0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnObject=function(obj,converter){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnCheck;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1O4B7OK1LocalVals*/
	if(converter){
		obj=converter(obj);
	}
	/*}#1H1O4B7OK1LocalVals*/
	
	/*#{1H1O4B7OK1PreState*/
	/*}#1H1O4B7OK1PreState*/
	state={
		"fontSize":txtSize.smallPlus,
		/*#{1H1O4B7OL4ExState*/
		/*}#1H1O4B7OL4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1O4B7OK1PostState*/
	/*}#1H1O4B7OK1PostState*/
	cssVO={
		"hash":"1H1O4B7OK1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":24,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","enable":obj.enable===false?false:true,
		"contentLayout":"flex-x","traceSize":true,"itemsAlign":1,
		"obj":obj,
		children:[
			{
				"hash":"1H1O6BJ290",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[0,0,0,0],
			},
			{
				"hash":"1H1O5PAKH0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":"FH-4","h":"FH-4","autoLayout":true,"margin":[0,3,0,0],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","background":obj.iconColor||obj.color||cfgColor.fontBody,"attached":(!!obj.icon)||(obj.icon===""),"maskImage":obj.icon,
			},
			{
				"hash":"1HAAHR1A50",
				"type":BtnCheck(state.fontSize+4,"",obj.checked,false),"id":"BtnCheck","position":"relative","x":0,"y":0,"margin":[0,5,0,0],"attached":!!obj.selectable,
			},
			{
				"hash":"1H1O5T0HD0",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":obj.color||cfgColor.fontBody,
				"text":obj.text,"fontSize":$P(()=>(state.fontSize),state),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1H1O640F30",
				"type":"box","id":"BoxCheck","x":">calc(100% - 5px)","y":"50%","w":"FH-6","h":"FH-6","anchorX":2,"anchorY":1,"display":(!!obj.check&&(!obj.selectable)),
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":obj.color||cfgColor.fontBody,"border":1,"maskImage":appCfg.sharedAssets+"/check_fat.svg",
				"attached":("check" in obj),
			}
		],
		get $$fontSize(){return state["fontSize"]},
		set $$fontSize(v){
			state["fontSize"]=v;
			/*#{1H1O4B7OK1SetfontSize*/
			/*}#1H1O4B7OK1SetfontSize*/
		},
		/*#{1H1O4B7OK1ExtraCSS*/
		/*}#1H1O4B7OK1ExtraCSS*/
		faces:{
			"up":{
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":[0,0,0,0]
				}
			},"over":{
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemOver"]
				}
			},"down":{
				"#self":{
					"alpha":1
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":cfgColor["itemDown"]
				}
			},"gray":{
				"#self":{
					"alpha":0.5
				},
				/*BoxBG*/"#1H1O6BJ290":{
					"background":[0,0,0,0]
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnCheck=self.BtnCheck;
			/*#{1H1O4B7OK1Create*/
			this.preferW=this.webObj.scrollWidth;
			/*}#1H1O4B7OK1Create*/
		},
		/*#{1H1O4B7OK1EndCSS*/
		/*}#1H1O4B7OK1EndCSS*/
	};
	/*#{1H1O4B7OK1PostCSSVO*/
	/*}#1H1O4B7OK1PostCSSVO*/
	return cssVO;
};
/*#{1H1O4B7OK1ExCodes*/
/*}#1H1O4B7OK1ExCodes*/

BtnObject.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("对象行"):("Object Line")),icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:24,
	catalog:"Buttons",
	args: {
		"obj": {
			"name": "obj", "showName": "obj", "type": "auto", "key": true, "fixed": true, 
			"initVal": {"text":"Object","selectable":true,"checked":true}
		}, 
		"converter": {
			"name": "converter", "showName": "converter", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
		fontSize:{name:"fontSize",type:"int",initVal:14,editType:"fontSize"}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","rotate","scale","cursor","zIndex","margin","minW","minH","maxW","maxH","enable","attach"],
	faces:["up","over","down","gray"],
	subContainers:{
	},
	/*#{1H1O4B7OK0ExGearInfo*/
	/*}#1H1O4B7OK0ExGearInfo*/
};
export default BtnObject;
export{BtnObject};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H1O4B7OK0",
//	"editVersion": 139,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H1O4B7OL0",
//			"editVersion": 10,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H1O4B7OL1",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H5VFJH9A0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1O4B7OL2",
//			"editVersion": 118,
//			"attrs": {
//				"obj": {
//					"type": "auto",
//					"valText": "#{\"text\":\"Object\",selectable:true,checked:false,checked:true}"
//				},
//				"converter": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1O4B7OL3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H1O4B7OL4",
//			"editVersion": 24,
//			"attrs": {
//				"fontSize": {
//					"type": "int",
//					"valText": "#txtSize.smallPlus",
//					"editType": "fontSize"
//				}
//			}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Object Line",
//			"localize": {
//				"EN": "Object Line",
//				"CN": "对象行"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "24",
//		"gearCatalog": "Buttons",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H1O4B7OL5",
//			"editVersion": 8,
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6SN0K0",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1O6TNKJ0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6SMEQ0",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1O6TNKJ1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6TNKJ2",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1O6TNKJ3",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1O6TNKJ4",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1O6TNKJ5",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HAAHAJUP0",
//			"editVersion": 15,
//			"attrs": {
//				"Text Only": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAHPAT91",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1H1O4B7OL2",
//							"editVersion": 80,
//							"attrs": {
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\"}"
//								},
//								"converter": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1H1O4B7OL4",
//							"editVersion": 24,
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.smallPlus",
//									"editType": "fontSize"
//								}
//							}
//						}
//					}
//				},
//				"Icon with text": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAI4JQ00",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1H1O4B7OL2",
//							"editVersion": 106,
//							"attrs": {
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",\"icon\":appCfg.sharedAssets+\"/prj.svg\",\"iconColor\":[0,0,0,1]}"
//								},
//								"converter": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1H1O4B7OL4",
//							"editVersion": 24,
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.smallPlus",
//									"editType": "fontSize"
//								}
//							}
//						}
//					}
//				},
//				"Color and checked": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAHPAT90",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1H1O4B7OL2",
//							"editVersion": 74,
//							"attrs": {
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",\"icon\":\"\",\"iconColor\":[255,0,0,1],\"check\":true,\"enable\":false}"
//								},
//								"converter": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1H1O4B7OL4",
//							"editVersion": 24,
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.smallPlus",
//									"editType": "fontSize"
//								}
//							}
//						}
//					}
//				},
//				"Selectable": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAI4JQ01",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1H1O4B7OL2",
//							"editVersion": 112,
//							"attrs": {
//								"obj": {
//									"type": "auto",
//									"valText": "#{\"text\":\"Object\",selectable:true,checked:false}"
//								},
//								"converter": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1H1O4B7OL4",
//							"editVersion": 24,
//							"attrs": {
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.smallPlus",
//									"editType": "fontSize"
//								}
//							}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1O4B7OK1",
//			"editVersion": 29,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H1O4B7OL6",
//					"editVersion": 110,
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "24",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[0,5,0,5]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "#obj.enable===false?false:true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"traceSize": "true",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1O6BJ290",
//							"editVersion": 39,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1O6PGCJ0",
//									"editVersion": 112,
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[0,0,0,0]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1O6PGCJ1",
//									"editVersion": 8,
//									"attrs": {
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O6TNKJ6",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1O6TNKJ7",
//													"editVersion": 8,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemOver\"]"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O6TNKJ8",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1O6TNKJ9",
//													"editVersion": 8,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU0",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1O7E6EU1",
//													"editVersion": 16,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemDown\"]"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										},
//										"1H1O6TNKJ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU2",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1O7E6EU3",
//													"editVersion": 4,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ4",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1O6PGCJ2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1O6PGCJ3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1O5PAKH0",
//							"editVersion": 25,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1O657LG0",
//									"editVersion": 176,
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"FH-4\"",
//										"h": "\"FH-4\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,3,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#obj.iconColor||obj.color||cfgColor.fontBody",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#(!!obj.icon)||(obj.icon===\"\")",
//										"maskImage": "#obj.icon"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1O657LG1",
//									"editVersion": 26,
//									"attrs": {
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O6TNKJ10",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1O6TNKJ11",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU4",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1O7E6EU5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU6",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1O7E6EU7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1O657LG2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1O657LG3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1H1LD0QTJ0",
//							"jaxId": "1HAAHR1A50",
//							"editVersion": 54,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HAAHR1A51",
//									"editVersion": 38,
//									"attrs": {
//										"size": "#state.fontSize+4",
//										"text": "",
//										"checked": "#obj.checked",
//										"radio": "false"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAAHR1A52",
//									"editVersion": 53,
//									"attrs": {
//										"type": "#null#>BtnCheck(state.fontSize+4,\"\",obj.checked,false)",
//										"id": "BtnCheck",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"margin": "[0,5,0,0]",
//										"attach": "#!!obj.selectable"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAAHR1A53",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAAHR1A54",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAAHR1A55",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HAAHR1A56",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1O5T0HD0",
//							"editVersion": 25,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1O657LG4",
//									"editVersion": 138,
//									"attrs": {
//										"type": "text",
//										"id": "TxtName",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#obj.color||cfgColor.fontBody",
//										"text": "#obj.text",
//										"font": "",
//										"fontSize": "${state.fontSize},state",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1O657LG5",
//									"editVersion": 26,
//									"attrs": {
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O6TNKJ12",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1O6TNKJ13",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU8",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1O7E6EU9",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU10",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1O7E6EU11",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1O657LG6",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1O657LG7",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1O640F30",
//							"editVersion": 25,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1O657LG8",
//									"editVersion": 172,
//									"attrs": {
//										"type": "box",
//										"id": "BoxCheck",
//										"position": "Absolute",
//										"x": "100%-5",
//										"y": "50%",
//										"w": "\"FH-6\"",
//										"h": "\"FH-6\"",
//										"anchorH": "Right",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "#(!!obj.check&&(!obj.selectable))",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#obj.color||cfgColor.fontBody",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#appCfg.sharedAssets+\"/check_fat.svg\"",
//										"attach": "#(\"check\" in obj)"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1O657LG9",
//									"editVersion": 26,
//									"attrs": {
//										"1H1O6SMEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O6TNKJ14",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1O6TNKJ15",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SMEQ0",
//											"faceTagName": "over"
//										},
//										"1H1O6SN0K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU12",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1O7E6EU13",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6SN0K0",
//											"faceTagName": "up"
//										},
//										"1H1O6TNKJ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1O7E6EU14",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1O7E6EU15",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1O6TNKJ2",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1O657LG10",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1O657LG11",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H1O4B7OL7",
//					"editVersion": 12,
//					"attrs": {
//						"1H1O6SMEQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O6TNKJ16",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1O6TNKJ17",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6SMEQ0",
//							"faceTagName": "over"
//						},
//						"1H1O6SN0K0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O7E6EU16",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1O7E6EU17",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6SN0K0",
//							"faceTagName": "up"
//						},
//						"1H1O6TNKJ2": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O7E6EU18",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1O7E6EU19",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6TNKJ2",
//							"faceTagName": "down"
//						},
//						"1H1O6TNKJ4": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1O7E6EU20",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1O7E6EU21",
//									"editVersion": 14,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.5",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1O6TNKJ4",
//							"faceTagName": "gray"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H1O4B7OL8",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H1O4B7OL9",
//					"editVersion": 8,
//					"attrs": {
//						"obj": {
//							"type": "auto",
//							"valText": "#obj"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1O4B7OL10",
//			"editVersion": 122,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"enable": "true",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "fontSize"
//				}
//			]
//		}
//	}
//}