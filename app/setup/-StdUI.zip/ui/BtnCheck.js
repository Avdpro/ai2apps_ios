//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1H1LD0QTJ0StartDoc*/
/*}#1H1LD0QTJ0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnCheck=function(size,text,checked,radio){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1LD0QTJ1LocalVals*/
	/*}#1H1LD0QTJ1LocalVals*/
	
	/*#{1H1LD0QTJ1PreState*/
	/*}#1H1LD0QTJ1PreState*/
	state={
		"fontSize":size>0?(size>17?size-5:12):16,"text":text,"checked":checked,"color":cfgColor.fontBody,
		/*#{1H1LD0QTK4ExState*/
		/*}#1H1LD0QTK4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1LD0QTJ1PostState*/
	/*}#1H1LD0QTJ1PostState*/
	cssVO={
		"hash":"1H1LD0QTJ1",nameHost:true,
		"type":"button","x":138,"y":165,"w":"","h":size,"cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		"traceSize":true,
		children:[
			{
				"hash":"1H1LDAK720",
				"type":"box","id":"BoxSlot","position":"relative","x":0,"y":0,"w":"FH","h":"FH","autoLayout":true,"uiEvent":-1,"padding":radio?3:0,"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","background":[0,0,0,0],"border":1,"borderColor":$P(()=>(state.color),state),"corner":radio?100:0,
				children:[
					{
						"hash":"1H1LDP68F0",
						"type":"box","id":"BoxMark","position":"relative","x":0,"y":0,"w":"100%","h":"100%","display":$P(()=>(!!state.checked),state),"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","background":$P(()=>(state.color),state),"corner":radio?100:0,"maskImage":radio?"":appCfg.sharedAssets+"/check_fat.svg",
					}
				],
			},
			{
				"hash":"1H1LDI5G40",
				"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":$P(()=>(state.color),state),"text":$P(()=>(state.text),state),"fontSize":$P(()=>(state.fontSize),state),"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,"attached":!!text,
			}
		],
		get $$checked(){return state["checked"]},
		set $$checked(v){
			state["checked"]=v;
			/*#{1H1LD0QTJ1Setchecked*/
			/*}#1H1LD0QTJ1Setchecked*/
		},
		get $$text(){return state["text"]},
		set $$text(v){
			state["text"]=v;
			/*#{1H1LD0QTJ1Settext*/
			/*}#1H1LD0QTJ1Settext*/
		},
		get $$fontSize(){return state["fontSize"]},
		set $$fontSize(v){
			state["fontSize"]=v;
			/*#{1H1LD0QTJ1SetfontSize*/
			/*}#1H1LD0QTJ1SetfontSize*/
		},
		get $$color(){return state["color"]},
		set $$color(v){
			state["color"]=v;
			/*#{1H1LD0QTJ1Setcolor*/
			/*}#1H1LD0QTJ1Setcolor*/
		},
		/*#{1H1LD0QTJ1ExtraCSS*/
		/*}#1H1LD0QTJ1ExtraCSS*/
		faces:{
			"up":{
				"#self":{
					"alpha":1
				},
				/*BoxSlot*/"#1H1LDAK720":{
					"background":[0,0,0,0]
				}
			},"over":{
				"#self":{
					"alpha":1
				},
				/*BoxSlot*/"#1H1LDAK720":{
					"background":[...cfgColor.primary,80]
				}
			},"down":{
				"#self":{
					"alpha":1
				},
				/*BoxSlot*/"#1H1LDAK720":{
					"background":[...cfgColor.primary,-20]
				}
			},"gray":{
				"#self":{
					"alpha":0.6
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H1LD0QTJ1Create*/
			/*}#1H1LD0QTJ1Create*/
		},
		/*#{1H1LD0QTJ1EndCSS*/
		/*}#1H1LD0QTJ1EndCSS*/
	};
	/*#{1H1LD0QTJ1PostCSSVO*/
	cssVO.OnClick=function(){
		state.checked=!state.checked;
		if(this.OnCheck){
			this.OnCheck(state.checked);
		}
	};
	/*}#1H1LD0QTJ1PostCSSVO*/
	return cssVO;
};
/*#{1H1LD0QTJ1ExCodes*/
/*}#1H1LD0QTJ1ExCodes*/

BtnCheck.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("选择/单选"):("Check / Raido")),icon:"btn_check.svg",previewImg:"./CheckBtn.png",
	fixPose:false,initW:100,initH:20,
	"desc":"Check or radio button with text",
	catalog:"Buttons",
	args: {
		"size": {
			"name": "size", "showName": "size", "type": "int", "key": true, "fixed": true, "initVal": 20
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Check button", "localizable": true
		}, 
		"checked": {
			"name": "checked", "showName": "checked", "type": "bool", "key": true, "fixed": true, "initVal": true
		}, 
		"radio": {
			"name": "radio", "showName": "radio", "type": "bool", "key": true, "fixed": true, "initVal": false
		}
	},
	state:{
		checked:{name:"checked",type:"bool",initVal:true},
		text:{name:"text",type:"string",initVal:"Check button",localizable:true},
		fontSize:{name:"fontSize",type:"int",initVal:15},
		color:{name:"color",type:"colorRGBA",initVal:[0,0,0,1]}
	},
	properties:["id","position","x","y","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","enable","attach"],
	faces:["up","over","down","gray"],
	subContainers:{
	},
	/*#{1H1LD0QTJ0ExGearInfo*/
	/*}#1H1LD0QTJ0ExGearInfo*/
};
export default BtnCheck;
export{BtnCheck};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H1LD0QTJ0",
//	"editVersion": 199,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H1LD0QTK0",
//			"editVersion": 16,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H1LD0QTK1",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H8GLJIRJ0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1LD0QTK2",
//			"editVersion": 96,
//			"attrs": {
//				"size": {
//					"type": "int",
//					"valText": "20"
//				},
//				"text": {
//					"type": "string",
//					"valText": "Check button",
//					"localizable": true
//				},
//				"checked": {
//					"type": "bool",
//					"valText": "true"
//				},
//				"radio": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1LD0QTK3",
//			"editVersion": 12,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H1LD0QTK4",
//			"editVersion": 70,
//			"attrs": {
//				"fontSize": {
//					"type": "int",
//					"valText": "#size>0?(size>17?size-5:12):16"
//				},
//				"text": {
//					"type": "string",
//					"valText": "#text",
//					"localizable": true
//				},
//				"checked": {
//					"type": "bool",
//					"valText": "#checked"
//				},
//				"color": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor.fontBody"
//				}
//			}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Check / Raido",
//			"localize": {
//				"EN": "Check / Raido",
//				"CN": "选择/单选"
//			},
//			"localizable": true
//		},
//		"gearIcon": "btn_check.svg",
//		"gearW": "100",
//		"gearH": "20",
//		"gearCatalog": "Buttons",
//		"description": "Check or radio button with text",
//		"fixPose": "false",
//		"previewImg": "./CheckBtn.png",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H1LD0QTK5",
//			"editVersion": 18,
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LEB2U80",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1LEB2U81",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LEB2U82",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1LEB2U83",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LEB2U84",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1LEB2U85",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1LEB2U86",
//					"editVersion": 8,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H1LEB2U87",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HAAUA6DP0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1LD0QTJ1",
//			"editVersion": 32,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H1LD0QTK6",
//					"editVersion": 98,
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "138",
//						"y": "165",
//						"w": "\"\"",
//						"h": "#size",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex X"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1LDAK720",
//							"editVersion": 34,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1LEB2U88",
//									"editVersion": 140,
//									"attrs": {
//										"type": "box",
//										"id": "BoxSlot",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"FH\"",
//										"h": "\"FH\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "#radio?3:0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[0,0,0,0]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "${state.color},state",
//										"corner": "#radio?100:0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1H1LDP68F0",
//											"editVersion": 29,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1LEB2U89",
//													"editVersion": 200,
//													"attrs": {
//														"type": "box",
//														"id": "BoxMark",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "${!!state.checked},state",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "${state.color},state",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "#radio?100:0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#radio?\"\":appCfg.sharedAssets+\"/check_fat.svg\""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1H1LEB2U810",
//													"editVersion": 32,
//													"attrs": {
//														"1H1LEB2U80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LET8380",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H1LET8381",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LEB2U80",
//															"faceTagName": "up"
//														},
//														"1H1LEB2U82": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LET8382",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H1LET8383",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LEB2U82",
//															"faceTagName": "over"
//														},
//														"1H1LEB2U84": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H1LRH88B0",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1H1LRH88B1",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1LEB2U84",
//															"faceTagName": "down"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1H1LEB2U811",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H1LEB2U812",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1LEB2U813",
//									"editVersion": 30,
//									"attrs": {
//										"1H1LEB2U80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LET8384",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1LET8385",
//													"editVersion": 8,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LEB2U80",
//											"faceTagName": "up"
//										},
//										"1H1LEB2U82": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LET8386",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1LET8387",
//													"editVersion": 8,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#[...cfgColor.primary,80]"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LEB2U82",
//											"faceTagName": "over"
//										},
//										"1H1LEB2U84": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LET8388",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1LET8389",
//													"editVersion": 8,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#[...cfgColor.primary,-20]"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LEB2U84",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1LEB2U814",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1LEB2U815",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1LDI5G40",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1LEB2U816",
//									"editVersion": 156,
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,3]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "${state.color},state",
//										"text": "${state.text},state",
//										"font": "",
//										"fontSize": "${state.fontSize},state",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false",
//										"attach": "#!!text"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1LEB2U817",
//									"editVersion": 34,
//									"attrs": {
//										"1H1LEB2U80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LET83810",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1LET83811",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LEB2U80",
//											"faceTagName": "up"
//										},
//										"1H1LEB2U82": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LET83812",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1LET83813",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LEB2U82",
//											"faceTagName": "over"
//										},
//										"1H1LEB2U84": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1LRH88B2",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H1LRH88B3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1LEB2U84",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1LEB2U818",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1LEB2U819",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H1LD0QTK7",
//					"editVersion": 24,
//					"attrs": {
//						"1H1LEB2U80": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LET83814",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1LET83815",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LEB2U80",
//							"faceTagName": "up"
//						},
//						"1H1LEB2U82": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LET83816",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1LET83817",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LEB2U82",
//							"faceTagName": "over"
//						},
//						"1H1LEB2U84": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LET83818",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1LET83819",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LEB2U84",
//							"faceTagName": "down"
//						},
//						"1H1LEB2U86": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1LET83820",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1LET83821",
//									"editVersion": 20,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.6",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1LEB2U86",
//							"faceTagName": "gray"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H1LD0QTK8",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H1LD0QTK9",
//					"editVersion": 6,
//					"attrs": {
//						"traceSize": {
//							"type": "bool",
//							"valText": "true"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1LD0QTK10",
//			"editVersion": 104,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "true",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "checked"
//				},
//				{
//					"type": "string",
//					"valText": "text"
//				},
//				{
//					"type": "string",
//					"valText": "fontSize"
//				},
//				{
//					"type": "string",
//					"valText": "color"
//				}
//			]
//		}
//	}
//}