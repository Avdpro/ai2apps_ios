//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnTextIcon} from "/@StdUI/ui/BtnTextIcon.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HB7QO7FS0StartDoc*/
import {tabNT} from "/@tabos/tabos_nt.js";
import {tabOS,tabFS} from "/@tabos";
import pathLib from "/@path";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {readSystemAIShortcuts,saveSystemAIShortcuts} from "../chathome.js";
import {BoxCatalog} from "./BoxCatalog.js";
import {DlgAddShortCut} from "./DlgAddShortCut.js";
/*}#1HB7QO7FS0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgAIChatHome=function(app,appFrame){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxContent;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7ISV51LocalVals*/
	let dlgVO,catalogBoxes,rootApp;
	const catalogDefs={
		"code":{name:"code",text:(($ln==="CN")?("编程"):/*EN*/("Coding"))},
		"tools":{name:"tools",text:(($ln==="CN")?("工具"):/*EN*/("Tools"))},
		"relax":{name:"relax",text:(($ln==="CN")?("娱乐"):/*EN*/("Relaxing"))},
	};
	const styleDefs={
		"chat":{name:"chat",text:"Bubble chat",size:[375,640],bubble:true},
		"pro":{name:"pro",text:"Perfectional dialog",size:[1000,640],bubble:false},
		"mini":{name:"mini",text:"Mini tool",size:[375,320],bubble:false},
	};
	
	rootApp=appFrame?appFrame.app:app;
	dlgVO=null;
	catalogBoxes={};
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","padding":[10,10,20,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"borderColor":cfgColor["fontBodySub"],
				"corner":5,"shadowX":3,"shadowY":6,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("AI 助理"):("AI Agents")),"fontSize":txtSize.bigPlus,"fontWeight":"bold","fontStyle":"normal",
				"textDecoration":"","alignH":1,"alignV":1,
			},
			{
				"hash":"1HBCKC4390",
				"type":"text","id":"TxtLogin","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor["fontBody"],"text":(($ln==="CN")?("请注意：要使用AI相关功能，需要先登录您的Tab-OS帐号。"):("Please note: To use AI-related features, you need to log in to your Tab-OS account.")),
				"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":100,"overflow":"auto-y","minW":"","minH":30,"maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y","flex":true,
				children:[
				],
			},
			{
				"hash":"1HB7TFE0I0",
				"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/additem.svg",null),"x":10,"y":10,
				"OnClick":function(event){
					/*#{1HBCCPRJU0FunctionBody*/
					self.addNewChat();
					/*}#1HBCCPRJU0FunctionBody*/
				},
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
			"!login":{
				/*TxtLogin*/"#1HBCKC4390":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContent=self.BoxContent;
			/*#{1H1T7ISV51Create*/
			let catDefs,name,box,catDef;
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			catDefs=Object.values(catalogDefs);
			for(catDef of catDefs){
				name=catDef.name;
				catalogBoxes[name]=box=boxContent.appendNewChild({type:BoxCatalog(catDef.text),position:"relative",x:0,y:0});
				box.showFace("open");
			}
			tabNT.checkLogin(false).then(async (isLogin)=>{
				if(!isLogin){
					let res=await tabNT.makeCall("checkAICallStatus",{},5000);
					if(res.code!==200){
						self.showFace("!login");
					}
				}
			});
			
			self.showChats();
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		self.showChats();
	};
	
	//------------------------------------------------------------------------
	cssVO.showChats=async function(){
		let json,name,box,chats,chatDef,btn;
		
		json=await readSystemAIShortcuts();
		for(name in catalogBoxes){
			box=catalogBoxes[name];
			box.clear();
		}
		chats=json.shortcuts;
		for(chatDef of chats){
			box=catalogBoxes[chatDef.catalog];
			if(box){
				btn=box.addItem({
					type:BtnTextIcon(60,60,chatDef.icon,cfgColor.fontBody,false,false,chatDef.name),chatDef:chatDef,
					position:"relative",x:0,y:0,margin:[0,15,0,0],padding:8,
					OnClick(evt){
						let chatDef=this.chatDef;
						if(evt.button===2){//Right click
							self.showIconMenu(this);
						}else{
							self.startAIChat(chatDef);
						}
						//TODO:
					},
					OnContextMenu(evt){}
				});
				//TODO: Add this icon
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.startAIChat=function(chatDef){
		let meta,stdFrame;
		meta=rootApp.appLib.getAppMeta("AIChat-"+chatDef.name);
		if(!meta){
			meta={
				type:"app",
				name:"AIChat-"+chatDef.name,
				caption:chatDef.name,
				icon:chatDef.icon,
			};
			stdFrame={
				group:chatDef.source,
				caption:chatDef.name,
				openApp:true,
				multiInstance:true,
				icon:chatDef.icon,
			}
			switch(chatDef.style){
				case "chat":
					meta.appFrame={
						...stdFrame,
						width:375,height:680,
						main:`/@aichat/app.html?chat=${encodeURIComponent(chatDef.source)}&style=chatDef.style`
					};
					break;
				case "pro":
					meta.appFrame={
						...stdFrame,
						width:1024,height:640,
						main:`/@aichat/app.html?chat=${encodeURIComponent(chatDef.source)}&style=chatDef.style`
					};
					break;
				case "mini":
					meta.appFrame={
						...stdFrame,
						width:500,height:300,
						main:`/@aichat/app.html?chat=${encodeURIComponent(chatDef.source)}&style=chatDef.style`
					};
					break;
			}
			rootApp.appLib.regAppInfo(meta);
		}
		rootApp.newFrameApp(meta,"");
	};
	
	//------------------------------------------------------------------------
	cssVO.addNewChat=async function(){
		if(await app.modalDlg(DlgAddShortCut,{})){
			self.showChats();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showIconMenu=async function(btn){
		let item=await app.modalDlg(DlgMenu,{
			hud:btn,anchorH:0,anchorV:1,
			items:[
				{text:"Open shortcut",code:"open"},
				{text:"Edit shortcut",code:"edit"},
				{text:"Remove shortcut",code:"remove"},
				{text:"Replace shortcut",code:"replace",enable:false},
			]
		});
		if(!item)
			return;
		switch(item.code){
			case "open":
				self.startAIChat(btn.chatDef);
				return;
			case "edit":{
				if(await app.modalDlg(DlgAddShortCut,{chatDef:btn.chatDef})){
					self.showChats();
				}
				return;
			}
			case "remove":{
				if(window.confirm("Are you sure to remove this shortcut?")){
					let json,list,i,n,stub,chatDef;
					chatDef=btn.chatDef;
					json=await readSystemAIShortcuts();
					list=json.shortcuts;
					n=list.length;
					for(i=0;i<n;i++){
						stub=list[i];
						if(stub.source===chatDef.source && stub.name===chatDef.name){
							list.splice(i,1);
							await saveSystemAIShortcuts(json);
							self.showChats();
							return;
						}
					}
				}
				return;
			}
			case "replace":{
				return;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	/*}#1H1T7ISV51PostCSSVO*/
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/


export default DlgAIChatHome;
export{DlgAIChatHome};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HB7QO7FS0",
//	"editVersion": 150,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H1T7ISV52",
//			"editVersion": 12,
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H1T7ISV53",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H8H690AD0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1T7ISV54",
//			"editVersion": 128,
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appFrame": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1T7ISV55",
//			"editVersion": 10,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H1T7ISV56",
//			"editVersion": 22,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Standard Dialog",
//			"localize": {
//				"EN": "Standard Dialog",
//				"CN": "标准对话框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "500",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H1T7ISV57",
//			"editVersion": 2,
//			"attrs": {
//				"!login": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HBCKGL3D0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HBCKGL3D1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HB7QO7MB0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7ISV51",
//			"editVersion": 20,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H1T7ISV58",
//					"editVersion": 202,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[10,10,20,10]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1T7LGH40",
//							"editVersion": 44,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O0",
//									"editVersion": 162,
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.body",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "5",
//										"shadow": "false",
//										"shadowX": "3",
//										"shadowY": "6",
//										"shadowBlur": "5",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O1",
//									"editVersion": 4,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1T7O2SA0",
//							"editVersion": 62,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O4",
//									"editVersion": 194,
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": {
//											"type": "string",
//											"valText": "AI Agents",
//											"localize": {
//												"EN": "AI Agents",
//												"CN": "AI 助理"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.bigPlus",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O5",
//									"editVersion": 4,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O6",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O7",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HBCKC4390",
//							"editVersion": 26,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HBCKGL3D2",
//									"editVersion": 138,
//									"attrs": {
//										"type": "text",
//										"id": "TxtLogin",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": {
//											"type": "string",
//											"valText": "Please note: To use AI-related features, you need to log in to your Tab-OS account.",
//											"localize": {
//												"EN": "Please note: To use AI-related features, you need to log in to your Tab-OS account.",
//												"CN": "请注意：要使用AI相关功能，需要先登录您的Tab-OS帐号。"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.mid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "true",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HBCKGL3D3",
//									"editVersion": 2,
//									"attrs": {
//										"1HBCKGL3D0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HBCKHEN24",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HBCKHEN25",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBCKGL3D0",
//											"faceTagName": "!login"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HBCKGL3D4",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HBCKGL3D5",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7S0BE0",
//							"editVersion": 64,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O8",
//									"editVersion": 154,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnTextIcon.js",
//											"jaxId": "1HB9R69P70",
//											"editVersion": 41,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HB9R6U2V0",
//													"editVersion": 20,
//													"attrs": {
//														"w": "48",
//														"h": "48",
//														"icon": "../../../../../aichat/ui",
//														"color": "[0,0,0,1.00]",
//														"hasMark": "false",
//														"hasCheck": "false",
//														"text": "Icon button"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB9R6U2V1",
//													"editVersion": 33,
//													"attrs": {
//														"type": "#null#>BtnTextIcon(48,48,\"../../../../../aichat/ui\",[0,0,0,1],false,false,\"Icon button\")",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "Off",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB9R6U2V2",
//													"editVersion": 4,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB9R6U2V3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB9R6U2V4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HB9R6U2V5",
//													"editVersion": 2,
//													"attrs": {
//														"Slot1H60ULCF00": {
//															"type": "gearcontainer",
//															"jaxId": "1HB9R6U2V6",
//															"editVersion": 4,
//															"attrs": {
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O9",
//									"editVersion": 4,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O10",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O11",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1HB7TFE0I0",
//							"editVersion": 33,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HB7TG71L0",
//									"editVersion": 16,
//									"attrs": {
//										"style": "\"front\"",
//										"w": "30",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/additem.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HB7TG71L1",
//									"editVersion": 43,
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/additem.svg\",null)",
//										"id": "",
//										"position": "Absolute",
//										"x": "10",
//										"y": "10",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HB7TG71L2",
//									"editVersion": 4,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HB7TG71L3",
//									"editVersion": 2,
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HBCCPRJU0",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1HBCCQCI10",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HB7TG71L4",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HB7TG71L5",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H1T7ISV59",
//					"editVersion": 4,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H1T7ISV510",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H1T7ISV511",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7ISV512",
//			"editVersion": 84,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}