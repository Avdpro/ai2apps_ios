//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HB5OTI560StartDoc*/
/*}#1HB5OTI560StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxCatalog=function(name){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxItems;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HB5OTI561LocalVals*/
	let isOpen=true;
	/*}#1HB5OTI561LocalVals*/
	
	/*#{1HB5OTI561PreState*/
	/*}#1HB5OTI561PreState*/
	/*#{1HB5OTI561PostState*/
	/*}#1HB5OTI561PostState*/
	cssVO={
		"hash":"1HB5OTI561",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"","minW":"","minH":50,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HB5OV6IG0",
				"type":"hud","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x",
				children:[
					{
						"hash":"1HB5P0O8I0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/collapse.svg",null),"position":"relative","x":10,"y":"50%","anchorY":1,"anchorX":1,"padding":2,
						"OnClick":function(event){
							/*#{1HB87TRF00FunctionBody*/
							self.showFace(isOpen?"close":"open");
							/*}#1HB87TRF00FunctionBody*/
						},
					},
					{
						"hash":"1HB5P48IC0",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":name,"fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
					}
				],
			},
			{
				"hash":"1HB5RAKIB0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[10,20,10,20],"minW":"","minH":50,"maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","itemsAlign":1,"itemsWrap":1,
				children:[
					{
						"hash":"1HB5RN25N0",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
						"text":(($ln==="CN")?("没有找到属于这个分类的项目"):("No items found for this category")),"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"alignH":1,"alignV":1,
					},
					{
						"hash":"1HB8260G90",
						"type":"hud","id":"BoxItems","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,20,0,20],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","itemsAlign":1,"itemsWrap":1,
					}
				],
			}
		],
		/*#{1HB5OTI561ExtraCSS*/
		/*}#1HB5OTI561ExtraCSS*/
		faces:{
			"open":{
				"#1HB5P0O8I0":{
					"rotate":90,
					ani:[
						{
							"type":"auto","time":100
						}
					]
				},
				/*BoxContent*/"#1HB5RAKIB0":{
					"display":1
				},
				/*#{1HB5RQDHO0Code*/
				$(){
					isOpen=true;
				}
				/*}#1HB5RQDHO0Code*/
			},"close":{
				"#1HB5P0O8I0":{
					"rotate":0
				},
				/*BoxContent*/"#1HB5RAKIB0":{
					"display":0
				},
				/*#{1HB5RQDHO2Code*/
				$(){
					isOpen=false;
				}
				/*}#1HB5RQDHO2Code*/
			},"empty":{
				"#1HB5RN25N0":{
					"display":1
				},
				/*BoxItems*/"#1HB8260G90":{
					"display":0
				}
			},"!empty":{
				"#1HB5RN25N0":{
					"display":0
				},
				/*BoxItems*/"#1HB8260G90":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxItems=self.BoxItems;
			/*#{1HB5OTI561Create*/
			/*}#1HB5OTI561Create*/
		},
		/*#{1HB5OTI561EndCSS*/
		/*}#1HB5OTI561EndCSS*/
	};
	/*#{1HB5OTI561PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.clear=function(){
		boxItems.clearChildren();
		self.showFace("empty");
	};
	
	//------------------------------------------------------------------------
	cssVO.addItem=function(itemDef){
		let i,n;
		boxItems.appendNewChild(itemDef);
		self.showFace("!empty");
	};
	
	//------------------------------------------------------------------------
	cssVO.addItems=function(items){
		let i,n;
		n=items.length;
		for(i=0;i<n;i++){
			boxItems.appendNewChild(items[i]);
		}
		if(n>0){
			self.showFace("!empty");
		}
	};
	/*}#1HB5OTI561PostCSSVO*/
	return cssVO;
};
/*#{1HB5OTI561ExCodes*/
/*}#1HB5OTI561ExCodes*/


export default BoxCatalog;
export{BoxCatalog};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HB5OTI560",
//	"editVersion": 55,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1HB5OTI562",
//			"editVersion": 10,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1HB5OTI563",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HB5OTI564",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HB5OTI565",
//			"editVersion": 10,
//			"attrs": {
//				"name": {
//					"type": "string",
//					"valText": "System"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HB5OTI566",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1HB5OTI567",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1HB5OTI568",
//			"editVersion": 8,
//			"attrs": {
//				"open": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HB5RQDHO0",
//					"editVersion": 18,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HB5RQDHO1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"close": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HB5RQDHO2",
//					"editVersion": 18,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HB5RQDHO3",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"empty": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HB5RQDHO4",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HB5RQDHO5",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"!empty": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HB5SCRQG0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HB5SE3BB0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HB5OTI569",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HB5OTI561",
//			"editVersion": 22,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1HB5OTI5610",
//					"editVersion": 76,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "50",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HB5OV6IG0",
//							"editVersion": 24,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HB5RQDHO6",
//									"editVersion": 112,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxHeader",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"subAlign": "Start",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Start"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HB5P0O8I0",
//											"editVersion": 33,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HB5RQDHO7",
//													"editVersion": 28,
//													"attrs": {
//														"style": "\"front\"",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/collapse.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB5RQDHO8",
//													"editVersion": 69,
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/collapse.svg\",null)",
//														"id": "",
//														"position": "relative",
//														"x": "10",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"anchorH": "Center",
//														"rotate": "0",
//														"padding": "2"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB5RQDHO9",
//													"editVersion": 18,
//													"attrs": {
//														"1HB5RQDHO4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB5SE3BB1",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB5SE3BB2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB5RQDHO4",
//															"faceTagName": "empty"
//														},
//														"1HB5RQDHO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB5SE3BB3",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB5SE3BB4",
//																	"editVersion": 8,
//																	"attrs": {
//																		"rotate": {
//																			"type": "number",
//																			"valText": "90"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": [
//																		{
//																			"type": "hudani",
//																			"def": "Auto",
//																			"jaxId": "1HB5SE3BB5",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HB5SE3BB6",
//																					"editVersion": 10,
//																					"attrs": {
//																						"type": "auto",
//																						"time": "100"
//																					}
//																				},
//																				"codes": "false"
//																			}
//																		}
//																	]
//																}
//															},
//															"faceTagId": "1HB5RQDHO0",
//															"faceTagName": "open"
//														},
//														"1HB5RQDHO2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB7PKKSG0",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB7PKKSG1",
//																	"editVersion": 4,
//																	"attrs": {
//																		"rotate": {
//																			"type": "number",
//																			"valText": "0"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB5RQDHO2",
//															"faceTagName": "close"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB5RQDHO10",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HB87TRF00",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HB87UHCS0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB5RQDHO11",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HB5RQDHO12",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HB5P48IC0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB5RQDHO13",
//													"editVersion": 124,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#name",
//														"font": "",
//														"fontSize": "#txtSize.midPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB5RQDHO14",
//													"editVersion": 38,
//													"attrs": {
//														"1HB5RQDHO4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB5SE3BB7",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB5SE3BB8",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB5RQDHO4",
//															"faceTagName": "empty"
//														},
//														"1HB5RQDHO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB87UHCS1",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB87UHCS2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB5RQDHO0",
//															"faceTagName": "open"
//														},
//														"1HB5RQDHO2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB9SG22T0",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB9SG22T1",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB5RQDHO2",
//															"faceTagName": "close"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB5RQDHO15",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB5RQDHO16",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HB5RQDHO17",
//									"editVersion": 38,
//									"attrs": {
//										"1HB5RQDHO4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HB5SE3BB11",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB5SE3BB12",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HB5RQDHO4",
//											"faceTagName": "empty"
//										},
//										"1HB5RQDHO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HB87UHCS3",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB87UHCS4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HB5RQDHO0",
//											"faceTagName": "open"
//										},
//										"1HB5RQDHO2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HB9SG22T2",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB9SG22T3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HB5RQDHO2",
//											"faceTagName": "close"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HB5RQDHO18",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HB5RQDHO19",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HB5RAKIB0",
//							"editVersion": 27,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HB5RQDHO20",
//									"editVersion": 118,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[10,20,10,20]",
//										"minW": "",
//										"minH": "50",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "Start",
//										"itemsAlign": "Center",
//										"itemsWrap": "Wrap"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HB5RN25N0",
//											"editVersion": 22,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB5RQDHO21",
//													"editVersion": 136,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodyLit\"]",
//														"text": {
//															"type": "string",
//															"valText": "No items found for this category",
//															"localize": {
//																"EN": "No items found for this category",
//																"CN": "没有找到属于这个分类的项目"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.mid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB5RQDHO22",
//													"editVersion": 28,
//													"attrs": {
//														"1HB5RQDHO4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB5SE3BB15",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB5SE3BB16",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB5RQDHO4",
//															"faceTagName": "empty"
//														},
//														"1HB5SCRQG0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB5SE3BB17",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB5SE3BB18",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB5SCRQG0",
//															"faceTagName": "!empty"
//														},
//														"1HB5RQDHO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB87UHCS5",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB87UHCS6",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB5RQDHO0",
//															"faceTagName": "open"
//														},
//														"1HB5RQDHO2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB9SG22T4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB9SG22T5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB5RQDHO2",
//															"faceTagName": "close"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB5RQDHO23",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB5RQDHO24",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HB8260G90",
//											"editVersion": 30,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB827G8U6",
//													"editVersion": 100,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxItems",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,20,0,20]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center",
//														"subAlign": "Start",
//														"itemsWrap": "Wrap"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB827G8U7",
//													"editVersion": 16,
//													"attrs": {
//														"1HB5RQDHO4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB827G8U8",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB827G8U9",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB5RQDHO4",
//															"faceTagName": "empty"
//														},
//														"1HB5SCRQG0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB827G8U10",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB827G8U11",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB5SCRQG0",
//															"faceTagName": "!empty"
//														},
//														"1HB5RQDHO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB87UHCS7",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB87UHCS8",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB5RQDHO0",
//															"faceTagName": "open"
//														},
//														"1HB5RQDHO2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB9SG22T6",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB9SG22T7",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB5RQDHO2",
//															"faceTagName": "close"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB827G8U12",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB827G8U13",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HB5RQDHO25",
//									"editVersion": 22,
//									"attrs": {
//										"1HB5RQDHO4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HB5SE3BB21",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB5SE3BB22",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HB5RQDHO4",
//											"faceTagName": "empty"
//										},
//										"1HB5RQDHO2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HB7PKKSG8",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB7PKKSG9",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HB5RQDHO2",
//											"faceTagName": "close"
//										},
//										"1HB5RQDHO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HB7PKKSG10",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB7PKKSG11",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HB5RQDHO0",
//											"faceTagName": "open"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HB5RQDHO26",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HB5RQDHO27",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1HB5OTI5611",
//					"editVersion": 38,
//					"attrs": {
//						"1HB5RQDHO4": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HB5SE3BB25",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HB5SE3BB26",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HB5RQDHO4",
//							"faceTagName": "empty"
//						},
//						"1HB5RQDHO0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HB87UHCS11",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HB87UHCS12",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HB5RQDHO0",
//							"faceTagName": "open"
//						},
//						"1HB5RQDHO2": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HB9SG22T8",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HB9SG22T9",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HB5RQDHO2",
//							"faceTagName": "close"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1HB5OTI5612",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HB5OTI5613",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HB5OTI5614",
//			"editVersion": 64,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}