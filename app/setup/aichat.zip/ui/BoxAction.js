//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxGoNext} from "./BoxGoNext.js";
/*#{1HAMT6Q0C0StartDoc*/
/*}#1HAMT6Q0C0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAction=function(action){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtActor,txtPrompt,boxSubActs,txtResult;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let color=cfgColor["success"];
	let fontColor=cfgColor["fontPrimary"];
	let isChatBot=true;
	
	/*#{1HAMT6Q0C1LocalVals*/
	const app=VFACT.app;
	switch(action.type){
		case "Chat":
			if(action.ownerAction){
				color=cfgColor["primary"];
			}else{
				color=cfgColor["success"];
			}
			fontColor=cfgColor["fontPrimary"];
			break;
		case "ChatText":{
			color=cfgColor["success"];
			fontColor=cfgColor["fontPrimary"];
			break;
		}
		case "Filter":
		default:
			color=cfgColor["secondary"];
			fontColor=cfgColor["fontPrimary"];
			break;
		case "GPTCall":
			color=cfgColor["warning"];
			fontColor=cfgColor["fontPrimary"];
			break;
		case "APICall":
			color=[30,30,30,1];
			fontColor=cfgColor["fontPrimary"];
			break;
		case "AskUser":
			color=[250,250,250,1];
			fontColor=[0,0,0,1];
			break;
		case "LogEvent":
			color=cfgColor["body"];
			fontColor=cfgColor["fontBody"];
			break;
	}
	/*}#1HAMT6Q0C1LocalVals*/
	
	/*#{1HAMT6Q0C1PreState*/
	isChatBot=false;//action.actor.endsWith(".aichat");
	/*}#1HAMT6Q0C1PreState*/
	/*#{1HAMT6Q0C1PostState*/
	/*}#1HAMT6Q0C1PostState*/
	cssVO={
		"hash":"1HAMT6Q0C1",nameHost:true,
		"type":"box","x":0,"y":0,"w":"","h":"","overflow":1,"cursor":"pointer","minW":300,"minH":"","maxW":"100%","maxH":"","styleClass":"","background":[255,255,255,1],
		"border":2,"corner":12,"contentLayout":"flex-y",
		children:[
			{
				"hash":"1HAMTCUC10",
				"type":"box","id":"BoxStart","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[5,10,10,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":color,"border":[0,0,1,0],"contentLayout":"flex-y",
				children:[
					{
						"hash":"1HAN7EO430",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"overflow":1,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x",
						children:[
							{
								"hash":"1HAN7F9K60",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","uiEvent":-1,"alpha":0.8,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":fontColor,"text":action.type+": ","fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1HAN7HEI40",
								"type":"text","id":"TxtActor","position":"relative","x":0,"y":0,"w":"","h":20,"uiEvent":isChatBot?1:-1,"cursor":isChatBot?"pointer":"","margin":[0,0,0,5],
								"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":fontColor,"text":action.actor,"fontSize":isChatBot?txtSize.smallPlus:txtSize.small,
								"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
								"OnClick":function(event){
									/*#{1HAT1T1HS0FunctionBody*/
									action.session.inspectChatBot(action.actor);
									/*}#1HAT1T1HS0FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1HAMU14GJ0",
						"type":"text","id":"TxtPrompt","position":"relative","x":0,"y":0,"w":"100%","h":"","overflow":"auto-y","margin":[5,0,0,0],"minW":"","minH":"","maxW":"",
						"maxH":100,"styleClass":"","color":fontColor,"text":action.prompt,"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"wrap":true,
					}
				],
				"OnClick":function(event){
					/*#{1HAO78CB50FunctionBody*/
					app.emit("ShowActionInfo",action);
					/*}#1HAO78CB50FunctionBody*/
				},
			},
			{
				"hash":"1HANR8U4E0",
				"type":BoxGoNext(),"position":"relative","x":0,"y":0,
			},
			{
				"hash":"1HAMTI5BQ0",
				"type":"box","id":"BoxSubActs","position":"relative","x":0,"y":0,"w":"","h":"","padding":[0,10,0,10],"minW":300,"minH":0,"maxW":"","maxH":"","styleClass":"",
				"background":cfgColor["body"],"contentLayout":"flex-y",
				"OnClick":function(event){
					/*#{1HAO5LFN30FunctionBody*/
					app.emit("ShowActionInfo",action);
					/*}#1HAO5LFN30FunctionBody*/
				},
			},
			{
				"hash":"1HAMTF9SV0",
				"type":"box","id":"BoxResult","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[5,10,5,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":color,"border":[1,0,0,0],
				children:[
					{
						"hash":"1HAMUANH60",
						"type":"text","id":"TxtResult","position":"relative","x":0,"y":0,"w":"100%","h":"","overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":100,
						"styleClass":"","color":fontColor,"text":action.result||action.error,"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"wrap":true,
					}
				],
				"OnClick":function(event){
					/*#{1HAO79CMO0FunctionBody*/
					app.emit("ShowActionInfo",action);
					/*}#1HAO79CMO0FunctionBody*/
				},
			}
		],
		/*#{1HAMT6Q0C1ExtraCSS*/
		/*}#1HAMT6Q0C1ExtraCSS*/
		faces:{
			"run":{
				/*BoxResult*/"#1HAMTF9SV0":{
					"display":0
				}
			},"done":{
				/*BoxResult*/"#1HAMTF9SV0":{
					"display":1
				}
			},"error":{
				/*BoxResult*/"#1HAMTF9SV0":{
					"background":cfgColor["error"],"display":1
				}
			},"log":{
				"#self":{
					"border":3
				},
				/*BoxStart*/"#1HAMTCUC10":{
					"border":0
				},
				"#1HANR8U4E0":{
					"display":0
				},
				/*BoxSubActs*/"#1HAMTI5BQ0":{
					"display":0
				},
				/*BoxResult*/"#1HAMTF9SV0":{
					"border":0,"display":0
				},
				/*TxtResult*/"#1HAMUANH60":{
					"display":0
				}
			},"chattext":{
				"#1HANR8U4E0":{
					"display":0
				},
				/*BoxSubActs*/"#1HAMTI5BQ0":{
					"display":0
				},
				/*BoxResult*/"#1HAMTF9SV0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtActor=self.TxtActor;txtPrompt=self.TxtPrompt;boxSubActs=self.BoxSubActs;txtResult=self.TxtResult;
			/*#{1HAMT6Q0C1Create*/
			action.uiBlock=self;
			action.on("NewSub",self.OnNewSub);
			action.on("ActionEnd",self.OnActionDone);
			action.on("ActionError",self.OnActionError);
			action.on("ActionError",self.OnActionError);
			action.on("ShowBreak",self.OnShowBreak);
			if(action.type==="LogEvent"){
				self.showFace("log");
			}else if(action.type==="ChatText"){
				self.showFace("chattext");
			}else if(action.endTime){
				if(action.error){
					self.showFace("error");
				}else{
					self.showFace("done");
				}
			}else{
				self.showFace("run");
			}
			/*}#1HAMT6Q0C1Create*/
		},
		/*#{1HAMT6Q0C1EndCSS*/
		/*}#1HAMT6Q0C1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnFree=function(){
		/*#{1HAN5KIKT0FunctionBody*/
		action.off("NewSub",self.OnNewSub);
		action.off("ActionEnd",self.OnActionDone);
		action.off("ActionError",self.OnActionError);
		/*}#1HAN5KIKT0FunctionBody*/
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClick=function(event){
		/*#{1HANS2ROP0FunctionBody*/
		app.emit("ShowActionInfo",action);
		/*}#1HANS2ROP0FunctionBody*/
	};
	/*#{1HAMT6Q0C1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnNewSub=function(action){
		let blk
		blk=boxSubActs.appendNewChild({type:BoxAction(action),position:"relative"});
		boxSubActs.appendNewChild({"type":BoxGoNext(),"position":"relative","x":0,"y":0,});
		VFACT.scrollToShow(blk,app.boxActions);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnActionDone=function(){
		if(action.type!=="LogEvent"){
			txtResult.text=""+action.result;
			action.off("ActionEnd",self.OnActionDone);
			action.off("ActionError",self.OnActionError);
			self.showFace("done");
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnActionError=function(){
		txtResult.text=""+action.error;
		action.off("ActionEnd",self.OnActionDone);
		action.off("ActionError",self.OnActionError);
		self.showFace("error");
	};
	
	//------------------------------------------------------------------------
	cssVO.OnShowBreak=function(text,phase){
		let blk;
		blk=boxSubActs.appendChild(app.boxBreakPoint);
		VFACT.scrollToShow(blk,app.boxActions);
	};
	/*}#1HAMT6Q0C1PostCSSVO*/
	return cssVO;
};
/*#{1HAMT6Q0C1ExCodes*/
/*}#1HAMT6Q0C1ExCodes*/


export default BoxAction;
export{BoxAction};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1HAMT6Q0C0",
//	"editVersion": 70,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1HAMT6Q0C2",
//			"editVersion": 16,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "600",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1HAMT6Q0C3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HAMT6Q0C4",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HAMT6Q0C5",
//			"editVersion": 20,
//			"attrs": {
//				"action": {
//					"type": "auto",
//					"valText": "#{type:\"Chat\",actor:\"cars.aichat\",prompt:\"What is the car color?\",result:\"It's red\"}"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HAMT6Q0C6",
//			"editVersion": 20,
//			"attrs": {
//				"color": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor[\"success\"]"
//				},
//				"fontColor": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor[\"fontPrimary\"]"
//				},
//				"isChatBot": {
//					"type": "bool",
//					"valText": "true"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1HAMT6Q0C7",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1HAMT6Q0C8",
//			"editVersion": 12,
//			"attrs": {
//				"run": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAMUUGMM0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HAMUV8340",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"done": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAMUUSGV0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HAMUV8341",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"error": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAMUT9AL0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HAMUV8342",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"log": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAPQK8UD0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HAPQK8UD1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"chattext": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HBGA2NK90",
//					"editVersion": 18,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HBGA5B9U0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HAMT6Q0C9",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1HAMT6Q0C1",
//			"editVersion": 23,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1HAMT6Q0C10",
//					"editVersion": 160,
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "300",
//						"minH": "",
//						"maxW": "100%",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"background": "[255,255,255,1.00]",
//						"border": "2",
//						"borderStyle": "Solid",
//						"borderColor": "[0,0,0,1.00]",
//						"corner": "12",
//						"shadow": "false",
//						"shadowX": "2",
//						"shadowY": "2",
//						"shadowBlur": "3",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.50]",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HAMTCUC10",
//							"editVersion": 29,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAMTF93I0",
//									"editVersion": 152,
//									"attrs": {
//										"type": "box",
//										"id": "BoxStart",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[5,10,10,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#color",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAN7EO430",
//											"editVersion": 22,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAN7KNUO0",
//													"editVersion": 92,
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "On",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAN7F9K60",
//															"editVersion": 20,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAN7KNUO1",
//																	"editVersion": 142,
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "0.8",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#fontColor",
//																		"text": "#action.type+\": \"",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAN7KNUO2",
//																	"editVersion": 30,
//																	"attrs": {
//																		"1HAMUUGMM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAPLF0IQ0",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAPLF0IQ1",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMUUGMM0",
//																			"faceTagName": "run"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAN7KNUO3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAN7KNUO4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAN7HEI40",
//															"editVersion": 37,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAN7HEI41",
//																	"editVersion": 196,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtActor",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "#isChatBot?1:-1",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "#isChatBot?\"pointer\":\"\"",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,5]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#fontColor",
//																		"text": "#action.actor",
//																		"font": "",
//																		"fontSize": "#isChatBot?txtSize.smallPlus:txtSize.small",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAN7HEI50",
//																	"editVersion": 42,
//																	"attrs": {
//																		"1HAMUUGMM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAN7HEI51",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAN7HEI52",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMUUGMM0",
//																			"faceTagName": "run"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAN7HEI53",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAT1T1HS0",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HAT1UDN30",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAN7HEI54",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAN7KNUO5",
//													"editVersion": 30,
//													"attrs": {
//														"1HAMUUGMM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAPLF0IQ6",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAPLF0IQ7",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMUUGMM0",
//															"faceTagName": "run"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAN7KNUO6",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAN7KNUO7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HAMU14GJ0",
//											"editVersion": 34,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAMU59R20",
//													"editVersion": 192,
//													"attrs": {
//														"type": "text",
//														"id": "TxtPrompt",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Auto Scroll Y",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "100",
//														"face": "",
//														"styleClass": "",
//														"color": "#fontColor",
//														"text": "#action.prompt",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAMU59R21",
//													"editVersion": 42,
//													"attrs": {
//														"1HAMUUGMM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMUV8345",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAMUV8346",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMUUGMM0",
//															"faceTagName": "run"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAMU59R22",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAMU59R23",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAMTF93I1",
//									"editVersion": 36,
//									"attrs": {
//										"1HAMUUGMM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAMUV8347",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAMUV8348",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMUUGMM0",
//											"faceTagName": "run"
//										},
//										"1HAPQK8UD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAPRCT7V8",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAPRCT7V9",
//													"editVersion": 8,
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "0",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAPQK8UD0",
//											"faceTagName": "log"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAMTF93I2",
//									"editVersion": 2,
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HAO78CB50",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1HAO78VQ60",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAMTF93I3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HANQVJRS0",
//							"jaxId": "1HANR8U4E0",
//							"editVersion": 26,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HANR8U4E1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HANR8U4E2",
//									"editVersion": 16,
//									"attrs": {
//										"type": "#null#>BoxGoNext()",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HANR8U4E3",
//									"editVersion": 18,
//									"attrs": {
//										"1HAMUUGMM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAPLF0IQ14",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAPLF0IQ15",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMUUGMM0",
//											"faceTagName": "run"
//										},
//										"1HAPQK8UD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAPRCT7V10",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAPRCT7V11",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAPQK8UD0",
//											"faceTagName": "log"
//										},
//										"1HBGA2NK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HBGA5B9V10",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HBGA5B9V11",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBGA2NK90",
//											"faceTagName": "chattext"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HANR8U4E4",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HANR8U4E5",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HANR8U4E6",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HAMTI5BQ0",
//							"editVersion": 36,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAMTJ36O0",
//									"editVersion": 220,
//									"attrs": {
//										"type": "box",
//										"id": "BoxSubActs",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "300",
//										"minH": "0",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAMTJ36O1",
//									"editVersion": 30,
//									"attrs": {
//										"1HAMUUGMM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAMUV8349",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAMUV83410",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMUUGMM0",
//											"faceTagName": "run"
//										},
//										"1HAPQK8UD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAPRCT7V12",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAPRCT7V13",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAPQK8UD0",
//											"faceTagName": "log"
//										},
//										"1HBGA2NK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HBGA5B9V12",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HBGA5B9V13",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBGA2NK90",
//											"faceTagName": "chattext"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAMTJ36O2",
//									"editVersion": 2,
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HAO5LFN30",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1HAO5LUMJ0",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAMTJ36O3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HAMTF9SV0",
//							"editVersion": 41,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAMTF9SV1",
//									"editVersion": 162,
//									"attrs": {
//										"type": "box",
//										"id": "BoxResult",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[5,10,5,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#color",
//										"border": "[1,0,0,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HAMUANH60",
//											"editVersion": 38,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAMUANH61",
//													"editVersion": 202,
//													"attrs": {
//														"type": "text",
//														"id": "TxtResult",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Auto Scroll Y",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "100",
//														"face": "",
//														"styleClass": "",
//														"color": "#fontColor",
//														"text": "#action.result||action.error",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAMUANH62",
//													"editVersion": 20,
//													"attrs": {
//														"1HAMUUGMM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMUV83413",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAMUV83414",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMUUGMM0",
//															"faceTagName": "run"
//														},
//														"1HAPQK8UD0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAPRCT7V14",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAPRCT7V15",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAPQK8UD0",
//															"faceTagName": "log"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAMUANH63",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAMUANH64",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAMTF9SV2",
//									"editVersion": 10,
//									"attrs": {
//										"1HAMUT9AL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAMUV83415",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAMUV83416",
//													"editVersion": 12,
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"error\"]"
//														},
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMUT9AL0",
//											"faceTagName": "error"
//										},
//										"1HAMUUGMM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAMUV83417",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAMUV83418",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMUUGMM0",
//											"faceTagName": "run"
//										},
//										"1HAMUUSGV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAMUV83419",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAMUV83420",
//													"editVersion": 4,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMUUSGV0",
//											"faceTagName": "done"
//										},
//										"1HAPQK8UD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAPRCT7V16",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAPRCT7V17",
//													"editVersion": 12,
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "0",
//															"editMode": "edges"
//														},
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAPQK8UD0",
//											"faceTagName": "log"
//										},
//										"1HBGA2NK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HBGA5B9V16",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HBGA5B9V17",
//													"editVersion": 8,
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBGA2NK90",
//											"faceTagName": "chattext"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAMTF9SV3",
//									"editVersion": 2,
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HAO79CMO0",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1HAO79G6F0",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAMTF9SV4",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1HAMT6Q0C11",
//					"editVersion": 36,
//					"attrs": {
//						"1HAMUUGMM0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HAMUV83421",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAMUV83422",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAMUUGMM0",
//							"faceTagName": "run"
//						},
//						"1HAPQK8UD0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HAPRCT7V18",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAPRCT7V19",
//									"editVersion": 8,
//									"attrs": {
//										"border": {
//											"type": "auto",
//											"valText": "3",
//											"editMode": "edges"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAPQK8UD0",
//							"faceTagName": "log"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1HAMT6Q0C12",
//					"editVersion": 4,
//					"attrs": {
//						"OnFree": {
//							"type": "fixedFunc",
//							"jaxId": "1HAN5KIKT0",
//							"editVersion": 2,
//							"attrs": {
//								"callArgs": {
//									"type": "object",
//									"jaxId": "1HAN5MQNT0",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						"OnClick": {
//							"type": "fixedFunc",
//							"jaxId": "1HANS2ROP0",
//							"editVersion": 2,
//							"attrs": {
//								"callArgs": {
//									"type": "object",
//									"jaxId": "1HANS3E2R0",
//									"editVersion": 2,
//									"attrs": {
//										"event": ""
//									}
//								}
//							}
//						}
//					}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HAMT6Q0C13",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HAMT6Q0C14",
//			"editVersion": 100,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "false",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}