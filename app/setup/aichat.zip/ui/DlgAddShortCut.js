//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1HB4TT0MM0StartDoc*/
import {tabNT} from "/@tabos/tabos_nt.js";
import {tabOS,tabFS} from "/@tabos";
import pathLib from "/@path";
import {DlgFile} from "/@homekit/ui/DlgFile.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {readSystemAIShortcuts,saveSystemAIShortcuts} from "../chathome.js";
/*}#1HB4TT0MM0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgAddShortCut=function(title,closeIcon,buttons){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxContent,edSource,edName,imgIcon,edIcon,btnCatalog,txtCatalog,btnStyle,txtStyle,boxButtons,btnOK;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7ISV51LocalVals*/
	let app,dlgVO;
	app=window.tabOSApp;
	dlgVO=null;
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	const catalogDefs={
		"code":{name:"code",text:(($ln==="CN")?("编程"):/*EN*/("Coding"))},
		"tools":{name:"tools",text:(($ln==="CN")?("工具"):/*EN*/("Tools"))},
		"relax":{name:"relax",text:(($ln==="CN")?("娱乐"):/*EN*/("Relaxing"))},
	};
	let catalog="tools";
	
	const styleDefs={
		"chat":{name:"chat",text:"Bubble chat",size:[375,640],bubble:true},
		"pro":{name:"pro",text:"Perfectional dialog",size:[1000,640],bubble:false},
		"mini":{name:"mini",text:"Mini tool",size:[375,320],bubble:false},
	};
	let chatStyle="chat";
	let imageOK=true;
	/*}#1H1T7ISV51PreState*/
	state={
		"title":(($ln==="CN")?("添加AI快捷方式"):("Add AI Shortcut")),"buttons":buttons,
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":"50%","y":"20%","w":">calc(100% - 20px)","h":"","anchorX":1,"padding":10,"minW":"","minH":"","maxW":380,"maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,
				"borderColor":cfgColor["fontBodySub"],"corner":5,"shadow":true,"shadowX":3,"shadowY":6,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":$P(()=>(state.title),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":"","overflow":"auto-y","padding":[0,10,0,10],"minW":"","minH":30,"maxW":"",
				"maxH":500,"styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1HB4U23EO0",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":(($ln==="CN")?("AIChat来源："):("AIChat source:")),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HB5G9OLG0",
						"type":"hud","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						children:[
							{
								"hash":"1HB5G9OLG2",
								"type":BtnIcon("front",25,0,appCfg.sharedAssets+"/folder.svg",null),"position":"relative","x":0,"y":0,"margin":[0,0,0,5],
								"OnClick":function(event){
									/*#{1HB5KMKH20FunctionBody*/
									self.setSource();
									/*}#1HB5KMKH20FunctionBody*/
								},
							},
							{
								"hash":"1HB5G9OLH0",
								"type":"edit","id":"EdSource","position":"relative","x":0,"y":0,"w":">calc(100% - 30px)","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"text":(($ln==="CN")?(""):("")),"placeHolder":(($ln==="CN")?(""):("")),"color":[0,0,0],"outline":0,"border":[0,0,1,0],
								"OnKeyDown":function(event){
									/*#{1HB5LVG2I0FunctionBody*/
									if(event.code==="Enter"){
										if((!event.isComposing) &&(!event.shiftKey)){
											event.stopPropagation();
											event.preventDefault();
											self.applyIcon();
										}
									}
									/*}#1HB5LVG2I0FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1HB4U6VKK0",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":(($ln==="CN")?("快捷方式名称："):("Shortcut Name:")),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HB4U3EL30",
						"type":"edit","id":"EdName","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"text":(($ln==="CN")?(""):("")),"placeHolder":(($ln==="CN")?(""):("")),"color":[0,0,0],"outline":0,"border":[0,0,1,0],
					},
					{
						"hash":"1HB4U9N3V0",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":(($ln==="CN")?("图标："):("Icon:")),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HB4UA80N0",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":60,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1HB4UAVA90",
								"type":"box","id":"BoxIcon","x":0,"y":"50%","w":60,"h":60,"anchorY":1,"cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":[255,255,255,1],"border":1,"borderColor":cfgColor["fontBodyLit"],
								children:[
									{
										"hash":"1HB4UG6GK0",
										"type":"image","id":"ImgIcon","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":appCfg.sharedAssets+"/aichat.svg",
										"fitSize":"cover",
										"OnLoad":function(){
											/*#{1HB5DLPUN0FunctionBody*/
											imageOK=true;
											/*}#1HB5DLPUN0FunctionBody*/
										},
									}
								],
								"OnClick":function(event){
									/*#{1HB5CKBUR0FunctionBody*/
									self.setIcon();
									/*}#1HB5CKBUR0FunctionBody*/
								},
							},
							{
								"hash":"1HB4UE73D0",
								"type":"edit","id":"EdIcon","x":65,"y":"50%","w":">calc(100% - 70px)","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","text":(($ln==="CN")?("/@tabos/shared/assets/aichat.svg"):("/@tabos/shared/assets/aichat.svg")),
								"placeHolder":(($ln==="CN")?("/@tabos/shared/assets/aichat.svg"):("/@tabos/shared/assets/aichat.svg")),"color":[0,0,0],"outline":0,"border":[0,0,1,0],
							},
							{
								"hash":"1HB4UJOE60",
								"type":"text","x":66,"y":">calc(100% - 50px)","w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
								"text":(($ln==="CN")?("点击左侧图标框以更改"):("Click left icon frame to change")),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"",
							}
						],
					},
					{
						"hash":"1HB4URD0Q0",
						"type":"hud","id":"BoxCatalog","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1HB4UTQ8I0",
								"type":BtnIcon("front",25,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnCatalog","position":"relative","x":0,"y":0,"margin":[0,0,0,5],
								"OnClick":function(event){
									/*#{1HB5M1OQ70FunctionBody*/
									self.setCatalog();
									/*}#1HB5M1OQ70FunctionBody*/
								},
							},
							{
								"hash":"1HB4USNJE0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
								"text":(($ln==="CN")?("目录："):("Catalog:")),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1HB4UUS3S0",
								"type":"text","id":"TxtCatalog","position":"relative","x":0,"y":0,"w":100,"h":"","margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":[0,0,0],"text":(($ln==="CN")?("系统"):("System")),"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							}
						],
					},
					{
						"hash":"1HB4V7K3R0",
						"type":"hud","id":"BoxStyle","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1HB4V7K3S3",
								"type":BtnIcon("front",25,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnStyle","position":"relative","x":0,"y":0,"margin":[0,0,0,5],
								"OnClick":function(event){
									/*#{1HB5M2A850FunctionBody*/
									self.setStyle();
									/*}#1HB5M2A850FunctionBody*/
								},
							},
							{
								"hash":"1HB4V7K3R2",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
								"text":(($ln==="CN")?("应用样式："):("App Style: ")),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1HB4V7K3S10",
								"type":"text","id":"TxtStyle","position":"relative","x":0,"y":0,"w":100,"h":"","margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":[0,0,0],"text":(($ln==="CN")?("移动聊天"):("Mobile Chat")),"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							}
						],
					}
				],
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":[0,20,0,0],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-x","subAlign":2,"itemsAlign":1,
				children:[
					{
						"hash":"1HB4TTTMF0",
						"type":BtnText("primary",100,25,(($ln==="CN")?("添加"):("Add")),false,""),"id":"BtnOK","position":"relative","x":0,"y":0,"margin":[0,20,0,0],
						"OnClick":function(event){
							/*#{1HB5CECOV0FunctionBody*/
							self.addShortcut();
							/*}#1HB5CECOV0FunctionBody*/
						},
					},
					{
						"hash":"1HB4TU42H0",
						"type":BtnText("warning",100,25,(($ln==="CN")?("取消"):("Cancel")),false,""),"position":"relative","x":0,"y":0,
						"OnClick":function(event){
							/*#{1HB5CDLOE0FunctionBody*/
							self.close(false);
							/*}#1HB5CDLOE0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContent=self.BoxContent;edSource=self.EdSource;edName=self.EdName;imgIcon=self.ImgIcon;edIcon=self.EdIcon;btnCatalog=self.BtnCatalog;txtCatalog=self.TxtCatalog;btnStyle=self.BtnStyle;txtStyle=self.TxtStyle;boxButtons=self.BoxButtons;btnOK=self.BtnOK;
			/*#{1H1T7ISV51Create*/
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let chatBot,chatDef;
		dlgVO=vo;
		chatBot=vo.bot;
		chatDef=vo.chatDef;
		if(vo.chatDef){
			edSource.text=chatDef.source;
			edName.text=chatDef.name;
			edIcon.text=chatDef.icon;
			imgIcon.image=chatDef.icon;
			catalog=chatDef.catalog||"tools";
			txtCatalog.text=catalogDefs[catalog].text;
			chatStyle=chatDef.style||"chat";
			txtStyle.text=styleDefs[chatStyle].text;
			imageOK=true;
			txtTitle.text=(($ln==="CN")?("编辑AI快捷方式"):/*EN*/("Edit AI Shortcut"));
			btnOK.text=(($ln==="CN")?("修改"):/*EN*/("Change"));
		}else{
			edSource.text=chatBot?chatBot.url:"";
			edName.text=chatBot?chatBot.name:"";
			edIcon.text="/@tabos/shared/assets/aichat.svg";
			imgIcon.image=appCfg.sharedAssets+"/aichat.svg";
			catalog="tools";
			txtCatalog.text=catalogDefs[catalog].text;
			chatStyle="chat";
			txtStyle.text=styleDefs[chatStyle].text;
			imageOK=true;
			txtTitle.text=(($ln==="CN")?("添加AI快捷方式"):/*EN*/("Add AI Shortcut"));
			btnOK.text=(($ln==="CN")?("添加"):/*EN*/("Add"));
		}
		self.animate({type:"in",alpha:0,scale:0.9,time:100});
	};
	
	//------------------------------------------------------------------------
	cssVO.setSource=async function(){
		let filePath;
		filePath=await app.modalDlg(DlgFile,{
			mode:"open",
			path:"/",
			options:{
				preview:true,
				filter:"*.aichat;*.js"
			}
		});
		if(filePath){
			if(filePath[0]==="/" && filePath[1]!=="~" && filePath[1]!=="/"){
				filePath="/~"+filePath;
			}
			edSource.text=filePath;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.setIcon=async function(){
		let filePath;
		filePath=await app.modalDlg(DlgFile,{
			mode:"open",
			path:"/",
			options:{
				preview:1,
				filter:"*.svg"
			}
		});
		if(filePath){
			if(filePath[0]==="/" && filePath[1]!=="~" && filePath[1]!=="/"){
				filePath="/~"+filePath;
			}
			imageOK=false;
			imgIcon.image=filePath;
			edIcon.text=filePath;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.applyIcon=function(){
		let filePath;
		imageOK=false;
		filePath=edIcon.text;
		imgIcon.image=filePath;
	};
	
	//------------------------------------------------------------------------
	cssVO.setCatalog=async function(){
		let item,items;
		items=Array.from(Object.values(catalogDefs));
		item=await app.modalDlg(DlgMenu,{
			hud:btnCatalog,
			items:items
		});
		if(item){
			catalog=item.name;
			txtCatalog.text=item.text;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.setStyle=async function(){
		let item,items;
		items=Array.from(Object.values(styleDefs));
		item=await app.modalDlg(DlgMenu,{
			hud:btnStyle,
			items:items
		});
		if(item){
			chatStyle=item.name;
			txtStyle.text=item.text;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.addShortcut=async function(){
		let json,list,stub,orgDef;
		let name,path,icon;
		if(!imageOK){
			window.alert((($ln==="CN")?("图标路径错误，不能添加新的快捷方式"):/*EN*/("Can't add shortcut: icon file path is not available.")));
			return;
		}
		
		name=edName.text;
		path=edSource.text;
		icon=imgIcon.image;
		if(!name){
			window.alert((($ln==="CN")?("快捷方式的名称不能为空。"):/*EN*/("The name of the shortcut cannot be empty.")));
			return;
		}
		
		try{
			json=await fetch(path)
		}catch(err){
			window.alert((($ln==="CN")?("AI Chat源文件路径不存在。"):/*EN*/("AI Chat source file path does not exist.")));
			return;
		}
			
		orgDef=dlgVO.chatDef;
		json=await readSystemAIShortcuts();
		list=json.shortcuts;
		if(orgDef){
			let i,n;
			n=list.length;
			for(i=0;i<n;i++){
				stub=list[i];
				if(stub.source===orgDef.source && stub.name===orgDef.name){
					list[i]={name:name,icon:icon,source:path,catalog:catalog,style:chatStyle};
					await saveSystemAIShortcuts(json);
					self.close(true);
					return;
				}
			}
		}
		//Add new shortcut.
		for(stub of list){
			if(stub.name===name){
				window.alert((($ln==="CN")?(`名字${name}已经被占用了。`):/*EN*/(`Name ${name} is already used.`)));
				edName.focus();
				return;
			}
		}
		list.push({
			name:name,icon:icon,source:path,catalog:catalog,style:chatStyle
		});
		saveSystemAIShortcuts(json);
		self.close(true);
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	/*}#1H1T7ISV51PostCSSVO*/
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/

DlgAddShortCut.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":(($ln==="CN")?("标准对话框"):("Standard Dialog")),icon:"gears.svg",previewImg:false,
	fixPose:false,initW:360,initH:500,
	catalog:"",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Add AI Shortcut", "localizable": true
		}, 
		"closeIcon": {
			"name": "closeIcon", "showName": "closeIcon", "type": "bool", "key": true, "fixed": true, "initVal": false
		}, 
		"buttons": {
			"name": "buttons", "showName": "buttons", "type": "auto", "key": true, "fixed": true, 
			"initVal": []
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","display"],
	faces:[],
	subContainers:{
		"1H1T7S0BE0":{"showName":"BoxContent","contentLayout":"flex-y"}
	},
	/*#{1HB4TT0MM0ExGearInfo*/
	/*}#1HB4TT0MM0ExGearInfo*/
};
export default DlgAddShortCut;
export{DlgAddShortCut};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HB4TT0MM0",
//	"editVersion": 138,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H1T7ISV52",
//			"editVersion": 12,
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H1T7ISV53",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H8H690AD0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1T7ISV54",
//			"editVersion": 112,
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Add AI Shortcut",
//					"localizable": true
//				},
//				"closeIcon": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"buttons": {
//					"type": "auto",
//					"valText": "[]"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H1T7ISV55",
//			"editVersion": 10,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H1T7ISV56",
//			"editVersion": 22,
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Add AI Shortcut",
//					"localize": {
//						"EN": "Add AI Shortcut",
//						"CN": "添加AI快捷方式"
//					},
//					"localizable": true
//				},
//				"buttons": {
//					"type": "auto",
//					"valText": "#buttons"
//				}
//			}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Standard Dialog",
//			"localize": {
//				"EN": "Standard Dialog",
//				"CN": "标准对话框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "500",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H1T7ISV57",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HB4TT0T10",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7ISV51",
//			"editVersion": 20,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H1T7ISV58",
//					"editVersion": 186,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "20%",
//						"w": "100%-20",
//						"h": "\"\"",
//						"anchorH": "Center",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "380",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1T7LGH40",
//							"editVersion": 41,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O0",
//									"editVersion": 152,
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.body",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "5",
//										"shadow": "true",
//										"shadowX": "3",
//										"shadowY": "6",
//										"shadowBlur": "5",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1T7O2SA0",
//							"editVersion": 60,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O4",
//									"editVersion": 180,
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "${state.title},state",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O5",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O6",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O7",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7S0BE0",
//							"editVersion": 62,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O8",
//									"editVersion": 116,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "500",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HB4U23EO0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB4U6RM20",
//													"editVersion": 128,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": {
//															"type": "string",
//															"valText": "AIChat source:",
//															"localize": {
//																"EN": "AIChat source:",
//																"CN": "AIChat来源："
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB4U6RM21",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB4U6RM22",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB4U6RM23",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HB5G9OLG0",
//											"editVersion": 22,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB5G9OLG1",
//													"editVersion": 100,
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%-10",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HB5G9OLG2",
//															"editVersion": 38,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HB5G9OLG3",
//																	"editVersion": 36,
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "25",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB5G9OLG4",
//																	"editVersion": 50,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",25,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,0,5]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB5G9OLG5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB5G9OLG6",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HB5KMKH20",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HB5L1ITV0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB5G9OLG7",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HB5G9OLG8",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "edit",
//															"jaxId": "1HB5G9OLH0",
//															"editVersion": 44,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB5G9OLH1",
//																	"editVersion": 162,
//																	"attrs": {
//																		"type": "edit",
//																		"id": "EdSource",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-30",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"inputType": "Text",
//																		"text": {
//																			"type": "string",
//																			"valText": "",
//																			"localize": {
//																				"EN": "",
//																				"CN": ""
//																			},
//																			"localizable": true
//																		},
//																		"placeHolder": {
//																			"type": "string",
//																			"valText": "",
//																			"localize": {
//																				"EN": "",
//																				"CN": ""
//																			},
//																			"localizable": true
//																		},
//																		"color": "[0,0,0]",
//																		"bgColor": "[255,255,255,1.00]",
//																		"font": "",
//																		"fontSize": "16",
//																		"outline": "0",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB5G9OLH2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB5G9OLH3",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnKeyDown": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HB5LVG2I0",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HB5LVJ8H0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB5G9OLH4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB5G9OLH5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB5G9OLH6",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB5G9OLH7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HB4U6VKK0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB4U6VKK1",
//													"editVersion": 142,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[10,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": {
//															"type": "string",
//															"valText": "Shortcut Name:",
//															"localize": {
//																"EN": "Shortcut Name:",
//																"CN": "快捷方式名称："
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB4U6VKL0",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB4U6VKL1",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB4U6VKL2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HB4U3EL30",
//											"editVersion": 37,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB4U6RM24",
//													"editVersion": 134,
//													"attrs": {
//														"type": "edit",
//														"id": "EdName",
//														"position": "relative",
//														"x": "10",
//														"y": "0",
//														"w": "100%-20",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": {
//															"type": "string",
//															"valText": "",
//															"localize": {
//																"EN": "",
//																"CN": ""
//															},
//															"localizable": true
//														},
//														"placeHolder": {
//															"type": "string",
//															"valText": "",
//															"localize": {
//																"EN": "",
//																"CN": ""
//															},
//															"localizable": true
//														},
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB4U6RM25",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB4U6RM26",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB4U6RM27",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HB4U9N3V0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB4U9N3V1",
//													"editVersion": 148,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[10,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": {
//															"type": "string",
//															"valText": "Icon:",
//															"localize": {
//																"EN": "Icon:",
//																"CN": "图标："
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB4U9N3V2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB4U9N3V3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB4U9N3V4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HB4UA80N0",
//											"editVersion": 22,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB4V635M0",
//													"editVersion": 70,
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "60",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HB4UAVA90",
//															"editVersion": 27,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB4V635M1",
//																	"editVersion": 126,
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxIcon",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "50%",
//																		"w": "60",
//																		"h": "60",
//																		"anchorH": "Left",
//																		"anchorV": "Center",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "pointer",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor[\"fontBodyLit\"]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "image",
//																			"jaxId": "1HB4UG6GK0",
//																			"editVersion": 36,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HB4V635M2",
//																					"editVersion": 98,
//																					"attrs": {
//																						"type": "image",
//																						"id": "ImgIcon",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "Tree Off",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"image": "#appCfg.sharedAssets+\"/aichat.svg\"",
//																						"autoSize": "false",
//																						"fitSize": "Cover",
//																						"repeat": "true",
//																						"alignX": "Left",
//																						"alignY": "Top"
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HB4V635M3",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HB4V635M4",
//																					"editVersion": 2,
//																					"attrs": {
//																						"OnLoad": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HB5DLPUN0",
//																							"editVersion": 2,
//																							"attrs": {
//																								"callArgs": {
//																									"type": "object",
//																									"jaxId": "1HB5DM0HK0",
//																									"editVersion": 0,
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HB4V635M5",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB4V635M6",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB4V635M7",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HB5CKBUR0",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HB5CL3TB0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB4V635M8",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "edit",
//															"jaxId": "1HB4UE73D0",
//															"editVersion": 36,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB4V635M9",
//																	"editVersion": 156,
//																	"attrs": {
//																		"type": "edit",
//																		"id": "EdIcon",
//																		"position": "Absolute",
//																		"x": "65",
//																		"y": "50%",
//																		"w": "100%-70",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"inputType": "Text",
//																		"text": {
//																			"type": "string",
//																			"valText": "/@tabos/shared/assets/aichat.svg",
//																			"localize": {
//																				"EN": "/@tabos/shared/assets/aichat.svg",
//																				"CN": "/@tabos/shared/assets/aichat.svg"
//																			},
//																			"localizable": true
//																		},
//																		"placeHolder": {
//																			"type": "string",
//																			"valText": "/@tabos/shared/assets/aichat.svg",
//																			"localize": {
//																				"EN": "/@tabos/shared/assets/aichat.svg",
//																				"CN": "/@tabos/shared/assets/aichat.svg"
//																			},
//																			"localizable": true
//																		},
//																		"color": "[0,0,0]",
//																		"bgColor": "[255,255,255,1.00]",
//																		"font": "",
//																		"fontSize": "16",
//																		"outline": "0",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB4V635M10",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB4V635M11",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB4V635M12",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HB4UJOE60",
//															"editVersion": 20,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB4V635M13",
//																	"editVersion": 126,
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "66",
//																		"y": "100%-50",
//																		"w": "100",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "Click left icon frame to change",
//																			"localize": {
//																				"EN": "Click left icon frame to change",
//																				"CN": "点击左侧图标框以更改"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB4V635M14",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB4V635M15",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB4V635M16",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB4V635M17",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB4V635M18",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB4V635M19",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HB4URD0Q0",
//											"editVersion": 29,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB4V5N970",
//													"editVersion": 108,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxCatalog",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[10,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HB4UTQ8I0",
//															"editVersion": 51,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HB4V5N975",
//																	"editVersion": 30,
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "25",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB4V5N976",
//																	"editVersion": 53,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",25,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																		"id": "BtnCatalog",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,0,5]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB4V5N977",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB4V5N978",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HB5M1OQ70",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HB5M220P0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB4V5N979",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HB4V5N9710",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HB4USNJE0",
//															"editVersion": 20,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB4V5N971",
//																	"editVersion": 120,
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "Catalog:",
//																			"localize": {
//																				"EN": "Catalog:",
//																				"CN": "目录："
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB4V5N972",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB4V5N973",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB4V5N974",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HB4UUS3S0",
//															"editVersion": 36,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB4V5N9711",
//																	"editVersion": 152,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtCatalog",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,3]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "[0,0,0]",
//																		"text": {
//																			"type": "string",
//																			"valText": "System",
//																			"localize": {
//																				"EN": "System",
//																				"CN": "系统"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "16",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB4V5N9712",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB4V5N9713",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB4V5N9714",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB4V5N9715",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB4V5N9716",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB4V5N9717",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HB4V7K3R0",
//											"editVersion": 31,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB4V7K3R1",
//													"editVersion": 114,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxStyle",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[10,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HB4V7K3S3",
//															"editVersion": 52,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HB4V7K3S4",
//																	"editVersion": 30,
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "25",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB4V7K3S5",
//																	"editVersion": 54,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",25,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																		"id": "BtnStyle",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,0,5]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB4V7K3S6",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB4V7K3S7",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HB5M2A850",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HB5M2FOI0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB4V7K3S8",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HB4V7K3S9",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HB4V7K3R2",
//															"editVersion": 20,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB4V7K3R3",
//																	"editVersion": 128,
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "App Style: ",
//																			"localize": {
//																				"EN": "App Style: ",
//																				"CN": "应用样式："
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB4V7K3S0",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB4V7K3S1",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB4V7K3S2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HB4V7K3S10",
//															"editVersion": 39,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB4V7K3S11",
//																	"editVersion": 164,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtStyle",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,3]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "[0,0,0]",
//																		"text": {
//																			"type": "string",
//																			"valText": "Mobile Chat",
//																			"localize": {
//																				"EN": "Mobile Chat",
//																				"CN": "移动聊天"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "16",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB4V7K3S12",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB4V7K3S13",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB4V7K3S14",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB4V7K3S15",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB4V7K3S16",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB4V7K3S17",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O9",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O10",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O11",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7UCES0",
//							"editVersion": 51,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H1T83E7O12",
//									"editVersion": 154,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "[0,20,0,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "End",
//										"attach": "true",
//										"flex": "false",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HB4TTTMF0",
//											"editVersion": 42,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HB4U6RM28",
//													"editVersion": 26,
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "25",
//														"text": {
//															"type": "string",
//															"valText": "Add",
//															"localize": {
//																"EN": "Add",
//																"CN": "添加"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB4U6RM29",
//													"editVersion": 44,
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,25,(($ln===\"CN\")?(\"添加\"):(\"Add\")),false,\"\")",
//														"id": "BtnOK",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,20,0,0]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB4U6RM210",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB4U6RM211",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HB5CECOV0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HB5CEMHK0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB4U6RM212",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HB4U6RM213",
//													"editVersion": 2,
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"type": "gearcontainer",
//															"jaxId": "1HB4U6RM214",
//															"editVersion": 4,
//															"attrs": {
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HB4TU42H0",
//											"editVersion": 35,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HB4U6RM215",
//													"editVersion": 32,
//													"attrs": {
//														"style": "warning",
//														"w": "100",
//														"h": "25",
//														"text": {
//															"type": "string",
//															"valText": "Cancel",
//															"localize": {
//																"EN": "Cancel",
//																"CN": "取消"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB4U6RM216",
//													"editVersion": 31,
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",100,25,(($ln===\"CN\")?(\"取消\"):(\"Cancel\")),false,\"\")",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB4U6RM217",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB4U6RM218",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HB5CDLOE0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HB5CE2AI0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB4U6RM219",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HB4U6RM220",
//													"editVersion": 2,
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"type": "gearcontainer",
//															"jaxId": "1HB4U6RM221",
//															"editVersion": 4,
//															"attrs": {
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H1T83E7O13",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H1T83E7O14",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H1T83E7O15",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H1T7ISV59",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H1T7ISV510",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H1T7ISV511",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7ISV512",
//			"editVersion": 84,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}