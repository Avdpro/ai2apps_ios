import pathLib from "/@path";
import {ChatAction} from "./chataction.js";
import {makeObjEventEmitter,makeNotify} from "/@events";

//----------------------------------------------------------------------------
const ChatModels={
	"GPT-3.5":{text:"GPT-3.5",maxToken:4096,model:"gpt-3.5-turbo"},
	"GPT-4":{text:"GPT-4",maxToken:8192,model:"gpt-4"},
	"GPT-3.5 16K":{text:"GPT-3.5 16K",maxToken:16*1024-32,model:"gpt-3.5-turbo-16k"},
	"GPT-4 32K":{text:"GPT-4 32K",maxToken:32*1024-32,model:"gpt-4-32k"},
};

let ChatBot,chatBot;
//****************************************************************************
//:ChatBot
//****************************************************************************
ChatBot=function(session){
	this.ready=false;

	this.isAIChatBot=true;
	this.session=session;
	this.orgSysMsg=
	this.sysMsg="You are a smart assistant.";
	this.presetMsgs=[];
	this.name="";
	this.alias="";
	this.info="";
	this.greeting="";
	this.userMsgPrefix="";
	this.userMsgPostfix="";
	this.orgPreFix="";
	this.orgPostFix="";
	this.config={
		model:"GPT-3.5",
		temperature:0,
		maxToken:2048,
		topP:1,fqcP:0,prcP:0
	};
	this.chatMsgs=[];
	this.filterInit=null;
	this.filterReset=null;
	this.filterInput=null;
	this.filterOutput=null;
	this.filterEndRound=null;
	this.filterCompress=null;
	this.filterInitURL=null;
	this.filterResetURL=null;
	this.filterInputURL=null;
	this.filterOutputURL=null;
	this.filterEndRoundURL=null;
	this.filterCompressURL=null;

	this.memoryChatNum=0;
	this.compressChatNum=6;
	this.secretInternal=false;
	this.runOnStart=false;
	this.allowFile=false;
	
	this.funcStubs={};
	this.funcNum=0;
	this.functions=null;
	
	//Memory:
	this.chatMemory="";
	this.chatContext="";
	
	makeObjEventEmitter(this);
	makeNotify(this);
};
chatBot=ChatBot.prototype={};
const botMap=new Map();

//----------------------------------------------------------------------------
ChatBot.loadBot=async function(session,url){
	let baseBot;
	baseBot=botMap.get(url);
	if(!baseBot){
		baseBot=new ChatBot(session);
		await baseBot.load(url);
		botMap.set(url,baseBot);
	}
	return baseBot;
};

//----------------------------------------------------------------------------
ChatBot.loadJSON=async function(session,url,json){
	let bot;
	bot=new ChatBot(session);
	bot.url=url;
	await bot.loadFromVO(json);
	return bot;
};

//****************************************************************************
//:Chat action related:
//****************************************************************************
{
	//------------------------------------------------------------------------
	chatBot.reset=async function(){
		let action;
		this.sysMsg=this.orgSysMsg;
		this.userMsgPrefix=this.orgPreFix;
		this.userMsgPostfix=this.orgPostFix;
		this.chatMemory="";
		this.chatMsgs.splice(0);
		if(this.filterReset){
			action=ChatAction.logFilter(this.session,this,"reset",this.filterResetURL,"");
			try{
				await this.filterReset();
			}catch(err){
				action.failed(err);
				throw err;
			}
			action.end();
		}else if(this.filterInit){
			action=ChatAction.logFilter(this.session,this,"reset",this.filterInitURL,"");
			try{
				await this.filterInit();
			}catch(err){
				action.failed(err);
				throw err;
			}
			action.end();
		}
	};
	
	//------------------------------------------------------------------------
	chatBot.clearChatMsgs=function(){
		this.chatMsgs.splice(0);
	};
	
	//------------------------------------------------------------------------
	chatBot.updateSysMsg=function(msg){
		this.sysMsg=msg;
	};
	
	//------------------------------------------------------------------------
	chatBot.checkMemory=async function(){
		let logMsgs,i,n,memJSON,action,cmpsData,session;
		logMsgs=this.chatMsgs;
		session=this.session;
		console.log(`Check memory: this.memoryChatNum=${this.memoryChatNum}`);
		console.log(`Check memory: this.compressChatNum=${this.compressChatNum}`);
		console.log(`Check memory: logMsgs.length=${logMsgs.length}`);
		if((this.memoryChatNum>=0 && this.memoryChatNum<200) && logMsgs.length>=(this.memoryChatNum+this.compressChatNum)){
			let chats;
			n=logMsgs.length-this.memoryChatNum;
			chats=logMsgs.slice(0,n);
			this.chatMsgs=logMsgs=logMsgs.slice(n);
			n=logMsgs.length;
			for(i=0;i<n;i++){
				if(logMsgs[0].role!=="user"){
					chats.push(logMsgs.shift());
				}else{
					break;
				}
			}
			if(this.filterCompress && chats && chats.length>0){
				//console.log("Will compress chats:");
				//console.log(chats);
				chats={
					memory:this.chatMemory||"",
					chats:chats
				};
				cmpsData=JSON.stringify(chats);
				action=ChatAction.logFilter(this.session,this,"compress",this.filterCompressURL,cmpsData);
				try{
					cmpsData=await session.checkStep(cmpsData,"input");
					memJSON=await this.filterCompress(cmpsData);
					memJSON=await session.checkStep(memJSON,"output");
				}catch(err){
					action.failed(err);
					throw err();
				}
				action.end(memJSON);
				//console.log("MemJSON:");
				//console.log(memJSON);
				if(memJSON){
					try{
						memJSON=JSON.parse(memJSON);
					}catch(err){
						memJSON=null;
					}
					if(memJSON && memJSON.memory){
						this.chatMemory=memJSON.memory;
						ChatAction.logLogEvent(session,"New memory: "+this.chatMemory);
						console.log("New memory: "+this.chatMemory);
					}
				}
			}
		}
	};
	
	//------------------------------------------------------------------------
	chatBot.genChatCallVO=async function(prompt){
		let callVO,cfg;
		cfg=this.config;
		switch(cfg.model){
			case "GPT-3.5":
			case "GPT-4":
			default:{
				let messages;
				messages=await this.genPromptMsgs(prompt);
				callVO={
					model:ChatModels[cfg.model]?ChatModels[cfg.model].model:"gpt-3.5-turbo",
					temperature:cfg.temperature,
					max_tokens:cfg.maxToken,
					top_p:cfg.topP,
					presence_penalty:cfg.prcP,
					frequency_penalty:cfg.fqcP,
					messages:messages,
				};
				if(this.funcNum>0){
					callVO.functions=this.getFunctions();
				}
			}
		};
		return callVO;
	};
	
	//------------------------------------------------------------------------
	chatBot.genPromptMsgs=async function(prompt){
		let logMsgs,userMsg,msgs,presetMsgs,i,n,action,session;
		logMsgs=this.chatMsgs;
		presetMsgs=this.presetMsgs;
		session=this.session;
		
		if(this.allowFile){
			let pos,pos1,pos2,mark,path,text;
			pos=0;
			mark="${{file:";
			do{
				pos1=prompt.indexOf(mark);
				if(pos1>=0){
					pos1+=(mark.length);
					pos2=prompt.indexOf("}}",pos1);
					if(pos2>0){
						path=prompt.substring(pos1,pos2);
						if(path[0]==="/" && path[1]!=="@" && path[1]!=="~" && path[1]!=="/"){
							path="/~"+path;
						}
						try{
							text=await (await fetch(path)).text();
							text="\n```\n"+text+"\n```\n";
							prompt=prompt.substring(0,pos1)+text+prompt.substring(pos2+2);
							pos=pos1+text.length;
						}catch(err){
							pos=pos2+2;
						}
					}else{
						pos=pos1+mark.length;
					}
				}else{
					break;
				}
			}while(pos>=0)
		}
		
		//Filter and prefix/postfix user message:
		if(this.filterInput){
			action=ChatAction.logFilter(this.session,this,"input",this.filterInputURL,prompt);
			try{
				prompt=await session.checkStep(prompt,"input");
				prompt=await this.filterInput(prompt);
				prompt=await session.checkStep(prompt,"output");
			}catch(err){
				action.failed(err);
				throw err;
			}
			action.end(prompt);
		}
		prompt=this.userMsgPrefix+prompt+this.userMsgPostfix;
		userMsg={role:"user",content:prompt};
		//Build up chat prompt
		msgs=[{role:"system",content:this.sysMsg},...presetMsgs];
		if(this.chatMemory){
			let text="Info from previous chats: "+this.chatMemory;
			msgs.push({role:"user",content:text});
		}
		msgs=msgs.concat(logMsgs);
		if(this.chatContext){
			let text="Chat context:\n"+this.chatContext;
			msgs.push({role:"user",content:text});
		}
		msgs.push(userMsg);
		logMsgs.push(userMsg);
		return msgs;
	};
	
	//------------------------------------------------------------------------
	chatBot.applyAIFeedback=async function(result){
		let botMsg,bot,session,action;
		session=this.session;
		//Remember this:
		botMsg={role:"assistant",content:result};
		this.chatMsgs.push(botMsg);

		//Filter and prefix/postfix user message:
		if(this.filterOutput){
			action=ChatAction.logFilter(this.session,this,"output",this.filterOutputURL,result);
			try{
				result=await session.checkStep(result,"input");
				result=await this.filterOutput(result);
				result=await session.checkStep(result,"output");
			}catch(err){
				action.failed(err);
				throw err;
			}
			action.end(result);
		}
		return result;
	};
	
	//------------------------------------------------------------------------
	chatBot.applyFunctionCall=async function(funcCall,callVO,callbackAI){
		let stub,def,name,funcObj,args,result,action,session;
		session=this.session;
		name=funcCall.name;
		stub=this.funcStubs[name];
		if(!stub){
			throw Error(`Chat bot Can't find function to call: ${name}`);
		}
		def=stub.def;
		funcObj=stub.func;
		args=funcCall["arguments"];
		action=ChatAction.logAPICall(this.session,name,args,stub);
		try{
			args=await session.checkStep(args,"input");
			result=await funcObj.call(this,JSON.parse(args));
			result=await session.checkStep(result,"output");
		}catch(err){
			action.failed(err);
			throw err;
		}
		action.end(result);
		if(stub.callbackAI||callbackAI){
			let msgs;
			msgs=callVO.messages;
			if(typeof(result)==="object"){
				result=JSON.stringify(result);
			}
			msgs.push({role:"assistant",content:"",function_call:funcCall});
			msgs.push({role:"function",name:name,content:result});
			return callVO;
		}
		this.session.waitObj.content=result;
		return null;
	};
	
	//------------------------------------------------------------------------
	chatBot.execNoAICall=async function(prompt){
		let action,session;
		session=this.session;
		if(this.filterInput){
			action=ChatAction.logFilter(this.session,this,"input",this.filterInputURL,prompt);
			try{
				prompt=await session.checkStep(prompt,"input");
				prompt=await this.filterInput(prompt);
				prompt=await session.checkStep(prompt,"output");
			}catch(err){
				action.failed(err);
				throw err;
			}
			action.end(prompt);
		}
		if(this.filterOutput){
			action=ChatAction.logFilter(this.session,this,"output",this.filterOutputURL,prompt);
			try{
				prompt=await session.checkStep(prompt,"input");
				prompt=await this.filterOutput(prompt);
				prompt=await session.checkStep(prompt,"output");
			}catch(err){
				action.failed(err);
				throw err;
			}
			action.end(prompt);
		}
		return prompt;
	};
}

//****************************************************************************
//:Functions
//****************************************************************************
{
	//------------------------------------------------------------------------
	chatBot.registerFunction=function(vo,func,callbackAI=true){
		let stubs=this.funcStubs;
		let name=vo.name||vo;
		if(func){
			if(!stubs[name]){
				this.funcNum++;
			}
			stubs[name]={
				def:vo,func:func,callbackAI:callbackAI
			};
		}else{
			if(stubs[name]){
				delete stubs[name];
				this.funcNum--;
			}
		}
		this.functions=null;
	};
	
	//------------------------------------------------------------------------
	chatBot.getFunctions=function(){
		//TODO: add session functions:
		return this.functions||(Object.values(this.funcStubs).map(item=>item.def));
	};
	
	//------------------------------------------------------------------------
	chatBot.pipeChat=async function(url,text){
		let botDir;		
		botDir=pathLib.dirname(this.url);
		if(url.startsWith(".")){
			url=pathLib.join(botDir,url);
		}
		if(url[0]!=="/"){
			url=this.session.baseURL+"/"+url;
		}
		if(url.startsWith("//")){
			url="/~/"+url.substring(2);
		}
		return await this.session.pipeChat(url,text);
	};
}

//****************************************************************************
//:I/O
//****************************************************************************
{
	//------------------------------------------------------------------------
	chatBot.cloneFrom=async function(bot,alias){
		//Clone base attributes:
		this.url=bot.url;
		this.alias=alias||bot.url;
		this.name=bot.name;
		this.info=bot.info;
		this.greeting=bot.greeting;
		this.orgSysMsg=bot.orgSysMsg;
		this.sysMsg=bot.sysMsg;
		this.orgPreFix=this.userMsgPrefix=bot.userMsgPrefix;
		this.orgPostFix=this.userMsgPostfix=bot.userMsgPostfix;
		this.userMsgPostfix=bot.userMsgPostfix;
		this.presetMsgs=bot.presetMsgs.slice(0);
		this.filterInit=bot.filterInit;
		this.filterReset=bot.filterReset;
		this.filterInput=bot.filterInput;
		this.filterOutput=bot.filterOutput;
		this.filterEndRound=bot.filterEndRound;
		this.filterCompress=bot.filterCompress;
		this.filterInitURL=bot.filterInitURL;
		this.filterResetURL=bot.filterResetURL;
		this.filterInputURL=bot.filterInputURL;
		this.filterOutputURL=bot.filterOutputURL;
		this.filterEndRoundURL=bot.filterEndRoundURL;
		this.filterCompressURL=bot.filterCompressURL;
		this.memoryChatNum=bot.memoryChatNum;
		this.compressChatNum=bot.compressChatNum;
		this.secretInternal=bot.secretInternal;
		this.runOnStart=bot.runOnStart;
		this.allowFile=bot.allowFile;
		this.funcStubs={...bot.funcStubs};
		this.funcNum=bot.funcNum;
		this.functions=null;
		//Clone config:
		this.config={...bot.config};
		if(this.filterInit){
			let result;
			let action=ChatAction.logFilter(this.session,this,"init",this.filterInitURL,"");
			try{
				result=await this.filterInit();
				action.end(result);
			}catch(err){
				action.failed(err);
				throw err;
			}
		}
		if(this.runOnStart){
			//TODO: Code this:
		}
	};
	
	//------------------------------------------------------------------------
	chatBot.load=async function(url){
		let jsonVO;
		this.url=url;
		try{
			jsonVO=await (await fetch(url)).json();
			this.ready=true;
		}catch(err){
			console.error("Load chat bot failed");
			console.log(err);
			throw err;
		}
		await this.loadFromVO(jsonVO);
		this.ready=true;
	};

	//------------------------------------------------------------------------
	chatBot.loadFromVO=async function(vo){
		let botDir,session,url,def,stub,lastMsg,apiFiles,msgs,msg,tgtMsgs,postfix,prefix;
		session=this.session;
		botDir=pathLib.dirname(this.url);
		this.name=vo.name||pathLib.basename(this.url);
		this.info=vo.info||"AIChat playground.";
		this.greeting=vo.greeting||"";
		this.sysMsg=vo.sysMsg;
		this.orgSysMsg=this.sysMsg;
		this.orgPreFix=this.userMsgPrefix=vo.userMsgPrefix||"";
		this.orgPostFix=this.userMsgPostfix=vo.userMsgPostfix||"";
		this.config.model=vo.config.model||"GPT-3.5";
		this.config.temperature=vo.config.temperature||0;
		this.config.maxToken=vo.config.maxToken||2048;
		this.config.topP=vo.config.topP||1;
		this.config.fqcP=vo.config.fqcP||0;
		this.config.prcP=vo.config.prcP||0;
		this.presetMsgs=vo.chatMsgs.slice(0);
		this.memoryChatNum=vo.memoryChatNum>=0?vo.memoryChatNum:6;
		this.compressChatNum=vo.compressChatNum>=0?vo.compressChatNum:6;
		this.secretInternal=!!vo.secretInternal;
		this.runOnStart=!!vo.runOnStart;
		this.allowFile=!!(vo.allowFile||vo.allowFileInput);
		lastMsg=this.presetMsgs[this.presetMsgs.length-1];
		if(lastMsg && lastMsg.role==="user"){
			this.presetMsgs.pop();
		}
		tgtMsgs=[];
		msgs=this.presetMsgs;
		prefix=this.orgPreFix;
		postfix=this.orgPostFix;
		for(msg of msgs){
			switch(msg.role){
				case "user":
					msg.content=prefix+"\n"+msg.content+"\n"+postfix;
					tgtMsgs.push(msg);
					break;
				case "assistant":
					tgtMsgs.push(msg);
					break;
			}
		}
		this.presetMsgs=tgtMsgs;
		
		//Load filters:
		url=vo.filterInit;
		if(url){
			this.filterInit=await this.loadFilterFunc(url);
			this.filterInitURL=url;
		}
		url=vo.filterReset;
		if(url){
			this.filterReset=await this.loadFilterFunc(url);
			this.filterResetURL=url;
		}
		url=vo.filterInput;
		if(url){
			this.filterInput=await this.loadFilterFunc(url);
			this.filterInputURL=url;
		}

		url=vo.filterOutput;
		if(url){
			this.filterOutput=await this.loadFilterFunc(url);
			this.filterOutputURL=url;
		}
		
		url=vo.filterEndRound;
		if(url){
			this.filterEndRound=await this.loadFilterFunc(url);
			this.filterEndRoundURL=url;
		}

		url=vo.filterCompress;
		if(url){
			this.filterCompress=await this.loadFilterFunc(url);
			this.filterCompressURL=url;
		}

		//Load APIs:
		apiFiles=vo.apiFiles;
		if(apiFiles){
			apiFiles=apiFiles.split(";");
			for(url of apiFiles){
				if(url){
					await this.loadAPIFile(url);
				}
			}
		}
	};

	//------------------------------------------------------------------------
	chatBot.loadFilterFunc=async function(filterText){
		let botDir,url,extName,funcName,modual,func;
		botDir=pathLib.dirname(this.url);
		if(Array.isArray(filterText)){
			url=filterText[0];
			funcName=filterText[1];
		}else if(typeof(filterText)==="string"){
			let pos=filterText.indexOf("@");
			if(pos>0){
				url=filterText.substring(pos+1);
				funcName=filterText.substring(0,pos);
			}else{
				url=filterText;
				funcName="";
			}
		}
		if(url.startsWith(".")){
			url=pathLib.join(botDir,url);
		}
		if(url[0]!=="/"){
			url=this.session.baseURL+"/"+url;
		}
		if(url.startsWith("//")){
			url="/~/"+url.substring(2);
		}
		extName=pathLib.extname(url);
		if(extName===".aichat"){
			return async function(message){
				return await this.pipeChat(url,message);
			};
		}else if(extName===".js"){
			modual=await import(url);
			if(funcName){
				func=modual[funcName];
				if(!func){
					throw Error(`Cant't find filter function "${funcName}" in ${url}`);
				}
			}else{
				func=modual.default;
				if(!func){
					throw Error(`Cant't find filter function default-entry in ${url}`);
				}
			}
			return func;
		}
	};
	
	//------------------------------------------------------------------------
	chatBot.loadAPIFile=async function(url){
		let botDir,extName,modual;
		botDir=pathLib.dirname(this.url);
		if(url.startsWith(".")){
			url=pathLib.join(botDir,url);
		}
		if(url[0]!=="/"){
			url=this.session.baseURL+"/"+url;
		}
		if(url.startsWith("//")){
			url="/~/"+url.substring(2);
		}
		extName=pathLib.extname(url);
		if(extName===".aichat"){
			let stub,bot,func;
			bot=await this.session.loadBot(url);
			func=async function(message){
				return await this.pipeChat(url,message);
			};
			stub={
				"name": bot.name,"description": bot.info,
				"parameters": {
					"type": "object",
					"properties": {
						"message": {
							"type": "string","description": "The prompt to call this API",
						}
					},
				}
			};
			this.registerFunction(stub,func,true);
		}else if(extName===".js"){
			let apiList,stub;
			modual=await import(url);
			apiList=modual.ChatAPI;
			if(apiList){
				if(!Array.isArray(apiList)){
					apiList=[apiList];
				}
				for(stub of apiList){
					this.registerFunction(stub.def,stub.func,true);
				}
			}
		}
	};
	
	//------------------------------------------------------------------------
	chatBot.genSaveVO=function(){
		let vo;
		vo={};
		vo.chatMsgs=[...this.chatMsgs];
		vo.chatMemory=this.chatMemory;
		vo.chatContext=this.chatContext;
		return vo;
	};
	
	//------------------------------------------------------------------------
	chatBot.loadFromSaveVO=function(vo){
		this.chatMsgs=[...vo.chatMsgs];
		this.chatMemory=vo.chatMemory;
		this.chatContext=vo.chatContext;
	};
}
export default ChatBot;
export {ChatBot};