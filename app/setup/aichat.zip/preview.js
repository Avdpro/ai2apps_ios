import {VFACT} from "/@vfact";
import {} from "/@vfact/vfact_app.js";
import {UIView} from "/@editkit/ui/UIView.js";
import {BoxCatalog} from "./temp/BoxCatalog.js";
async function startApp() {
	let app,uiDef;
	window.tabOSApp=app=await VFACT.createApp();
	uiDef=UIView(BoxCatalog);
	await VFACT.initApp(app,uiDef,{});
}
startApp();
