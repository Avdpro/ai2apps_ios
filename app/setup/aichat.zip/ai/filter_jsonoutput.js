
export default function filterJSONOuput(code){
	try{
		let json;
		json=JSON.parse(code);
		json=JSON.stringify(json,null,"\t");
		json="```json\n"+json+"\n```";
		return json;
	}catch(err){
		return code;
	}
};