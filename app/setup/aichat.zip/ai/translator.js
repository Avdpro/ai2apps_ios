//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
/*#{1HDP0G4P60MoreImports*/
/*}#1HDP0G4P60MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HDP0G4P60StartDoc*/
/*}#1HDP0G4P60StartDoc*/
//----------------------------------------------------------------------------
let translator=async function(session){
	let context,globalContext;
	let self;
	let Start,ChooseLan,ShowLan,WaitChat,CheckInput,CallAI,ShowResult;
	/*#{1HDP0G4P60LocalVals*/
	/*}#1HDP0G4P60LocalVals*/
	
	/*#{1HDP0G4P60PreContext*/
	/*}#1HDP0G4P60PreContext*/
	globalContext=session.globalContext;
	context={
		"tgtLan":"Chinese",
		/*#{1HDP0G4P64ExCtxAttrs*/
		/*}#1HDP0G4P64ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1HDP0G4P60PostContext*/
	/*}#1HDP0G4P60PostContext*/
	let agent,segs={};
	segs["Start"]=Start=async function(input){//:1HDP0T0UT0
		let result=input;
		let role="assistant";
		let conent=(($ln==="CN")?("这是一个用来演示交互功能的翻译 Agent。在启动后，Agent 会先询问用户翻译的目标语言。然后每轮对话把用户输入的文本翻译成用户选择的语言。如果用户输入 “rest” 则重新询问用户目标语言。"):("This is a translation Agent for demonstrating interactive functionality. Upon launch, the Agent will first ask the user for the target language of translation. Then, in each conversation round, it will translate the user's input text into the selected language. If the user inputs 'rest', it will ask the user for the target language again."));
		session.addChatText(role,conent);
		return {seg:ChooseLan,result:(result),preSeg:"1HDP0T0UT0",outlet:"1HDP0T0UT1"};
	};
	Start.jaxId="1HDP0T0UT0"
	Start.url="Start@"+agentURL
	
	segs["ChooseLan"]=ChooseLan=async function(input){//:1HDP0T0UU0
		let prompt=((($ln==="CN")?("请选择翻译的目标语言"):("Please select the target language")))||input;
		let items=[
			{text:"中文",code:0},
			{text:"English",code:1},
			{text:"日本语",code:2},
		];
		let result="";
		let item=null;
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,items:items});
		if(item.code===0){
			/*#{1HDUHR54S0*/
			context.tgtLan="Chinese";
			/*}#1HDUHR54S0*/
			return {seg:ShowLan,result:(result),preSeg:"1HDP0T0UU0",outlet:"1HDUHR54S0"};
		}
		if(item.code===1){
			/*#{1HDUHR54S1*/
			context.tgtLan="English";
			/*}#1HDUHR54S1*/
			return {seg:ShowLan,result:(result),preSeg:"1HDP0T0UU0",outlet:"1HDUHR54S1"};
		}
		if(item.code===2){
			/*#{1HDUHR54S2*/
			context.tgtLan="Japanese";
			/*}#1HDUHR54S2*/
			return {seg:ShowLan,result:(result),preSeg:"1HDP0T0UU0",outlet:"1HDUHR54S2"};
		}
		return {result:result};
	
	};
	ChooseLan.jaxId="1HDP0T0UU0"
	ChooseLan.url="ChooseLan@"+agentURL
	
	segs["ShowLan"]=ShowLan=async function(input){//:1HDP0T0UU1
		let result=input;
		let role="event";
		let conent=(($ln==="CN")?(`选择的目标语言：${input}。`):(`Selected target language: ${input}.`));
		session.addChatText(role,conent);
		return {seg:WaitChat,result:(result),preSeg:"1HDP0T0UU1",outlet:"1HDP0T0UU2"};
	};
	ShowLan.jaxId="1HDP0T0UU1"
	ShowLan.url="ShowLan@"+agentURL
	
	segs["WaitChat"]=WaitChat=async function(input){//:1HDP0T0UU3
		let prompt=("Please input")||input;
		let placeholder=("");
		let text=("");
		let result="";
		result=await session.askChatInput({type:"input",prompt:prompt,placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:CheckInput,result:(result),preSeg:"1HDP0T0UU3",outlet:"1HDP0T0UU4"};
	};
	WaitChat.jaxId="1HDP0T0UU3"
	WaitChat.url="WaitChat@"+agentURL
	
	segs["CheckInput"]=CheckInput=async function(input){//:1HDP0T0UU5
		if(input==="reset"){
			return {seg:ChooseLan,result:(input),preSeg:"1HDP0T0UU5",outlet:"1HDP0T0UU6"};
		}return {seg:CallAI,result:(input),preSeg:"1HDP0T0UU5",outlet:"1HDP0T0UU7"};
	};
	CheckInput.jaxId="1HDP0T0UU5"
	CheckInput.url="CheckInput@"+agentURL
	
	segs["CallAI"]=CallAI=async function(input){//:1HDP0T0UU8
		let result;
		/*#{1HDP0T0UU8Input*/
		input=`Translate following text into ${context.tgtLan}: \n${input}`;
		/*}#1HDP0T0UU8Input*/
		let opts={
			mode:"gpt-3.5-turbo",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false
		};
		let messages=[
			{role:"system",content:`You are a translator. You translate text into ${context.tgtLan}. If text is already ${context.tgtLan}, keep the same.`},
		];
		messages.push({role:"user",content:input});
		
		/*#{1HDP0T0UU8PreCall*/
		/*}#1HDP0T0UU8PreCall*/
		result=await session.callSegLLM("CallAI@"+agentURL,opts,messages);
		/*#{1HDP0T0UU8PostCall*/
		/*}#1HDP0T0UU8PostCall*/
		return {seg:ShowResult,result:(result),preSeg:"1HDP0T0UU8",outlet:"1HDP0T0UU9"};
	};
	CallAI.jaxId="1HDP0T0UU8"
	CallAI.url="CallAI@"+agentURL
	
	segs["ShowResult"]=ShowResult=async function(input){//:1HDP0T0UU10
		let result=input;
		let role="assistant";
		let conent=input;
		session.addChatText(role,conent);
		return {seg:WaitChat,result:(result),preSeg:"1HDP0T0UU10",outlet:"1HDP0T0UU11"};
	};
	ShowResult.jaxId="1HDP0T0UU10"
	ShowResult.url="ShowResult@"+agentURL
	
	agent={
		isAIAgent:true,
		name:"translator",
		url:agentURL,
		autoStart:true,
		jaxId:"1HDP0G4P60",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			/*#{1HDP0G4P60PreEntry*/
			/*}#1HDP0G4P60PreEntry*/
			result={seg:Start,"input":input};
			/*#{1HDP0G4P60PostEntry*/
			/*}#1HDP0G4P60PostEntry*/
			return result;
		},
		/*#{1HDP0G4P60MoreAgentAttrs*/
		/*}#1HDP0G4P60MoreAgentAttrs*/
	};
	/*#{1HDP0G4P60PostAgent*/
	/*}#1HDP0G4P60PostAgent*/
	return agent;
};
/*#{1HDP0G4P60ExCodes*/
/*}#1HDP0G4P60ExCodes*/


export default translator;
export{translator};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HDP0G4P60",
//	"editVersion": 24,
//	"attrs": {
//		"editObjs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDP0G4P61",
//			"editVersion": 2,
//			"attrs": {
//				"translator": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HDP0G4P80",
//					"editVersion": 18,
//					"attrs": {
//						"constructArgs": {
//							"type": "object",
//							"jaxId": "1HDP0G4P90",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0G4P91",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"functions": {
//							"type": "object",
//							"def": "Functions",
//							"jaxId": "1HDP0G4P92",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDP0G4P62",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"segs": {
//			"type": "array",
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HDP0T0UT0",
//					"editVersion": 54,
//					"attrs": {
//						"id": "Start",
//						"label": "New AI Seg",
//						"x": "50",
//						"y": "340",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": {
//							"type": "string",
//							"valText": "This is a translation Agent for demonstrating interactive functionality. Upon launch, the Agent will first ask the user for the target language of translation. Then, in each conversation round, it will translate the user's input text into the selected language. If the user inputs 'rest', it will ask the user for the target language again.",
//							"localize": {
//								"EN": "This is a translation Agent for demonstrating interactive functionality. Upon launch, the Agent will first ask the user for the target language of translation. Then, in each conversation round, it will translate the user's input text into the selected language. If the user inputs 'rest', it will ask the user for the target language again.",
//								"CN": "这是一个用来演示交互功能的翻译 Agent。在启动后，Agent 会先询问用户翻译的目标语言。然后每轮对话把用户输入的文本翻译成用户选择的语言。如果用户输入 “rest” 则重新询问用户目标语言。"
//							},
//							"localizable": true
//						},
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDP0T0UT1",
//							"editVersion": 6,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1HDP0T0UU0",
//					"editVersion": 50,
//					"attrs": {
//						"id": "ChooseLan",
//						"label": "New AI Seg",
//						"x": "240",
//						"y": "340",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV2",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV3",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": {
//							"type": "string",
//							"valText": "Please select the target language",
//							"localize": {
//								"EN": "Please select the target language",
//								"CN": "请选择翻译的目标语言"
//							},
//							"localizable": true
//						},
//						"multi": "false",
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HDUHR54S0",
//									"editVersion": 20,
//									"attrs": {
//										"id": "CN",
//										"text": "中文",
//										"codes": "true"
//									},
//									"linkedSeg": "1HDP0T0UU1"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HDUHR54S1",
//									"editVersion": 20,
//									"attrs": {
//										"id": "EN",
//										"text": "English",
//										"codes": "true"
//									},
//									"linkedSeg": "1HDP0T0UU1"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HDUHR54S2",
//									"editVersion": 20,
//									"attrs": {
//										"id": "JP",
//										"text": "日本语",
//										"codes": "true"
//									},
//									"linkedSeg": "1HDP0T0UU1"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HDP0T0UU1",
//					"editVersion": 60,
//					"attrs": {
//						"id": "ShowLan",
//						"label": "New AI Seg",
//						"x": "440",
//						"y": "340",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV4",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV5",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Event",
//						"text": {
//							"type": "string",
//							"valText": "#`Selected target language: ${input}.`",
//							"localize": {
//								"EN": "#`Selected target language: ${input}.`",
//								"CN": "#`选择的目标语言：${input}。`"
//							},
//							"localizable": true
//						},
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDP0T0UU2",
//							"editVersion": 6,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU3"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1HDP0T0UU3",
//					"editVersion": 50,
//					"attrs": {
//						"id": "WaitChat",
//						"label": "New AI Seg",
//						"x": "560",
//						"y": "270",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV6",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV7",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "Please input",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDP0T0UU4",
//							"editVersion": 6,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU5"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1HDP0T0UU5",
//					"editVersion": 42,
//					"attrs": {
//						"id": "CheckInput",
//						"label": "New AI Seg",
//						"x": "690",
//						"y": "340",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV8",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV9",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDP0T0UU7",
//							"editVersion": 6,
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU8"
//						},
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1HDP0T0UU6",
//									"editVersion": 24,
//									"attrs": {
//										"id": "reset",
//										"condition": "",
//										"codes": "false",
//										"ouput": "",
//										"desc": "条件输出节点。"
//									},
//									"linkedSeg": "1HDP0T0UV10"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HDP0T0UU8",
//					"editVersion": 68,
//					"attrs": {
//						"id": "CallAI",
//						"label": "New AI Seg",
//						"x": "870",
//						"y": "270",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV11",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV12",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "执行一次LLM调用。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"mode": "GPT-3.5",
//						"system": "#`You are a translator. You translate text into ${context.tgtLan}. If text is already ${context.tgtLan}, keep the same.`",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"type": "array",
//							"attrs": []
//						},
//						"prompt": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDP0T0UU9",
//							"editVersion": 6,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU10"
//						},
//						"secret": "false",
//						"keepChat": "No",
//						"apiFiles": {
//							"type": "array",
//							"def": "FileArray",
//							"attrs": []
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HDP0T0UU10",
//					"editVersion": 44,
//					"attrs": {
//						"id": "ShowResult",
//						"label": "New AI Seg",
//						"x": "1010",
//						"y": "330",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV13",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV14",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDP0T0UU11",
//							"editVersion": 6,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UV15"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HDP0T0UV10",
//					"editVersion": 26,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "840",
//						"y": "430",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDP0T0UV16",
//							"editVersion": 6,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UV17"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HDP0T0UV17",
//					"editVersion": 30,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "270",
//						"y": "430",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDP0T0UV18",
//							"editVersion": 6,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HDP0T0UV15",
//					"editVersion": 26,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1160",
//						"y": "210",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDP0T0UV19",
//							"editVersion": 6,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UV20"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HDP0T0UV20",
//					"editVersion": 30,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "590",
//						"y": "210",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDP0T0UV21",
//							"editVersion": 6,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU3"
//						},
//						"dir": "R2L"
//					}
//				}
//			]
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDP0G4P63",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"context": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDP0G4P64",
//			"editVersion": 8,
//			"attrs": {
//				"tgtLan": {
//					"type": "string",
//					"valText": "Chinese"
//				}
//			}
//		},
//		"globalMockup": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDP0G4P65",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"desc": "这是一个AI代理。"
//	}
//}