import {tabNT} from "/@tabos/tabos_nt.js";
import {ChatAction} from "/@aichat/chataction.js"

//----------------------------------------------------------------------------
async function filterInit(){
	console.log("filterInit called.");
	return;
};


//----------------------------------------------------------------------------
async function filterReset(){
	console.log("filterReset called.");
};

//----------------------------------------------------------------------------
async function filterInput(prompt){
	console.log("filterInput called.");
	ChatAction.logLogEvent(this.session,"Hello from log!");
	return prompt;
};

//----------------------------------------------------------------------------
async function filterOutput(result){
	let val;
	let session=this.session;
	//result=await this.pipeChat("./translate.aichat",result);
	return result;
	//Test confirm:
	val=await session.askUser({type:"confirm",text:"Please cofirm this result: "+result});
	//Test Menu:
	val=await session.askUser({
		type:"menu",text:"Select:",
		items:[{text:"Red",icon:"",iconColor:[255,0,0,1],code:"red"},{text:"Green",code:"green"},{text:"Blue",code:"blue",checked:true}]
	});
	//Multi-select:
	val=await session.askUser({
		type:"menu",text:"Multi select:",multiSelect:true,
		items:[{text:"Red",code:"red"},{text:"Green",code:"green"},{text:"Blue",code:"blue",checked:true}]
	});
	//One line input:
	val=await session.askUser({
		type:"input",prompt:"Please input:",placeholder:"input something",text:""
	});
	//Password input:
	val=await session.askUser({
		type:"input",inputType:"password",prompt:"Please input password:",placeholder:"input password",text:""
	});
	//Memo input:
	val=await session.askUser({
		type:"input",memo:true,prompt:"Please input password:",placeholder:"input password",text:""
	});
	return result;
};

let testName=10;
let copyNodes=null;
let updateState;
//APIs:
async function getCurrentWeather({location, unit="fahrenheit"}) {
	let res;
	const fakeInfo = {
		"location": location,
		"temperature": "72",
		"unit": unit,
		"forecast": ["sunny", "windy"],
	};
	if(!await tabNT.checkLogin(false)){
		return JSON.stringify(fakeInfo);
	}
	res=await tabNT.makeCall("getWeather",{city:location});
	if(res.code===200){
		return JSON.stringify(res);
	}
	return JSON.stringify(fakeInfo);
}

function getDateTime() {
    return ""+Date();
}

let sum=function(a,b){
	return a+b;
};

var sub;
sub=function(a,b){
	return a-b;
};

export const ChatAPI=[
	{
		def:{
			"name": "getCurrentWeather",
			"description": "Get the current weather in a given location",
			"parameters": {
				"type": "object",
				"properties": {
					"location": {
						"type": "string",
						"description": "The city and state, e.g. San Francisco, CA",
					},
					"unit": {"type": "string", "enum": ["celsius", "fahrenheit"]},
				},
				"required": ["location"],
			}
		},
		func:getCurrentWeather
	},
	{
		def:{
			"name": "getDateTime",
			"description": "Get the current time and date",
			"parameters": {
				"type": "object","properties": {}
			}
		},
		func:getDateTime
	}
];

export {filterInit,filterReset,filterInput,filterOutput};