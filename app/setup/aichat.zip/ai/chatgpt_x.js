//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
/*#{1HDOQGMUJ0MoreImports*/
/*}#1HDOQGMUJ0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HDOQGMUJ0StartDoc*/
/*}#1HDOQGMUJ0StartDoc*/
//----------------------------------------------------------------------------
let chatgpt_x=async function(session){
	let context,globalContext;
	let self;
	let Start,Setup,StartChat,WaitChat,CheckInput,CallAI,Result;
	/*#{1HDOQGMUJ0LocalVals*/
	/*}#1HDOQGMUJ0LocalVals*/
	
	/*#{1HDOQGMUJ0PreContext*/
	/*}#1HDOQGMUJ0PreContext*/
	globalContext=session.globalContext;
	context={
		"mode":"gpt-3.5-turbo",
		/*#{1HDOQGMUK3ExCtxAttrs*/
		/*}#1HDOQGMUK3ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1HDOQGMUJ0PostContext*/
	/*}#1HDOQGMUJ0PostContext*/
	let agent,segs={};
	segs["Start"]=Start=async function(input){//:1HDOR5CE12
		let result=input;
		let role="assistant";
		let conent=(($ln==="CN")?("这是一个展示 AI Agent 与用户高效交互及动态更改设定的例子。Agent 启动后会通过菜单询问用户使用哪一种 AI 引擎进行对话，然后 Agent 会用用户指定的 AI 引擎与用户对话。如果用户在对话的时候输入 “gpt” 则会重新让用户选择 AI 引擎。"):("This is an example demonstrating efficient interaction and dynamic configuration changes between an AI Agent and a user. After the Agent is launched, it will ask the user through a menu which AI engine to use for the conversation, and then the Agent will engage in a conversation with the user using the specified AI engine. If the user enters 'gpt' during the conversation, the user will be asked to select an AI engine again."));
		session.addChatText(role,conent);
		return {seg:Setup,result:(result),preSeg:"1HDOR5CE12",outlet:"1HDOR5CE13"};
	};
	Start.jaxId="1HDOR5CE12"
	Start.url="Start@"+agentURL
	
	segs["Setup"]=Setup=async function(input){//:1HDOR5CE10
		let prompt=((($ln==="CN")?("请选择 AI 引擎"):("Please select an AI engine")))||input;
		let items=[
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"ChatGPT 3.5",code:0},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"ChatGPT 4",code:1},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"ChatGPT 3.5 16K",code:2},
		];
		let result="";
		let item=null;
		/*#{1HDOR5CE10PreCodes*/
		/*}#1HDOR5CE10PreCodes*/
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,items:items});
		/*#{1HDOR5CE10PostCodes*/
		switch(item.code){
			case 0:
				context.mode="gpt-3.5-turbo";
				break;
			case 1:
				context.mode="gpt-4";
				break;
			case 2:
				context.mode="gpt-3.5-turbo-16k";
				break;
		}
		/*}#1HDOR5CE10PostCodes*/
		if(item.code===0){
			return {seg:StartChat,result:(result),preSeg:"1HDOR5CE10",outlet:"1HE61TQD60"};
		}
		if(item.code===1){
			return {seg:StartChat,result:(result),preSeg:"1HDOR5CE10",outlet:"1HE61TQD61"};
		}
		if(item.code===2){
			return {seg:StartChat,result:(result),preSeg:"1HDOR5CE10",outlet:"1HE61TQD62"};
		}
		/*#{1HDOR5CE10FinCodes*/
		/*}#1HDOR5CE10FinCodes*/
		return {result:result};
	
	};
	Setup.jaxId="1HDOR5CE10"
	Setup.url="Setup@"+agentURL
	
	segs["StartChat"]=StartChat=async function(input){//:1HDOR5CE14
		let result=input;
		let role="event";
		let conent=`Use mode: ${context.mode}`;
		session.addChatText(role,conent);
		return {seg:WaitChat,result:(result),preSeg:"1HDOR5CE14",outlet:"1HDOR5CE20"};
	};
	StartChat.jaxId="1HDOR5CE14"
	StartChat.url="StartChat@"+agentURL
	
	segs["WaitChat"]=WaitChat=async function(input){//:1HDOR5CE21
		let prompt=("Please input")||input;
		let placeholder=("");
		let text=("");
		let result="";
		result=await session.askChatInput({type:"input",prompt:prompt,placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:CheckInput,result:(result),preSeg:"1HDOR5CE21",outlet:"1HDOR5CE22"};
	};
	WaitChat.jaxId="1HDOR5CE21"
	WaitChat.url="WaitChat@"+agentURL
	
	segs["CheckInput"]=CheckInput=async function(input){//:1HDOR5CE23
		if(input==="gpt"){
			/*#{1HDOR5CE24Codes*/
			/*}#1HDOR5CE24Codes*/
			return {seg:Setup,result:(input),preSeg:"1HDOR5CE23",outlet:"1HDOR5CE24"};
		}return {seg:CallAI,result:(input),preSeg:"1HDOR5CE23",outlet:"1HDOR5CE25"};
	};
	CheckInput.jaxId="1HDOR5CE23"
	CheckInput.url="CheckInput@"+agentURL
	
	segs["CallAI"]=CallAI=async function(input){//:1HDOR5CE11
		let result;
		let opts={
			mode:context.mode,
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false
		};
		let messages=[
			{role:"system",content:"You are a smart assistant."},
		];
		messages.push({role:"user",content:input});
		
		result=await session.callSegLLM("CallAI@"+agentURL,opts,messages,true);
		return {seg:Result,result:(result),preSeg:"1HDOR5CE11",outlet:"1HDOR5CE26"};
	};
	CallAI.jaxId="1HDOR5CE11"
	CallAI.url="CallAI@"+agentURL
	
	segs["Result"]=Result=async function(input){//:1HDOR5CE27
		let result=input;
		let role="assistant";
		let conent=input;
		session.addChatText(role,conent);
		return {seg:WaitChat,result:(result),preSeg:"1HDOR5CE27",outlet:"1HDOR5CE28"};
	};
	Result.jaxId="1HDOR5CE27"
	Result.url="Result@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"chatgpt_x",
		url:agentURL,
		autoStart:true,
		jaxId:"1HDOQGMUJ0",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			/*#{1HDOQGMUJ0PreEntry*/
			/*}#1HDOQGMUJ0PreEntry*/
			result={seg:Start,"input":input};
			/*#{1HDOQGMUJ0PostEntry*/
			/*}#1HDOQGMUJ0PostEntry*/
			return result;
		},
		/*#{1HDOQGMUJ0MoreAgentAttrs*/
		/*}#1HDOQGMUJ0MoreAgentAttrs*/
	};
	/*#{1HDOQGMUJ0PostAgent*/
	/*}#1HDOQGMUJ0PostAgent*/
	return agent;
};
/*#{1HDOQGMUJ0ExCodes*/
/*}#1HDOQGMUJ0ExCodes*/


export default chatgpt_x;
export{chatgpt_x};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HDOQGMUJ0",
//	"editVersion": 32,
//	"attrs": {
//		"editObjs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDOQGMUK0",
//			"editVersion": 2,
//			"attrs": {
//				"chatgpt_x": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HDOQGMUK5",
//					"editVersion": 24,
//					"attrs": {
//						"constructArgs": {
//							"type": "object",
//							"jaxId": "1HDOQGMUL0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOQGMUL1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"functions": {
//							"type": "object",
//							"def": "Functions",
//							"jaxId": "1HDOQGMUL2",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDOQGMUK1",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"segs": {
//			"type": "array",
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HDOR5CE12",
//					"editVersion": 68,
//					"attrs": {
//						"id": "Start",
//						"label": "New AI Seg",
//						"x": "50",
//						"y": "230",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS20",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS21",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": {
//							"type": "string",
//							"valText": "This is an example demonstrating efficient interaction and dynamic configuration changes between an AI Agent and a user. After the Agent is launched, it will ask the user through a menu which AI engine to use for the conversation, and then the Agent will engage in a conversation with the user using the specified AI engine. If the user enters 'gpt' during the conversation, the user will be asked to select an AI engine again.",
//							"localize": {
//								"EN": "This is an example demonstrating efficient interaction and dynamic configuration changes between an AI Agent and a user. After the Agent is launched, it will ask the user through a menu which AI engine to use for the conversation, and then the Agent will engage in a conversation with the user using the specified AI engine. If the user enters 'gpt' during the conversation, the user will be asked to select an AI engine again.",
//								"CN": "这是一个展示 AI Agent 与用户高效交互及动态更改设定的例子。Agent 启动后会通过菜单询问用户使用哪一种 AI 引擎进行对话，然后 Agent 会用用户指定的 AI 引擎与用户对话。如果用户在对话的时候输入 “gpt” 则会重新让用户选择 AI 引擎。"
//							},
//							"localizable": true
//						},
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDOR5CE13",
//							"editVersion": 16,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDOR5CE10"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1HDOR5CE10",
//					"editVersion": 73,
//					"attrs": {
//						"id": "Setup",
//						"label": "New AI Seg",
//						"x": "250",
//						"y": "230",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS22",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS23",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"prompt": {
//							"type": "string",
//							"valText": "Please select an AI engine",
//							"localize": {
//								"EN": "Please select an AI engine",
//								"CN": "请选择 AI 引擎"
//							},
//							"localizable": true
//						},
//						"multi": "false",
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HE61TQD60",
//									"editVersion": 26,
//									"attrs": {
//										"id": "GPT-3.5",
//										"text": "ChatGPT 3.5"
//									},
//									"linkedSeg": "1HDOR5CE14"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HE61TQD61",
//									"editVersion": 27,
//									"attrs": {
//										"id": "GPT-4",
//										"text": "ChatGPT 4"
//									},
//									"linkedSeg": "1HDOR5CE14"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HE61TQD62",
//									"editVersion": 35,
//									"attrs": {
//										"id": "GPT-3.5-16K",
//										"text": "ChatGPT 3.5 16K"
//									},
//									"linkedSeg": "1HDOR5CE14"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HDOR5CE14",
//					"editVersion": 96,
//					"attrs": {
//						"id": "StartChat",
//						"label": "New AI Seg",
//						"x": "470",
//						"y": "230",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS24",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS25",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Event",
//						"text": "#`Use mode: ${context.mode}`",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDOR5CE20",
//							"editVersion": 18,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDOR5CE21"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1HDOR5CE21",
//					"editVersion": 96,
//					"attrs": {
//						"id": "WaitChat",
//						"label": "New AI Seg",
//						"x": "610",
//						"y": "150",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS26",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS27",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "Please input",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDOR5CE22",
//							"editVersion": 19,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDOR5CE23"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1HDOR5CE23",
//					"editVersion": 69,
//					"attrs": {
//						"id": "CheckInput",
//						"label": "New AI Seg",
//						"x": "730",
//						"y": "230",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS30",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS31",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "gpt",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDOR5CE25",
//							"editVersion": 16,
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDOR5CE11"
//						},
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1HDOR5CE24",
//									"editVersion": 79,
//									"attrs": {
//										"id": "Reset",
//										"condition": "input===\"gpt\"",
//										"codes": "true",
//										"ouput": "",
//										"desc": "条件输出节点。"
//									},
//									"linkedSeg": "1HDOR6DS32"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HDOR5CE11",
//					"editVersion": 118,
//					"attrs": {
//						"id": "CallAI",
//						"label": "New AI Seg",
//						"x": "900",
//						"y": "150",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS33",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS34",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"mode": "#context.mode",
//						"system": "You are a smart assistant.",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"type": "array",
//							"attrs": []
//						},
//						"prompt": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDOR5CE26",
//							"editVersion": 16,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDOR5CE27"
//						},
//						"secret": "false",
//						"keepChat": "No",
//						"clearChat": "2",
//						"inputPrefix": "",
//						"inputPostfix": "",
//						"apiFiles": {
//							"type": "array",
//							"def": "FileArray",
//							"attrs": []
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HDOR5CE27",
//					"editVersion": 96,
//					"attrs": {
//						"id": "Result",
//						"label": "New AI Seg",
//						"x": "1030",
//						"y": "210",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS35",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDOR6DS36",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDOR5CE28",
//							"editVersion": 16,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDOR6DS37"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HDOR6DS37",
//					"editVersion": 48,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1150",
//						"y": "80",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDOR6DS38",
//							"editVersion": 16,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDOR6DS39"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HDOR6DS39",
//					"editVersion": 36,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "640",
//						"y": "80",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDOR6DS310",
//							"editVersion": 16,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDOR5CE21"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HDOR6DS32",
//					"editVersion": 28,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "880",
//						"y": "330",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDOR6DS311",
//							"editVersion": 15,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDOR6DS312"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HDOR6DS312",
//					"editVersion": 32,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "280",
//						"y": "330",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HDOR6DS313",
//							"editVersion": 15,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDOR5CE10"
//						},
//						"dir": "R2L"
//					}
//				}
//			]
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDOQGMUK2",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"context": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDOQGMUK3",
//			"editVersion": 14,
//			"attrs": {
//				"mode": {
//					"type": "string",
//					"valText": "gpt-3.5-turbo"
//				}
//			}
//		},
//		"globalMockup": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HDOQGMUK4",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"desc": "这是一个AI代理。"
//	}
//}