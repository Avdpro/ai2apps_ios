//This function checks the length of the current document summary and shortens it further if it is too long:
const MAX_STEPS=5
const LENGTH_LIMIT=500
async function maybeShorter(info){
	let len,session,step;
	len=info.length;
	step=0;
	while(len>LENGTH_LIMIT){
		step++;
		info=await this.pipeChat("./briefinfo.aichat",info);
		if(step>=MAX_STEPS){
			break;
		}
		len=info.length;
	}
	return info;
};
export default maybeShorter;
export {maybeShorter};