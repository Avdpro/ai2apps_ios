
//----------------------------------------------------------------------------
async function filterInit(seesion){
	console.log("filterInit called.");
};


//----------------------------------------------------------------------------
async function filterReset(seesion){
	console.log("filterReset called.");
};

//----------------------------------------------------------------------------
async function filterPrechat(seesion,prompt){
	console.log("filterReset called.");
};

//----------------------------------------------------------------------------
async function filterPostchat(seesion,prompt){
	//TODO: Code this:
};


export {fixInit,fixReset}