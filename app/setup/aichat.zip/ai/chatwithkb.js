import {tabOS,tabFS} from "/@tabos";
async function input(prompt){
	let docs,pos1,pos2,path,context,text;
	docs=await this.pipeChat("./choosedoc.aichat",prompt);
	pos1=docs.indexOf("[");
	pos2=docs.indexOf("]");
	if(pos1>=0 && pos2>pos1){
		docs=docs.substring(pos1,pos2+1);
		docs=JSON.parse(docs);
	}
	try{
		if(docs.length>0){
			console.log("Docs: ");
			console.log(docs);
			context="";
			for(path of docs){
				text=await tabFS.readFile(path,"utf8");
				context+="\n"+text;
			}
			this.chatContext=context;
		}
	}catch(err){
		console.warn(err);
	}
	return prompt;
};

export {input};