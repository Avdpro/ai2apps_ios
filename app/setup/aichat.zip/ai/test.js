//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
/*#{1HC98474C0MoreImports*/
/*}#1HC98474C0MoreImports*/
const basePath=pathLib.dirname(import.meta.url);
const $ln=VFACT.lanCode||"EN";
/*#{1HC98474C0StartDoc*/
/*}#1HC98474C0StartDoc*/
//----------------------------------------------------------------------------
let test=function(session){
	let state,context;
	let self;
	
	
	/*#{1HC98474C0LocalVals*/
	/*}#1HC98474C0LocalVals*/
	
	/*#{1HC98474C0PreContext*/
	/*}#1HC98474C0PreContext*/
	/*#{1HC98474C0PostContext*/
	/*}#1HC98474C0PostContext*/
	let agent,segs={};
	/*#{1HC98474C0PostAgent*/
	/*}#1HC98474C0PostAgent*/
	return agent;
};
/*#{1HC98474C0ExCodes*/
/*}#1HC98474C0ExCodes*/


export default test;
export{test};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HC98474C0",
//	"editVersion": 18,
//	"attrs": {
//		"editObjs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HC98474C1",
//			"editVersion": 2,
//			"attrs": {
//				"test": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HC98474D0",
//					"editVersion": 20,
//					"attrs": {
//						"constructArgs": {
//							"type": "object",
//							"jaxId": "1HC98474D1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HC98474D2",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"functions": {
//							"type": "object",
//							"def": "Functions",
//							"jaxId": "1HC98474D3",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"desc": "这是一个AI代理。",
//		"agent": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HC98474C2",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"segs": {
//			"type": "array",
//			"attrs": []
//		},
//		"entry": "",
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HC98474C3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"context": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HC98474C4",
//			"editVersion": 0,
//			"attrs": {}
//		}
//	}
//}