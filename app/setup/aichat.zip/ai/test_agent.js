import pathLib from "/@path";
const basePath=pathLib.dirname(import.meta.url);
function myAgent(session){
	let agent,segs;
	let context={
		name:"",
		age:"",
	};
	segs={
		"start":async function(input){
			let result;
			session.outputBlock({role:"assistant",text:"Hello, how are you."});
			result=session.execSeg(segs,"getUserInput",input);
			//TODO: function
			return await result;
		},
		"getUserInput":async function(input){
			let result;
			result=await this.session.askUser({type:"input",text:"How is it"});
			result=await segs["execGPT"].call(this,result);
			//TODO: function
			return result;
		},
		"execGPT":async function(input){
			let result;
			result=await session.pipeChat(pathLib.join("basePath","./guess.aichat"),"input");
			//TODO: function
			return result;
		};
	};
	agent={
		context:context,
		chatEntry:null,
		exec:function(input){
			let result;
			result=await session.execSeg(segs,"start",input);
			return result;
		}
	};
	return agent;
};

