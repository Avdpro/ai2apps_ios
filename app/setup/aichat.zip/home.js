//Auto genterated by Cody
import {tabOS,tabFS,tabTask} from "/@tabos";
import {VFACT} from "/@vfact";
import {} from "/@vfact/vfact_app.js";
import{appCfg} from "./cfg/appCfg.js";
import{} from "/@StdUI/cfg/appCfg.js";
/*#{MoreImports*/
import {AppLib} from "/@homekit/data/AppLib.js";
import pathLib from "/@path";
import {DlgAIChatHome} from "./ui/DlgAIChatHome.js";
import {DlgTask} from "/@homekit/ui/DlgTask.js";
/*}#MoreImports*/
VFACT.appCfg=appCfg;
//Prefix extern-lib's appCfgs:
{
	let cfgs,name;
	cfgs=window.codyAppCfgs;
	for(name in cfgs){
		cfgs[name].applyCfg();
	}
}
/*#{StartApp*/
/*}#StartApp*/
//----------------------------------------------------------------------------
//Start the app:
async function startApp() {
	/*#{AppCode*/
	let app,uiDef;
	
	document.title="Tab-OS App";
	//------------------------------------------------------------------------
	//Check if we are in appFrame:
	let appFrame=null;
	//CheckAppFrame:
	{
		let pw;
		appFrame=null;
		pw=window.parent;
		if(pw!==window){
			if(pw.getAppFrame){
				appFrame=window.appFrame=pw.getAppFrame(window);
			}
		}
	}
	window.tabOSApp=app=await VFACT.createApp();
	
	//setup open (openPath, openMeta...) API:
	await AppLib.setupOpenAPI(app,appFrame);
	
	uiDef=DlgAIChatHome(app,appFrame);
	if(!appFrame){
		uiDef=AppLib.setupMiniDocker(app,uiDef);
	}
	//init app, create app UI tree:
	await VFACT.initApp(app,uiDef,{
		wait:1,
		shortcuts:appCfg.shortcuts,
		DlgTask:DlgTask,
		appFrame:appFrame,
	});
	/*}#AppCode*/
}
tabOS.setup().then(()=>{startApp();});
/*#{EndDoc*/
/*}#EndDoc*/
