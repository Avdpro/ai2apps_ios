import {EditAttr} from "../EditAttr.js";
import {EditObj} from "../EditObj.js";
import {EditArray} from "../EditArray.js";
import {ExportObj} from "../exporters/ExportObj.js";
import inherits from "/@inherits";
import {esprima} from "/@tabos/utils/esprima.mjs";
import {VFACT} from "/@vfact";

const $ln=VFACT.lanCode;
let EditAISeg,editAISeg,EditAISegOutlet,editAISegOutlet,EditAISegJoint,editAISegJoint;
//****************************************************************************
//Default def:
//****************************************************************************
let SegOutletDef,SegOutletArrayDef,SegObjShellAttr;
{
	SegOutletDef={
		name:"AISegOutlet",allowExtraAttr:false,
		constructFunc:EditAISegOutlet,
		attrs:{
			"id":{
				name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"",
			},
			"desc":{
				name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",key:1,fixed:1,initVal:(($ln==="CN")?("这是一个输出。"):/*EN*/("This is an outlet.")),
			},
			"showLine":{
				name:"showLine",showName:(($ln==="CN")?("显示连接线"):/*EN*/("Show joint line")),type:"bool",key:1,fixed:1,initVal:true,
			},
			"hideTree":{
				name:"hideTree",showName:(($ln==="CN")?("隐藏后续项目"):/*EN*/("Hide subsequents")),type:"bool",key:1,fixed:1,initVal:false,
			},
		}
	};
	SegOutletArrayDef={elementType:"aiseg_outlet",allowExtraAttr:1};

	SegObjShellAttr={
		"id":{
			name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"",
		},
		"label":{
			name:"label",showName:(($ln==="CN")?("标签"):/*EN*/("Label")),type:"string",key:1,fixed:1,initVal:"New AI Seg",
		},
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",key:1,fixed:1,initVal:(($ln==="CN")?("这是一个AISeg。"):/*EN*/("This is an AISeg.")),
		},
		"outlets":{
			name:"outlets",type:"array",def:SegOutletArrayDef,fixed:1,key:1,edit:false,navi:"doc"
		},
		"x":{
			name:"x",showName:"X",type:"int",key:1,fixed:1,initVal:0,
		},
		"y":{
			name:"y",showName:"Y",type:"int",key:1,fixed:1,initVal:0,
		},
		"extraPpts":{
			name:"extraPpts",showName:(($ln==="CN")?("附加属性"):/*EN*/("Extra Properties")),type:"object",def:"Object",key:1,fixed:1,navi:"doc",edit:1,
		},
		"mockup":{name:"mockup",showName:(($ln==="CN")?("仅供展示"):/*EN*/("Mockup Item")),type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false},
		"codes":{name:"codes",showName:(($ln==="CN")?("附有代码"):/*EN*/("With Codes")),type:"bool",initVal:false,key:1,fixed:1,edit:1,rawEdit:false},
		"nameVal":{name:"nameVal",showName:(($ln==="CN")?("控件名变量"):/*EN*/("ID Name Variable")),type:"bool",initVal:false,key:1,fixed:1,edit:true,rawEdit:false}
	};
}

//****************************************************************************
//:EditAISegJoint
//****************************************************************************
{
	EditAISegJoint=function(outlet){
		this.outlet=outlet;
		this.keyPoints=[];
		this.tgtSeg=null;
		this.canvas=null;
		this.svgLine=null;
		this.svgPoints=[];
	};
	editAISegJoint=EditAISegJoint.prototype={};
	
	//------------------------------------------------------------------------
	editAISegJoint.clear=function(){
		let svgLine=this.svgLine;
		if(svgLine){
			this.canvas.removeChild(svgLine);
			this.svgLine=null
			this.canvas=null;
		}
	};
	
	//------------------------------------------------------------------------
	editAISegJoint.genSaveVO=function(){
		let vo={};
		//TODO: Code this:
		return vo;
	};
	
	//------------------------------------------------------------------------
	editAISegJoint.loadFromVO=function(vo){
		//TODO: Code this:
	};
	
	//------------------------------------------------------------------------
	let drawLine=function(svgPts,pt1,pt2){
		let xs,ys,xm,ym,xe,ye,changed;
		changed=false;
		xs=pt1.x;ys=pt1.y;
		xe=pt2.x;ye=pt2.y;
		if(pt1.dir[0]){//X
			xm=pt2.x;
			ym=pt1.y;
		}else{
			xm=pt1.x;
			ym=pt2.y;
		}
		svgPts.push(xs,ys,xm,ym,xe,ye);
	};
	
	//------------------------------------------------------------------------
	editAISegJoint.render=function(canvas){
		let kps,rootPoint,endPoint,rootHud,endHud,hud,svgPts,drawPts,rect,ox,oy,svgLine,changed;
		canvas=canvas||this.canvas;
		rootHud=this.outlet.hud;
		if(!canvas){
			return;
		}
		if(!rootHud){
			//TODO: Clear lines:
		}
		changed=false;
		svgPts=this.svgPoints;
		drawPts=[];
		kps=this.keyPoints;
		svgLine=this.svgLine;
		//First, adust keyPoints:
		{
			let i,n,pt,nxtPt,x1,y1,x2,y2,line;
			n=kps.length;
			//Add / adjust root point:
			rootPoint=kps[0];
			rect=canvas.getBoundingClientRect();
			ox=rect.x;oy=rect.y;
			if(!rootPoint){
				kps[0]=rootPoint={
					type:"start",x:0,y:0,hud:rootHud,line:null,dir:[1,0],
				};
			}
			
			//Add / adjust end point:
			endPoint=kps[n-1];
			if(this.tgtSeg){
				endHud=this.tgtSeg.hud.BoxEntry;
				if(endPoint.type!=="end"){
					endPoint={
						type:"end",x:0,y:0,hud:endHud,line:null,dir:[1,0],
					};
					kps.push(endPoint);
				}
			}else{
				if(endPoint && endPoint.type==="end"){
					kps.pop();
				}
			}
			
			//Adjust all points' pos:
			for(i=0;i<n;i++){
				pt=kps[i];
				hud=pt.hud;
				rect=hud.getBoundingClientRect();
				switch(pt.type){
					case "start":
						pt.x=rect.x+rect.width-ox;
						pt.y=rect.y+rect.height*0.5-oy;
						break;
					case "end":
						pt.x=rect.x-ox;
						pt.y=rect.y+rect.height*0.5-oy;
						break;
					default:
						pt.x=rect.x+rect.width*0.5-ox;
						pt.y=rect.y+rect.height*0.5-oy;
						break;
				}
			}
			//Adjust all points' line:
			for(i=0;i<n-1;i++){
				pt=kps[i];
				nxtPt=kps[i+1];
				drawLine(drawPts,pt,nxtPt);
			}
			if(!svgLine){
				svgLine = document.createElementNS("http://www.w3.org/2000/svg", "polyline");
				svgLine.setAttribute("points", ""+drawPts);
				svgLine.setAttribute("fill", "none");
				svgLine.setAttribute("stroke", "black");
				svgLine.setAttribute("stroke-width", "3");
				this.canvas=canvas;
				canvas.appendChild(svgLine);
				this.svgPoints=drawPts;
				this.svgLine=svgLine;
			}else{
				if(drawPts.length===svgPts.length){
					n=drawPts.length;
					for(i=0;i<n;i++){
						if(drawPts[i]!==svgPts[i]){
							changed=true;
							break;
						}
					}
				}else{
					changed=true;
				}
				if(changed){
					this.svgPoints=drawPts;
					svgLine.setAttribute("points", ""+drawPts);
				}
			}
		}
		
	};
	
	//------------------------------------------------------------------------
	editAISegJoint.startDragTgtPoint=function(){
		//TODO: Code this:
		this.render();
	};

	//------------------------------------------------------------------------
	editAISegJoint.moveDragTgtPoint=function(x,y){
		//TODO: Code this:
		this.render();
	};

	//------------------------------------------------------------------------
	editAISegJoint.endDragTgtPoint=function(tgtSeg,x,y){
		//TODO: Code this:
		if(tgtSeg){
		}
		this.render();
	};
	
	//------------------------------------------------------------------------
	editAISegJoint.startDragKeyPoint=function(keyPoint){
		//TODO: Code this:
	};

	//------------------------------------------------------------------------
	editAISegJoint.moveDragKeyPoint=function(keyPoint,x,y){
		//TODO: Code this:
	};

	//------------------------------------------------------------------------
	editAISegJoint.endDragKeyPoint=function(keyPoint,x,y){
		//TODO: Code this:
	};
}

//****************************************************************************
//:EditAISegOutlet
//****************************************************************************
{
	EditAISegOutlet=function(owner,def,init){
		let self;
		self=this;
		EditObj.call(this,owner,def,true);
		this.isAISegOutlet=true;
		this.joint=new EditAISegJoint(this);
		this.liveHud=null;
	};
	inherits(EditAISegOutlet,EditObj);
	EditAttr.regAttrType("aiseg_outlet",EditAISegOutlet);
	editAISegOutlet=EditAISegOutlet.prototype;
	
	//------------------------------------------------------------------------
	editAISegOutlet.genSaveVO=function(){
		let vo=EditObj.prototype.genSaveVO.call(this);
		vo.joint=this.joint.genSaveVO();
	};
	
	//------------------------------------------------------------------------
	editAISegOutlet.loadFromVO=function(vo){
		EditObj.prototype.loadFromVO.call(this,vo);
		this.joint.loadFromVO(vo.joint);
	};
	
	//------------------------------------------------------------------------
	editAISegOutlet.render=function(canvas){
		this.joint.render(canvas);
	};
	
	//------------------------------------------------------------------------
	editAISegOutlet.bindLiveObj=function(liveObj){
		//TODO: Code this:
	};
}

//****************************************************************************
//:EditAISeg
//****************************************************************************
EditAISeg=function(owner,def,init){
	let self;
	self=this;
	EditObj.call(this,owner,def,true);
	this.isAISeg=true;
	//Inbuilt outlet:
	this.outlet=new EditAISegOutlet(this,{type:"aiseg_outlet",name:"outlet",def:SegOutletDef},true);
	//Extra outlets:
	this.outletsVal=this.getAttr("outlets");
	this.outletsList=this.outlets.attrList;
	this.idVal=this.this.getAttr("id");
	
	this.liveHudObj=null;
};
inherits(EditAISeg,EditObj);
EditAttr.regAttrType("aiseg",EditAISeg);
editAISeg=EditAISeg.prototype;

//****************************************************************************
//:EditAISeg def registers
//****************************************************************************
{
	var segDefRegs={};
	EditAISeg.regDef=function(name,def){
		if(def){
			segDefRegs[name]=def;
		}else{
			delete segDefRegs[name];
		}
	};
	EditAISeg.getDef=function(name){
		return segDefRegs[name];
	};
}

//****************************************************************************
//:EditAISeg I/O
//****************************************************************************
{
	//------------------------------------------------------------------------
	editAISeg.genSaveVO=function(){
		let vo;
		vo=EditObj.prototype.genSaveVO.call(this);
		vo.outlet=this.outlet.genSaveVO();
		return vo;
	};
}

//****************************************************************************
//:EditAISeg Live obj access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	editAISegOutlet.bindLiveObj=function(liveObj){
		let outlet;
		if(this.liveHudObj){
			this.dropLiveObj(this.liveHudObj);
		}
		this.liveHudObj=liveObj;
		this.outlet.bindLiveObj(liveObj);
		for(outlet of this.outletsList){
			outlet.bindLiveObj(liveObj);
		}
	};
	
}

//****************************************************************************
//:EditAISeg types:
//****************************************************************************
{
	//------------------------------------------------------------------------
	//AISeg that use a code seg:
	EditAISeg.regDef("function",{
		name:"code",showName:"Code Seg",
		attrs:{
			...SegObjShellAttr,
			"codes":{name:"codes",showName:(($ln==="CN")?("附有代码"):/*EN*/("With Codes")),type:"bool",initVal:true,key:1,fixed:1,edit:false},
		},
		listHint:[
			"id","label","x","y","desc","nameVal"
		]
	});

	//------------------------------------------------------------------------
	//AISeg that call a function:
	EditAISeg.regDef("function",{
		name:"function",showName:"Function",
		attrs:{
			...SegObjShellAttr,
			"source":{
				name:"source",showName:(($ln==="CN")?("源文件"):/*EN*/("Source")),type:"path",key:1,fixed:1,initVal:""),
			},
			"function":{
				name:"function",showName:(($ln==="CN")?("函数名"):/*EN*/("Function name")),type:"string",key:1,fixed:1,initVal:"",
			}
		},
		listHint:[
			"id","label","source","function","x","y","desc","codes","nameVal"
		]
	});

	//------------------------------------------------------------------------
	//AISeg that call a aichat:
	EditAISeg.regDef("aichat",{
		name:"aichat",showName:"AIChat",
		attrs:{
			...SegObjShellAttr,
			"source":{
				name:"source",showName:(($ln==="CN")?("源文件"):/*EN*/("Source")),type:"path",key:1,fixed:1,initVal:""),
			},
		},
		listHint:[
			"id","label","source","x","y","desc","codes","nameVal"
		]
	});

	//------------------------------------------------------------------------
	//AISeg that make switch based on input:
	EditAISeg.regDef("switch",{
		name:"switch",showName:"Switch",
		attrs:{
			...SegObjShellAttr,
		},
		listHint:[
			"id","label","x","y","desc","codes","nameVal"
		]
	});
	
	//------------------------------------------------------------------------
	//AISeg that make survey based on input and summary it:
	EditAISeg.regDef("survey",{
		name:"survey",showName:"Survey",
		attrs:{
			...SegObjShellAttr,
		},
		listHint:[
			"id","label","x","y","desc","codes","nameVal"
		]
	});
	
	//------------------------------------------------------------------------
	//AISeg that make out content to user:
	EditAISeg.regDef("output",{
		name:"output",showName:"Ouput",
		attrs:{
			...SegObjShellAttr,
			"role":{
				name:"role",showName:(($ln==="CN")?("角色"):/*EN*/("Role")),type:"string",key:1,fixed:1,initVal:"assistant"),
			},
		},
		listHint:[
			"id","label","x","y","desc","codes","nameVal"
		]
	});

	//------------------------------------------------------------------------
	//AISeg that ask user to confirm:
	EditAISeg.regDef("askUser",{
		name:"askUser",showName:"Query user",
		attrs:{
			...SegObjShellAttr,
			"queryText":{
				name:"queryText",showName:(($ln==="CN")?("询问文本"):/*EN*/("Query text")),type:"string",key:1,fixed:1,initVal:"Please input"),
			},
			"multiLine":{
				name:"multi",showName:(($ln==="CN")?("多行输入"):/*EN*/("Multi-Line")),type:"bool",key:1,fixed:1,initVal:false),
			},
			"file":{
				name:"file",showName:(($ln==="CN")?("文件输入"):/*EN*/("File path(es)")),type:"bool",key:1,fixed:1,initVal:false),
			},
			//TODO:Init outlets:
		},
		listHint:[
			"id","label","queryText","x","y","desc","codes","nameVal"
		]
	});
	
	//------------------------------------------------------------------------
	//AISeg that ask user to confirm:
	EditAISeg.regDef("askConfirm",{
		name:"askConfirm",showName:"Confirm query",
		attrs:{
			...SegObjShellAttr,
			"queryText":{
				name:"queryText",showName:(($ln==="CN")?("询问文本"):/*EN*/("Query text")),type:"string",key:1,fixed:1,initVal:"Please confirm"),
			},
			//TODO:Init outlets:
		},
		listHint:[
			"id","label","queryText","x","y","desc","codes","nameVal"
		]
	});
	
	//------------------------------------------------------------------------
	//AISeg that ask user to choose from items:
	EditAISeg.regDef("askMenu",{
		name:"askMenu",showName:"Menu Query",
		attrs:{
			...SegObjShellAttr,
			"queryText":{
				name:"queryText",showName:(($ln==="CN")?("询问文本"):/*EN*/("Query text")),type:"string",key:1,fixed:1,initVal:"Please choose"),
			},
			"multi":{
				name:"multi",showName:(($ln==="CN")?("多选"):/*EN*/("Multi-select")),type:"bool",key:1,fixed:1,initVal:false),
			},
			//TODO:Init outlets:
		},
		listHint:[
			"id","label","queryText","x","y","desc","codes","nameVal"
		]
	});
}

export {EditAISeg,EditAISegOutlet};