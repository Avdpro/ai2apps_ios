import {VFACT} from "/@vfact";
const $ln=VFACT.lanCode;

let basicTemplates=[
	//------------------------------------------------------------------------
	//Visual Dev Application
	{
		name:"V Tab-OS Application",
		catalog:"Visual Dev.",
		caption:{"EN":"Tab-OS Application","CN":"Tab-OS 应用程序"},
		icon:"assets/prj/cklogo.svg",
		diskId:"prj_tabapp@avdpro@me.com",
		info:{
			"EN":"Create an application runs in Tab-OS environment. Develop it with Tab-OS' VFACT(Visual Faced Abstruct Component Tree) framework.",
			"CN":"创建一个运行在Tab-OS环境中的应用程序. 基于Tab-OS关联的VFACT(Visual Faced Abstruct Component Tree) 框架.",
		},
		preview:["assets/prj/prj_tabapp.png"],
		editPrj:{
			"version": "1.0.0",
			"indent": 4,
			"tabDocs": [
				"ui/MainUI.js",
				"app.js",
				"app.html",
				"cfg/appCfg.js",
				"app.config.js"
			],
			"liveDocs": [
				"app.js",
				"app.html",
				"cfg/appCfg.js",
				"app.config.js",
				"ui/MainUI.js"
			]
		}
	},
	//Visual React HTML
	{
		name:"V Visual React HTML",
		catalog:"Visual Dev.",
		caption:{"EN":"Visual React HTML","CN":"可视化React"},
		icon:"assets/prj/react.svg",
		diskId:"prj_vreact@avdpro@me.com",
		info:{
			"EN":"Create a Visual React HTML project. With Visual Editor (WYSWYG), you can design and code at same time. Fast and Easy.",
			"CN":"创建一个可视化的React HTML 页面项目. 在可视化编辑器中，你可以一边设计一边编写代码，还可以利用Faces机制应对复杂的页面变化。",
		},
		preview:["assets/prj/prj_app.png"],
		mark:"mark_work",
		mark:"mark_lab",
		editPrj:{
			"version": "1.0.0",
			"indent": 4,
			"tabDocs": [
				"readme.md",
				"ui/MainUI.jsx",
				"ui/BoxColor.jsx",
				"app.js",
				"app.html"
			],
			"liveDocs": [
				"app.html",
				"app.js",
				"ui/BoxColor.jsx",
				"ui/MainUI.jsx",
				"readme.md"
			]
		}
	},
	//Visual HTML
	{
		name:"V Visual HTML",
		catalog:"Visual Dev.",
		icon:"assets/prj/web.svg",
		caption:{"EN":"Visual HTML","CN":"可视化HTML页面"},
		info:{
			"EN":"Design and develop your HTML page with WYSWYG Editor. Easy and Fun!",
			"CN":"在可视化编辑器中设计并开发HTML页面，又快又有趣!",
		},
		preview:["assets/prj/prj_html.png"],
		mark:"mark_work"
	},
	{
		name:"V Visual VUE HTML",
		catalog:"Visual Dev.",
		caption:"Visual VUE HTML",
		icon:"assets/prj/vue.svg",
		info:"Simple VUE HTML project.",
		preview:["assets/prj/vue.png"],
		mark:"mark_work"
	},
	{
		name:"V Visual iOS App",
		catalog:"Visual Dev.",
		caption:"Visual iOS App",
		icon:"assets/prj/app.svg",
		info:"Simple VUE HTML project.",
		preview:["assets/prj/prj_app.png"],
		mark:"mark_work"
	},
	{
		name:"V Visual Android App",
		catalog:"Visual Dev.",
		caption:"Visual Android App",
		icon:"assets/prj/android.svg",
		info:"Simple VUE HTML project.",
		preview:["assets/prj/android.png"],
		mark:"mark_work"
	},
	//------------------------------------------------------------------------
	//Tab-OS Application
	{
		name:"Tab-OS Application",
		catalog:"Tab-OS",
		caption:{"EN":"Tab-OS Application","CN":"Tab-OS 应用程序"},
		icon:"assets/prj/cklogo.svg",
		diskId:"prj_tabapp@avdpro@me.com",
		info:{
			"EN":"Create an application runs in Tab-OS environment. Develop it with Tab-OS' VFACT(Visual Faced Abstruct Component Tree) framework.",
			"CN":"创建一个运行在Tab-OS环境中的应用程序。 基于Tab-OS关联的VFACT(Visual Faced Abstruct Component Tree) 框架开发。",
		},
		preview:["assets/prj/prj_tabapp.png"],
		editPrj:{
			"version": "1.0.0",
			"indent": 4,
			"tabDocs": [
				"ui/MainUI.js",
				"app.js",
				"app.html",
				"cfg/appCfg.js",
				"app.config.js"
			],
			"liveDocs": [
				"app.js",
				"app.html",
				"cfg/appCfg.js",
				"app.config.js",
				"ui/MainUI.js"
			]
		}
	},
	//Tab-OS Command Line Tool
	{
		name:"Command Line Tool",
		catalog:"Tab-OS",
		caption:{"EN":"Command Line Tool","CN":"命令行工具程序"},
		icon:"assets/prj/cmd.svg",
		zipFile:"assets/prj/prj_cmd.zip",
		info:{
			"EN":"Command line tool-app runs in the terminal.",
			"CN":"在终端中运行的命令行工具程序。",
		},
		preview:["assets/prj/prj_cmd.png"],
		diskId:"prj_cmd@avdpro@me.com",
		editPrj:{
			"version": "1.0.0",
			"indent": 4,
			"tabDocs": [
				"cmd.js",
				"readme.md"
			],
			"liveDocs": [
				"readme.md",
				"cmd.js"
			]
		}
	},
	//Empty HTML Project
	{
		name:"Empty Project",
		catalog:"Tab-OS",
		caption:"Empty Project",
		icon:"assets/prj/empty.svg",
		diskId:"prj_empty@avdpro@me.com",
		info:"Empty Tab Code project.",
		preview:["assets/prj/prj_empty.png"]
	},
	
	//------------------------------------------------------------------------
	//IDE UI-Lib
	{
		name:"IDE UI-Lib Add On",
		catalog:"IDE Add On",
		caption:"IDE UI-Lib",
		icon:"assets/prj/gears.svg",
		info:"Create an UI-Lib for Tab Studio IDE. An UI-Lib can have component templates and data templates",
		preview:["assets/prj/gears.png"],
		mark:"mark_work"
	},
	//IDE Navi Tool AddOn
	{
		name:"IDE Navi-Tool Add On",
		catalog:"IDE Add On",
		caption:"IDE Navi-Tool",
		icon:"assets/prj/gears.svg",
		info:"Create a Tab Studio IDE Navi-Tool Add On. This is an UI-Box at left side of the IDE",
		preview:["assets/prj/gears.png"],
		mark:"mark_work"
	},
	//IDE Info Tool AddOn
	{
		name:"IDE Info-Tool Add On",
		catalog:"IDE Add On",
		caption:"IDE Info-Tool",
		icon:"assets/prj/gears.svg",
		info:"Create a Tab Studio IDE Info-Tool Add On. This is an UI-Box at right side of the IDE",
		preview:["assets/prj/gears.png"],
		mark:"mark_work"
	},
	//IDE Edit Mode AddOn
	{
		name:"IDE Edit Mode Add On",
		catalog:"IDE Add On",
		caption:"IDE Edit Mode",
		icon:"assets/prj/gears.svg",
		info:"Create a Tab Studio IDE custom editor-UI for certain type of docs.",
		preview:["assets/prj/gears.png"],
		mark:"mark_work"
	},
	//IDE Exporter AddOn
	{
		name:"Doc Exporter AddOn",
		catalog:"IDE Add On",
		caption:"Doc Exporter",
		icon:"assets/prj/gears.svg",
		info:"Create a Tab Studio IDE custom exporter for certain type of docs.",
		preview:["assets/prj/gears.png"],
		mark:"mark_work"
	},

	//------------------------------------------------------------------------
	//HTML Dev.
	{
		name:"HTML",
		catalog:"HTML Dev.",
		icon:"assets/prj/web.svg",
		caption:"Basic HTML",
		zipFile:"assets/prj/prj_html.zip",
		info:"Basic HTML page with a script and a css file.",
		preview:["assets/prj/prj_html.png"],
		diskId:"prj_html@avdpro@me.com",
		editPrj:{
			"version": "1.0.0",
			"indent": 4,
			"tabDocs": [
				"index.html",
				"style.css",
				"code.js"
			],
			"liveDocs": [
				"code.js",
				"style.css",
				"index.html",
			]
		}
	},
	//Visual HTML
	{
		name:"Visual HTML",
		catalog:"HTML Dev.",
		icon:"assets/prj/web.svg",
		caption:"Visual HTML",
		info:"Design and develop your HTML page with WYSWYG Editor. Easy and Fun!",
		preview:["assets/prj/prj_html.png"],
		mark:"mark_lab"
	},
	//Visual HTML with Bootstrap.
	{
		name:"Visual BootStrap",
		catalog:"HTML Dev.",
		icon:"assets/prj/web.svg",
		caption:"Visual BootStrap HTML",
		info:"Design and develop your BootStrap powered HTML page with WYSWYG Editor. Easy and Fun!",
		preview:["assets/prj/prj_html.png"],
		mark:"mark_work"
	},
	//Visual HTML with Tailwind.
	{
		name:"Visual Tailwind",
		catalog:"HTML Dev.",
		icon:"assets/prj/web.svg",
		caption:"Visual Tailwind HTML",
		info:"Design and develop your Tailwind powered HTML page with WYSWYG Editor. Easy and Fun!",
		preview:["assets/prj/prj_html.png"],
		mark:"mark_work"
	},
	
	//------------------------------------------------------------------------
	//React HTML
	//Visual React HTML
	{
		name:"Visual React HTML",
		catalog:"React Dev.",
		caption:{EN:"Visual React HTML",CN:"可视化React页面"},
		icon:"assets/prj/react.svg",
		info:{
			"EN":"Create a Visual React HTML project. With Visual Editor (WYSWYG), you can design and code at same time. Fast and Easy.",
			"CN":"创建一个可视化的React HTML 页面项目. 在可视化编辑器中，你可以一边设计一边编写代码，还可以利用Faces机制应对复杂的页面变化。",
		},
		preview:["assets/prj/prj_app.png"],
		mark:"mark_work",
		mark:"mark_lab",
		diskId:"prj_vreact@avdpro@me.com",
		editPrj:{
			"version": "1.0.0",
			"indent": 4,
			"tabDocs": [
				"readme.md",
				"ui/MainUI.jsx",
				"ui/BoxColor.jsx",
				"app.js",
				"app.html"
			],
			"liveDocs": [
				"app.html",
				"app.js",
				"ui/BoxColor.jsx",
				"ui/MainUI.jsx",
				"readme.md"
			]
		}
	},
	{
		name:"React HTML",
		catalog:"React Dev.",
		caption:"React HTML",
		icon:"assets/prj/react.svg",
		info:"Create a basic React HTML project. Using rollup to build source.",
		preview:["assets/prj/prj_app.png"],
		diskId:"prj_react@avdpro@me.com",
		editPrj:{
			"version": "1.0.0",
			"indent": 4,
			"tabDocs": [
				"ui.js",
				"app.js",
				"dev.html",
				"readme.md"
			],
			"liveDocs": [
				"readme.md",
				"dev.html",
				"app.js",
				"ui.js"
			]
		}
	},
	//React HTML HMR
	{
		name:"React HTML HMR",
		catalog:"React Dev.",
		caption:"React HTML HMR",
		icon:"assets/prj/react.svg",
		info:"Create a React HTML project with HMR feature.",
		preview:["assets/prj/prj_app.png"],
		mark:"mark_lab",
		diskId:"prj_reacthmr@avdpro@me.com",
		editPrj:{
			"version": "1.0.0",
			"indent": 4,
			"tabDocs": [
				"readme.md",
				"src/app.jsx",
				"src/app.css",
				"public/index.html"
			],
			"liveDocs": [
				"public/index.html",
				"src/app.css",
				"src/app.jsx",
				"readme.md"
			]
		}
	},
	
	//------------------------------------------------------------------------
	//Visual VUE HTML
	{
		name:"Visual VUE HTML",
		catalog:"VUE Dev.",
		caption:"Visual VUE HTML",
		icon:"assets/prj/app.svg",
		info:"Simple VUE HTML project.",
		preview:["assets/prj/prj_app.png"],
		mark:"mark_lab"
	},
	//VUE HTML
	{
		name:"VUE HTML",
		catalog:"VUE Dev.",
		caption:"VUE HTML",
		icon:"assets/prj/app.svg",
		info:"Simple VUE HTML project.",
		preview:["assets/prj/prj_app.png"],
		mark:"mark_work"
	},
	//VUE HTML HMR
	{
		name:"VUE HTML HMR",
		catalog:"VUE Dev.",
		caption:"VUE HTML HMR",
		icon:"assets/prj/app.svg",
		info:"VUE HTML project with HMR support.",
		preview:["assets/prj/prj_app.png"],
		mark:"mark_work"
	},
	
	//------------------------------------------------------------------------
	//Mobile Visual HTML5 App
	{
		name:"Mobile HTML5 App",
		catalog:"Mobile Dev.",
		caption:"HTML5 App",
		icon:"assets/prj/app.svg",
		info:"Mobile application runs in WebView in iOS or Android.",
		preview:["assets/prj/prj_app.png"],
		mark:"mark_work"
	},
	//React Native iOS App
	{
		name:"React Native iOS App",
		catalog:"Mobile Dev.",
		caption:"React Native iOS",
		icon:"assets/prj/react.svg",
		zipFile:"assets/prj/prj_app.zip",
		diskId:"prj_app@avdpro@me.com",
		info:"React Native application runs in in iOS.",
		preview:["assets/prj/prj_app.png"],
		mark:"mark_work"
	},
	//React Native Android App
	{
		name:"React Native Android App",
		catalog:"Mobile Dev.",
		caption:"React Native Android",
		icon:"assets/prj/react.svg",
		info:"React Native application runs in in Android.",
		preview:["assets/prj/prj_app.png"],
		mark:"mark_work"
	},
	
	//------------------------------------------------------------------------
	//HTTP REST API Server
	{
		name:"HTTP API Server",
		catalog:"Backend Dev.",
		caption:"HTTP API Server",
		icon:"assets/prj/cloud.svg",
		info:"Create a simple HTTP Server answer JSON (REST) API calls. Useful for simulating the real server APIs.",
		preview:["assets/prj/prj_app.png"],
		diskId:"prj_api@avdpro@me.com",
		editPrj:{
			"version": "1.0.0",
			"indent": 4,
			"tabDocs": [
				"readme.md",
				"server.js",
				"test.html"
			],
			"liveDocs": [
				"test.html",
				"server.js",
				"readme.md"
			]
		}
	},
	//HTTP Fastify Server
	{
		name:"Fastify Server",
		catalog:"Backend Dev.",
		caption:"Fastify Server",
		icon:"assets/prj/cloud.svg",
		info:"Create a Fastify Server project.",
		preview:["assets/prj/prj_app.png"],
		mark:"mark_lab"
	},
	//Node Application
	{
		name:"Node Application",
		catalog:"Backend Dev.",
		caption:"Node Application",
		icon:"assets/prj/cloud.svg",
		info:"Create a Node application.",
		preview:["assets/prj/prj_app.png"],
		mark:"mark_work"
	},
	//HTTP Express Server
	{
		name:"Express Server",
		catalog:"Backend Dev.",
		caption:"Express Server",
		icon:"assets/prj/cloud.svg",
		info:"Create a Express Server project.",
		preview:["assets/prj/prj_app.png"],
		mark:"mark_work"
	},
	//TODO: Add more
];

export default basicTemplates;
export {basicTemplates};