import {tabOS,tabFS,tabTask} from "/@tabos";
import {VFACT} from "/@vfact";
import {} from "/@vfact/vfact_app.js";
import{appCfg} from "./cfg/appCfg.js";
import {AppLib} from "./data/AppLib.js";
import {UIHome} from "./ui/UIHome.js";
import {DlgTask} from "./ui/DlgTask.js";

if(window.innerWidth>=500){
	//Ask before close:
	window.onbeforeunload=function (e) {
		// Cancel the event
		e.preventDefault(); // If you prevent default behavior in Mozilla Firefox prompt will always be shown
		// Chrome requires returnValue to be set
		e.returnValue = 'Are you sure to close code editor? Unsaved changes will be lost.';
		return 'Are you sure to close code editor? Unsaved changes will be lost.';
	};

	async function startApp() {
		let app;

		
		window.name="TabOSHome";
		document.title=appCfg.isAI2Apps?"AI2Apps Home":"TabOS Home";

		app=await VFACT.createApp();

		//setup open (openPath, openMeta...) API:
		await AppLib.setupOpenAPI(app,null);

		//init app, create app UI tree:
		await VFACT.initApp(app,UIHome(app),{shortcuts:{},DlgTask:DlgTask});
	}
	
	tabOS.allowRoot=true;//Our OS can be the rootOS:
	tabOS.setup(true).then(()=>{startApp();});
}else{
	window.location.href="/@MobileHome/app.html";
}
