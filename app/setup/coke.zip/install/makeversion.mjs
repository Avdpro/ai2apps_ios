import {tabOS,tabFS} from "/@tabos";
import pathLib from "/@path";

export default async function makeVersion(env){
	let orgCokeJSON,tgtCokeJSON,versionIdx;
	orgCokeJSON=await tabFS.readFile("/coke/disk.json","utf8");
	orgCokeJSON=JSON.parse(orgCokeJSON);
	tgtCokeJSON=await tabFS.readFile("/inst/disk.json","utf8");
	tgtCokeJSON=JSON.parse(tgtCokeJSON);
	versionIdx=orgCokeJSON.versionIdx||0;
	versionIdx+=1;//Make sure increase versionIdx
	orgCokeJSON.versionIdx=versionIdx;
	tgtCokeJSON.version=orgCokeJSON.version;
	tgtCokeJSON.versionIdx=versionIdx;
	await tabFS.writeFile("/coke/disk.json",JSON.stringify(orgCokeJSON,null,"\t"),"utf8");
	await tabFS.writeFile("/inst/disk.json",JSON.stringify(tgtCokeJSON,null,"\t"),"utf8");
}
