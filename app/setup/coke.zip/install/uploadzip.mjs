import {tabOS,tabFS,tabNT} from "/@tabos";
import pathLib from "/@path";
import Base64 from "/@tabos/utils/base64.js";

export default async function uploadzip(env){
	let list,entry,fileName,fileData,tty;
	tty=env.tty;
	list=await tabFS.getEntries("/inst-zip");
	for(entry of list){
		if(!entry.dir){
			fileName=entry.name;
			fileData=await tabFS.readFile("/inst-zip/"+fileName);
			fileData=Base64.encode(fileData);
			await tabNT.makeCall("postInstZip",{
				fileName:fileName,
				data:fileData,
				size:fileData.length,
			});
			tty.textOut("Upload file: "+fileName+" done.\n");
		}
	}
}
