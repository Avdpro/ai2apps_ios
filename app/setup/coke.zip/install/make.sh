#Prepare empty disks:
disk drop inst
disk drop inst-zip
disk new inst
disk new inst-zip

#Prepare coke disk
#=============================================================================
#files needed to cop:
cp -f /coke/bin/cmd.html /inst/bin/
cp -f /coke/lib/terminal.json /inst/lib/
cp -f /coke/lib/ccedit.json /inst/lib/
cp -f /coke/lib/desktop.json /inst/lib/
cp -f /coke/lib/diskit.json /inst/lib/

#=============================================================================
#Packages needed to install:
pkg install markdownit -sd inst
pkg install cokecmds -sd inst
pkg install pkg -sd inst
pkg install disk -sd inst
pkg install cloud -sd inst
#pkg install nodeshim -sd inst
pkg install cmdargs -sd inst
pkg install zippath -sd inst
pkg install cokecodes -sd inst
pkg install codemirror -sd inst
pkg install markbook -sd inst
pkg update jaxweb -sd inst
pkg update terminal -sd inst
pkg update desktop -sd inst
pkg update ccedit -sd inst
pkg update diskit -sd inst

#=============================================================================
#Update install-coke disk's version
coke /coke/install/makeversion.mjs

#zip inst disk into /inst-zip/coke.zip
zip /inst/* /inst-zip/coke.zip

#zip -terminal into /inst-zip/terminal.zip
zip /-terminal/* /inst-zip/terminal.zip

#zip -desktop into /inst-zip/desktop.zip
zip /-desktop/* /inst-zip/desktop.zip

#zip -diskit into /inst-zip/diskit.zip
zip /-diskit/* /inst-zip/diskit.zip

#zip -ccedit into /inst-zip/ccedit.zip
zip /-ccedit/* /inst-zip/ccedit.zip

#=============================================================================
#Update install check versions:
cd /coke/install
coke updateversions.mjs

#=============================================================================
#Rollup install:
cd /webhome
rollup -c rollup.setup.js
coke makeinstall.mjs
cp -f install.html /inst-zip/
cd /coke/install
