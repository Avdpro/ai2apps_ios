#Prepare empty disks:
disk drop inst
disk drop inst-zip
disk new inst
disk new inst-zip

#=============================================================================
#Prepare coke disk
#Packages needed to install:
pkg install markdownit -sd inst
pkg install cokecmds -sd inst
pkg install disk -sd inst
pkg install pkg -sd inst
pkg install cloud -sd inst
pkg install cmdargs -sd inst
pkg install zippath -sd inst
pkg install codemirror -sd inst
pkg install vfact -sd inst
pkg install codeLint -sd inst
pkg update tabos -sd inst
pkg update homekit -sd inst
pkg update terminal -sd inst
pkg update files -sd inst
pkg update tabedit -sd inst
pkg update editkit -sd inst
pkg update books -sd inst
pkg update StdUI -sd inst
pkg update aichat -sd inst
pkg update MobileHome -sd inst

#=============================================================================
#Update install-coke disk's version
coke /coke/install/makeversion.mjs

#zip inst disk into /inst-zip/coke.zip
zip /inst/* /inst-zip/coke.zip

#zip setup disks into /inst-zip/
zip /-tabos/* /inst-zip/tabos.zip
zip /-homekit/* /inst-zip/homekit.zip
zip /-terminal/* /inst-zip/terminal.zip
zip /-files/* /inst-zip/files.zip
zip /-tabedit/* /inst-zip/tabedit.zip
zip /-editkit/* /inst-zip/editkit.zip
zip /-books/* /inst-zip/books.zip
zip /-StdUI/* /inst-zip/StdUI.zip
zip /-aichat/* /inst-zip/aichat.zip
zip /-MobileHome/* /inst-zip/MobileHome.zip

#=============================================================================
#Update install check versions:
cd /coke/install
coke updateversions.mjs

#=============================================================================
#Rollup install:
cd /install_tab
rollup -c rollup.setup.js
coke makeinstall.mjs
cp -f setup.html /inst-zip/
cd /coke/install
coke uploadzip.mjs
