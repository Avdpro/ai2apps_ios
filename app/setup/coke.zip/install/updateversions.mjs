import {tabOS,tabFS} from "/@tabos";
import pathLib from "/jaxweb/utils/path.js";

async function getDiskVersion(dskName){
	let pkgJSON,jsonPath;
	jsonPath=`/${dskName}/disk.json`;
	try{
		pkgJSON=await tabFS.readFile(jsonPath,"utf8");
		pkgJSON=JSON.parse(pkgJSON);
		return pkgJSON.versionIdx;
	}catch(err){
		return null;
	}
};

//----------------------------------------------------------------------------
//Get a installed package version:
async function getPkgVersion(pkgName){
	let pkgJSON,jsonPath;
	jsonPath=`/coke/lib/${pkgName}/coke.json`;
	try{
		pkgJSON=await tabFS.readFile(jsonPath,"utf8");
	}catch(err){
		pkgJSON=null;
	}
	if(pkgJSON){
		let tag,tags,tagVO;
		//This package is in lib:
		try{
			pkgJSON=JSON.parse(pkgJSON);
			tag=pkgJSON.tag;
			tags=pkgJSON.tags;
			tagVO=tags[tag];
			return tagVO.versionIdx;
		}catch(err){
			return null;
		}
	}else{
		//Maybe this package is in disk:
		jsonPath=`/-${pkgName}/disk.json`;
		pkgJSON=await tabFS.readFile(jsonPath,"utf8");
		try{
			pkgJSON=JSON.parse(pkgJSON);
			return pkgJSON.versionIdx;
		}catch(err){
			return null;
		}
	}
};

export default async function cmd(env,args){
	let vsnList=[],code;
	await tabOS.setup();
	vsnList.push({name:"coke",versionIdx:await getDiskVersion("coke"),zip:"coke.zip"});
	vsnList.push({name:"-tabos",versionIdx:await getDiskVersion("-tabos"),zip:"tabos.zip"});
	vsnList.push({name:"-homekit",versionIdx:await getDiskVersion("-homekit"),zip:"homekit.zip"});
	vsnList.push({name:"-terminal",versionIdx:await getDiskVersion("-terminal"),zip:"terminal.zip"});
	vsnList.push({name:"-files",versionIdx:await getDiskVersion("-files"),zip:"files.zip"});
	vsnList.push({name:"-tabedit",versionIdx:await getDiskVersion("-tabedit"),zip:"tabedit.zip"});
	vsnList.push({name:"-editkit",versionIdx:await getDiskVersion("-editkit"),zip:"editkit.zip"});
	vsnList.push({name:"-books",versionIdx:await getDiskVersion("-books"),zip:"books.zip"});
	vsnList.push({name:"-aichat",versionIdx:await getDiskVersion("-aichat"),zip:"aichat.zip"});
	vsnList.push({name:"-StdUI",versionIdx:await getDiskVersion("-StdUI"),zip:"StdUI.zip"});
	vsnList.push({name:"-MobileHome",versionIdx:await getDiskVersion("-MobileHome"),zip:"MobileHome.zip"});

	code=`export default ${JSON.stringify(vsnList,null,"\t")}`;
	env.tty.textOut("Disk versions: \n");
	env.tty.textOut(JSON.stringify(vsnList,null,"\t")+"\n");
	await tabFS.writeFile("/install_tab/diskversion.js",code,"utf8");

	vsnList=[];
	vsnList.push({name:"coke",versionIdx:await getDiskVersion("coke"),zip:"coke.zip"});
	vsnList.push({name:"-tabos",versionIdx:await getDiskVersion("-tabos"),zip:"tabos.zip"});
	vsnList.push({name:"-homekit",versionIdx:await getDiskVersion("-homekit"),zip:"homekit.zip"});
	vsnList.push({name:"-terminal",versionIdx:await getDiskVersion("-terminal"),zip:"terminal.zip"});
	vsnList.push({name:"-files",versionIdx:await getDiskVersion("-files"),zip:"files.zip"});
	vsnList.push({name:"-books",versionIdx:await getDiskVersion("-books"),zip:"books.zip"});
	vsnList.push({name:"-aichat",versionIdx:await getDiskVersion("-aichat"),zip:"aichat.zip"});
	vsnList.push({name:"-StdUI",versionIdx:await getDiskVersion("-StdUI"),zip:"StdUI.zip"});
	vsnList.push({name:"-MobileHome",versionIdx:await getDiskVersion("-MobileHome"),zip:"MobileHome.zip"});

	code=`export default ${JSON.stringify(vsnList,null,"\t")}`;
	env.tty.textOut("Mobile Disk versions: \n");
	env.tty.textOut(JSON.stringify(vsnList,null,"\t")+"\n");
	await tabFS.writeFile("/install_tab/diskversion_mobile.js",code,"utf8");
};
