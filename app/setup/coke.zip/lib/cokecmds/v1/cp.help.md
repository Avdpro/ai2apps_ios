### Commnad: *cp* -- copy files

#### Usage:
       cp [source-file] [target-file]
       cp [source-file] [target-dir]

In the first synopsis form, the cp utility copies the contents of the 
source_file to the target_file.  In the second synopsis form, the 
contents of each named source_file is copied to the destination 
target_directory.  The names of the files themselves are not changed.  If 
cp detects an attempt to copy a file to itself, the copy will fail.

#### Examples:
      cp image.svg /images/image.svg
copy "image.svg" file in CDRPATH to "/images/image.svg".

      cd image.svg /images
copy "image.svg" file in CDRPATH to "/images" dir, the result will be "/images/image.svg".
