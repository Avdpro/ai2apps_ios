## Commnad: *cd*

### Usage:
       cd [dir]

Change the current directory to DIR. The variable CDPATH defines the search path for the directory containing DIR. 
Alternative directory names in CDPATH
are separated by a colon (:).  A null directory name is the same as
the current directory, i.e. ".".  If DIR begins with a slash (/),
then CDPATH is not used.  If the directory is not found, and the
shell option `cdable_vars' is set, then try the word as a variable
name.  If that variable has a value, then cd to the value of that
variable.

### Examples:
      cd images
Change the current directory to "images" under current CDPATH. If current CDPATH is "/myapp", then change the directory to "/myapp/images".

      cd /images
Change the current directory to "/images" which is a root dir(disk).
