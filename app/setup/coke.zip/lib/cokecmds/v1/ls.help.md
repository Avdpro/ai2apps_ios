### Commnad: *ls* -- list directory contents

#### Usage:
       ls [-lha] [dir]

List files in [dir]. Default [dir] is [CDPATH].

 - -l: List files with details.
 - -h: Show file size with better to read format.
 - -a: Show hidden files

#### Examples:
      ls
List all files in current dir.

      ls -la /coke/bin
List all files in "/coke/bin" dir with file details and show hidden files.
