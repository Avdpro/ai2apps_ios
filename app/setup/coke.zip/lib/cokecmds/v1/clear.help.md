### Commnad: *clear* -- clear terminal screen.
