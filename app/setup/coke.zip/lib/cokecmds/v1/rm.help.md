### Commnad: *rm* -- remove directory entries

#### Usage:
       rm [-d][-r] path

The rm utility attempts to remove the non-directory type files specified 
on the command line.  If the permissions of the file do not permit writing, 
and the standard input device is a terminal, the user is prompted 
(on the standard error output) for confirmation.
	 
- -d: Allow remove dir as well as other types of files.

- -r: Attempt to remove the file hierarchy rooted in each file argument.  The -r option implies the -d option.

#### Examples:
      rm nice.js
Remove file nice.js
