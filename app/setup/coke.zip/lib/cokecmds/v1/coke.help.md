## Commnad: *coke* -- excute javascript file or sh file.

### Usage:
       coke [src-file]

Load and execute [src-file]. [src-file] can be .js/.mjs(javascript) file that write under **the rule** or .sh(coke shell commands) file.

### Examples:
      coke startBackup.sh

      coke showUserName.js

      coke updateClient.mjs
