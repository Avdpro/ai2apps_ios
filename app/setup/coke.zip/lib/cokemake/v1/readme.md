## CokeCodes Terminal Command Project
This project is created by Cokecodes project wizard. 
This is a **Terminal Command** project. It's main entry is **cmd.js**. When executed, **cmd.js** will print a line "Hello world". If starts with a argument, it will print the argument text in second line.


### Edit
Edit cmd.js or add other source files with CCEdit.

### Test and run
- In CCEdit, click the run button on tool bar to quick test your commnad. The default entry is cmd.js. You can change the entry in **disk.json**
- In Terminal:  
```
	cd /[YourPrjDiskName]  
	coke [YourMainEntry.js]
```

### Export bin executable
You can export your cmd as system executable. So it can be execute in terminal just like system commands.
- First, config your disk.json's **binExport** property. It defines the bin-executable entry(s). One project (package) can export more than one bin-executables.  
The binExport property should looks like this:
```
	...
	"binExport": [
		{
			"name": "newCmd",
			"main": "cmd.js",
			"type": "cmd"
		}
	]
	...
```
It is a array of **export entry** 
	- "name" attribute is the execute command name. In this case, the command will be **newCmd**.
	- "main" attribute is the entry file to execute
	- "type" attribute is the executable's type. For terminal commnad, it should be **"cmd"**.

<br/>

- To export your executable, start a terminal:  
```
	cd /[YourPrjDiskName]
	pkg binexport
```
This will make your command executable. Then you will able use your command.


### Cloud
- You can **checkin** this disk with **Diskit** app or use terminal command:  
```
cd /[YourPrjDiskName]
disk checkin
```  
You will be asked about your disk name on cloud, and version.  

- To **commit** your changes, use terminal command:  
```
cd /[YourPrjDiskName]
disk commit
```  
With disk on cloud, you can sync connents and track the version changes.

- **cloudId**: your disk's cloud-uniq-name. After check in check your **disk.json**, it should be: `[diskName]@[yourAccoutEmail]`. You can share your cloud disk with others or check it out and continue your work on other computer at any place.

- You can check out your work on anywhere, in terminal:  
```
disk checkout [cloudId]
```  


### Packag and publish
1. Before publish your disk as a package, make sure your disk is already commited to the cloud.
2. To publish package, in terminal run:  
```
	cd /[YourPrjDiskName]
	pkg share
```
You will be asked about version and tag, then the **pkg** tool will publish your package on cloud.
3. Install your package, in terminal run:  
```
	pkg install [YourPackageName[@YourAccoutEmail]]
```
Or, in another project, to import your package as lib:
```
	cd /[WorkPrjDiskName]
	pkg import [YourPackageName[@YourAccoutEmail]]
```
4. Update a package, in terminal run:  
```
	pkg update [YourPackageName[@YourAccoutEmail]]
```

