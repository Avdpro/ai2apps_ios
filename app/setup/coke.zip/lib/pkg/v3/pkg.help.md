
## Commnad: *pkg*

### Usage:
```
  pkg init                              Init current project-disk for packageing
  pkg install [[Tag@]PkgName]           Install a package. 
  pkg import [[Tag@]PkgName]            Import a package for current project-disk
  pkg update [PkgName]                  Update a package to the lastest tag/version
  pkg merge [PkgName]                   Merge a package's compatible tags 
  pkg uninstall [[Tag@]PkgName]         Uninstall a package/lib/app/tool
  pkg unimport [[Tag@]PkgName]          Unimport a package for current project-disk
  pkg binexport                         Export current disk project's bin executable
  pkg libexport                         Export current disk project to system lib
  pkg share                             Share current disk project as package in www.cokecodes.com
```

#### init
Init current project-disk for packageing. It will setup the **disk.json** file in your project-disk's root dir. You will be asked about package name and main entry. You can config those attributes in **disk.json**.

#### install
Install a package. Note: user shared package name should like `name@useremail`.  
examples:  
`pkg install disk`
install the **disk** package  
`pkg install mytool@user@mail.com` 
install the **mytool** package shared by user accout **user@mail.com**.

#### import
Import a package for current project-disk. Package dependence will be recorded in **disk.json**. Note: user shared package name should like `name@useremail`.  

***Examples:*** 
`pkg import disk`
Import  the **disk** package  
`pkg import mytool@user@mail.com` 
install the **mytool** package shared by user accout **user@mail.com**. 

***Import a package in code:***
import default:
`import obj from "/@pkgName";`
Import a single item:
`import {item} from "/@pkgName";`
import default from a file other than package main entry:
`import obj from "/@pkgname/file.js";`
Import a single item from a file other than package main entry:
`import {item} from "/@pkgname/file.js";`

#### update
Update a installed package to it's latest tag and version.

#### merge
Merge a package's compatible tags. For example, there is 3 tags of package "coolib" installed: V1, V2 and V3. The V3 is compatible with V2 but not compatible with V1. After merge, V2 will be "redirected" to V3 and it's files will be removed from disk. But V1 files will be remained cause V3 is not compatible with it.
</br>
</br>
#### uninstall
Uninstall a package. If the package is still been imported by projects, uninstall will not execute.

#### unimport
Unimport a package for current project-disk. If a package is not needed by any project, it will be removed.

#### binexport
You can export your cmd as system executable. So it can be execute in terminal just like system commands.  
First, config your disk.json's **binExport** property. It defines the bin-executable entry(s). One project (package) can export more than one bin-executables.  
The binExport property should looks like this:
```
	...
	"binExport": [
		{
			"name": "newCmd",
			"main": "cmd.js",
			"type": "cmd"
		}
	]
	...
```
It is a array of **export entry**   

- "name" attribute is the execute command name. In this case, the command will be **newCmd**.
- "main" attribute is the entry file to execute
- "type" attribute is the executable's type. For terminal commnad, it should be **"cmd"**.


To export your executable, start a terminal:  
```
	cd /[YourPrjDiskName]
	pkg binexport
```
This will make your command executable. Then you will able use your command.

#### libexport
To test your project as a package, you can export your project as system package.
First, config your disk.json's **libExport** property. It defines the lib entry(s). One project (package) can export more than one lib-entry.  
The libExport property should looks like this:
```
	...
	"libExport": [
		{
			"name": "newCmd",
			"main": "newCmd/cmd.js",
			"path": "newCmd"
		},
		{
			"name": "newCmd2",
			"main": "newCmd2/cmd2.js",
			"path": "newCmd2"
		}
	]
	...
```
It is a array of **lib package entry**   

- "name" attribute is the export lib entry name. 
- "main" attribute is the entry file to export as package.
- "path" attribute is the files path for the package.


After proper configed your **disk.json**, start a terminal:  
```
	cd /[YourPrjDiskName]
	pkg libexport
```
This will export your project as package lib. It is very useful for debug a packages project.

#### share
Share your project-disk as a package. So you or others can install or import it.
