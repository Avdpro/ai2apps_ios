
## Commnad: *cloud*

### Usage:
```
  cloud register                        Register a new www.cokecods.com account.
  cloud login                           Login www.cokecods.com.
  cloud user                            Display current login account info.
  cloud password                        Change account password.
  cloud logout                          Logout www.codecodes.com.
```

**register**  
Register a new www.cokecods.com account. Email address is the uniq-account-id.

**login**  
Login www.cokecods.com. After login you can access to cloud disks or share your package.

**user**  
Display current login account info. 

**password**  
Change account password.

**logout**  
Logout www.codecodes.com.


